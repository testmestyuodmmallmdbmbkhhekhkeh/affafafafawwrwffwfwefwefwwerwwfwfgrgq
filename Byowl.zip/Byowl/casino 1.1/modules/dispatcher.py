from aiogram import Bot, Dispatcher
from modules.my_filters import IsAdminFilter, IsMainAdminFilter, IsUserBanFilter, IsChatBanFilter, IsIgnorFilter
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram.dispatcher.filters.state import State, StatesGroup
from modules.tokens import MainTokens

import logging

token = MainTokens()
telegram_token = token.tg_token()


storage = MemoryStorage()
logging.basicConfig(level=logging.INFO)
bot = Bot(telegram_token)
dp = Dispatcher(bot, storage=storage)

# Включаем фильтры
dp.filters_factory.bind(IsAdminFilter)
dp.filters_factory.bind(IsMainAdminFilter)
dp.filters_factory.bind(IsUserBanFilter)
dp.filters_factory.bind(IsChatBanFilter)
dp.filters_factory.bind(IsIgnorFilter)


# Welcome form
class start_Form(StatesGroup):
    first_menu = State()


# Welcome form
class Donations(StatesGroup):
    first_menu = State()
    second_menu = State()
    second_menu_qiwi = State()

# Welcome form
class Words(StatesGroup):
    game_menu = State()


# Welcome form
class Market(StatesGroup):
    roll_limits = State()
    roll_limits_pay = State()
