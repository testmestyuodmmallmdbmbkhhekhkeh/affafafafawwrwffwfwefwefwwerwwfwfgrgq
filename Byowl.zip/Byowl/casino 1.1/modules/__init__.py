from modules.handlers import start_handlers
from modules.handlers import qiwi_pay
from modules.handlers import donations_handlers
from modules.handlers import user_profile
from modules.handlers import all_state_handlers
