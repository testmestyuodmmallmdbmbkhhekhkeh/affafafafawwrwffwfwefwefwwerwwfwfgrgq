import json


class MainTokens:
    with open('modules/token.json', 'r') as file:
        tg_data = json.load(file)

    def tg_token(self):
        return self.tg_data['telegram_token']

    def sber_token(self):
        return self.tg_data['sber_token']

    def qiwi_token(self):
        return self.tg_data['qiwi_token']
