import schedule
import datetime
from modules import sqLite


# Цикл функций удаления данных у пользователей в чатах по расписанию
# Процесс удаления дневных данных в чате
def day_cleaner(chat_id: str, user_id: int):
    sqLite.insert_info(table=f'chat{chat_id}', id_name='tg_id', telegram_id=user_id, name='deal_day', data=0)
    sqLite.insert_info(table=f'chat{chat_id}', id_name='tg_id', telegram_id=user_id, name='income_day', data=0)
    sqLite.insert_info(table=f'chat{chat_id}', id_name='tg_id', telegram_id=user_id, name='outcome_day', data=0)


# Процесс сбора пользователей в каждом чате
def get_user_in_chat(chat: tuple):
    chat_id = str(chat[1])[1:]
    users_in_chat = sqLite.read_all(table=f'chat{chat_id}')
    for user in users_in_chat:
        user_id = user[1]
        day_cleaner(chat_id=chat_id, user_id=user_id)
    sqLite.delete_all_str(table=f'filins')


# Чистим базу каждый день
def clean_all_chats():
    chats = sqLite.read_all(table='chats')
    for chat in chats:
        get_user_in_chat(chat)


# Определяем нужно ли дать манеты сейчас
def check_deal_time(user_time: str):
    user_time = datetime.datetime.strptime(user_time, "%Y-%m-%d %H:%M:%S")
    now = datetime.datetime.now()
    time_19 = now - datetime.timedelta(minutes=19)

    if time_19.time() < user_time.time() < now.time():
        return True
    else:
        return False


# Даем монеты каждый день
def give_many_for_status():
    all_users = sqLite.read_all(table='all_users')
    now = datetime.datetime.now()
    get_time = lambda str_time: datetime.datetime.strptime(str(str_time), "%Y-%m-%d %H:%M:%S") + \
                                datetime.timedelta(days=30)
    for user in all_users:
        # Дневной
        if user[20] == 0:
            pass
        # ПРоверям 30 дней
        elif get_time(user[20]) > now:
            if check_deal_time(user[20]):
                sqLite.insert_info(table='all_users', name='money', data=user[2] + 50000, telegram_id=user[1])
                sqLite.ins_log(tg_id=str(user[1]), info=f'Начисление за статус Дневной', money="+50,000",
                               chanel_id=user[1])
            else:
                pass
        else:
            sqLite.insert_info(table='all_users', name='status_day', data=0, telegram_id=user[1])

        # Ночной
        if user[21] == 0:
            pass
        # ПРоверям 30 дней
        elif get_time(user[21]) > now:
            if check_deal_time(user[21]):
                user_money = sqLite.read_values_by_name(table='all_users', name='money', data=user[1])[0]
                sqLite.insert_info(table='all_users', name='money', data=user_money + 100000, telegram_id=user[1])
                sqLite.ins_log(tg_id=str(user[1]), info=f'Начисление за статус Ночной', money="+100,000",
                               chanel_id=user[1])
            else:
                pass
        else:
            sqLite.insert_info(table='all_users', name='status_night', data=0, telegram_id=user[1])

        # Королевский
        if user[22] == 0:
            pass
        # ПРоверям 30 дней
        elif get_time(user[22]) > now:
            if check_deal_time(user[22]):
                user_money = sqLite.read_values_by_name(table='all_users', name='money', data=user[1])[0]
                sqLite.insert_info(table='all_users', name='money', data=user_money + 500000, telegram_id=user[1])
                sqLite.ins_log(tg_id=str(user[1]), info=f'Начисление за статус Королевский', money="+500,000",
                               chanel_id=user[1])
            else:
                pass
        else:
            sqLite.insert_info(table='all_users', name='status_king', data=0, telegram_id=user[1])

        # Фирменный
        if user[23] == 0:
            pass
        # ПРоверям 30 дней
        elif get_time(user[23]) > now:
            if check_deal_time(user[23]):
                user_money = sqLite.read_values_by_name(table='all_users', name='money', data=user[1])[0]
                sqLite.insert_info(table='all_users', name='money', data=user_money + 1000000, telegram_id=user[1])
                sqLite.ins_log(tg_id=str(user[1]), info=f'Начисление за статус Королевский', money="+1.000,000",
                               chanel_id=user[1])
            else:
                pass
        else:
            sqLite.insert_info(table='all_users', name='status_firm', data=0, telegram_id=user[1])


# Основная функция расписания
# Запускаем процессы по расписанию
def start_schedule_():
    schedule.every().day.at("02:00").do(clean_all_chats)
    schedule.every(19).minutes.do(give_many_for_status)

    while True:
        schedule.run_pending()
