import sqlite3
import datetime


# Пользователь проверяет себя по базе данных
def read_value_table_name(
        table: str,
        telegram_id, *,
        graph: str = '*',
        id_name: str = 'telegram_id'):
    connect = sqlite3.connect('modules/database.db')
    curs = connect.cursor()
    curs.execute(f'SELECT {graph} FROM {table} WHERE {id_name} ="{telegram_id}"')
    data = curs.fetchall()
    connect.close()
    return data


# Пользователь проверяет данные по двум параметрам
def read_value_2_(user_tg_id,
                  ignor_tg_id, *,
                  table: str = 'ignor',
                  id_name1: str = 'user_tg_id',
                  id_name2: str = 'ignor_tg_id',
                  name: str = '*'):
    connect = sqlite3.connect('modules/database.db')
    curs = connect.cursor()
    curs.execute(f'SELECT {name} FROM {table} WHERE "{id_name1}" = "{user_tg_id}" AND "{id_name2}" = "{ignor_tg_id}"')
    data = curs.fetchall()
    connect.close()
    return data


# Пользователь проверяет себя по базе данных
def read_all(
        name: str = '*',
        table: str = 'all_users'):
    connect = sqlite3.connect('modules/database.db')
    curs = connect.cursor()
    curs.execute(f'SELECT {name} FROM {table}')
    data = curs.fetchall()
    return data


# Пользователь проверяет себя по базе данных
def give_top_bigmany(
        name: str = '*',
        table: str = 'all_users',
        sort_name: str = 'money'):
    connect = sqlite3.connect('modules/database.db')
    curs = connect.cursor()
    curs.execute(f'SELECT {name} FROM {table} ORDER BY {sort_name} DESC')
    data = curs.fetchall()
    return data


# Пользователь проверяет себя по базе данных
def read_all_log_sort(
        name: str = '*',
        table: str = 'all_users',
        sort_name: str = 'id'):
    connect = sqlite3.connect('modules/database.db')
    curs = connect.cursor()
    curs.execute(f'SELECT {name} FROM {table} ORDER BY {sort_name} DESC')
    data = curs.fetchall()
    return data


# Создаем первую запись в бд
def insert_first_note(
        table: str,
        telegram_id, *,
        id_name: str = 'telegram_id'):
    connect = sqlite3.connect('modules/database.db')
    curs = connect.cursor()
    curs.execute(f"INSERT OR IGNORE INTO {table} ({id_name}) VALUES ('{telegram_id}')")
    connect.commit()
    connect.close()


# Создаем первую запись в бд
def insert_all_info_casino(
        table: str,
        telegram_id,
        money,
        deal,
        datatime,
        nick):
    connect = sqlite3.connect('modules/database.db')
    curs = connect.cursor()
    curs.execute(f"INSERT OR IGNORE INTO {table} VALUES (?,?,?,?,?,?)",
                 (None, f'{telegram_id}', f'{money}', f'{deal}', f'{datatime}', f'{nick}'))
    connect.commit()
    connect.close()


# Создаем первую запись в бд
def insert_ignor_table(
        table: str,
        user_tg_id: int,
        ignor_tg_id: int):
    connect = sqlite3.connect('modules/database.db')
    curs = connect.cursor()
    curs.execute(f"INSERT OR IGNORE INTO {table} VALUES (?,?,?)",
                 (None, f'{user_tg_id}', f'{ignor_tg_id}'))
    connect.commit()
    connect.close()


# Создаем первую запись в бд
def ins_log(
        tg_id: str,
        info: str,
        money: str,
        chanel_id: str,
        victem_id='111'):
    connect = sqlite3.connect('modules/database.db')
    curs = connect.cursor()
    time_now = str(datetime.datetime.now()).split('.')[0]
    new_user_log_table(tg_id)
    connect.commit()
    curs.execute(f"INSERT OR IGNORE INTO log{tg_id} VALUES (?,?,?,?,?,?)",
                 (None, f'{info}', f'{money}', f'{chanel_id}', f'{victem_id}', f'{time_now}'))
    connect.commit()
    connect.close()


# Обновляем любые данные в любую таблицу
def insert_info(
        table: str,
        telegram_id,
        name: str,
        data, *,
        id_name: str = 'telegram_id'):
    connect = sqlite3.connect('modules/database.db')
    curs = connect.cursor()
    curs.execute(f"UPDATE {table} SET {name}= ('{data}') WHERE {id_name}='{telegram_id}'")
    connect.commit()
    connect.close()


# Обновляем любые данные в любую таблицу
def insert_info_roll(
        table: str,
        tg_id,
        money: int,
        deal: int,
        income: int,
        outcome: int,
        max_income: int,
        deal_day: int,
        income_day: int,
        outcome_day: int):
    connect = sqlite3.connect('modules/database.db')
    curs = connect.cursor()
    curs.execute(f"UPDATE {table} SET money = '{money}', deal = '{deal}', income = '{income}', outcome = '{outcome}', "
                 f"max_income = '{max_income}', deal_day = '{deal_day}', income_day = '{income_day}', outcome_day = "
                 f"'{outcome_day}' WHERE tg_id='{tg_id}'")
    connect.commit()
    connect.close()


# Читаем данные в таблице
def read_values_by_name(table: str,
                        data, *,
                        id_name: str = 'telegram_id',
                        name: str = '*'):
    connect = sqlite3.connect('modules/database.db')
    curs = connect.cursor()
    for d in curs.execute(f'SELECT {name} FROM {table} WHERE "{id_name}" = "{data}"'):
        return d
    connect.close()


# Удаляем данные из таблицы
def delete_str(
        table: str,
        data, *,
        name: str = 'telegram_id'):
    connect = sqlite3.connect('modules/database.db')
    curs = connect.cursor()
    curs.execute(f"DELETE FROM '{table}' WHERE {name}={data}")
    connect.commit()
    connect.close()


# Удаляем все данные из таблицы
def delete_all_str(table: str):
    connect = sqlite3.connect('modules/database.db')
    curs = connect.cursor()
    curs.execute(f"DELETE FROM '{table}'")
    connect.commit()
    connect.close()


# Удаляем таблицу
def delete_table(table: str):
    connect = sqlite3.connect('modules/database.db')
    curs = connect.cursor()
    curs.execute(f"DROP TABLE IF EXISTS {table}")
    connect.commit()
    connect.close()


# Новый юзер создает таблицу в бд
def new_table_ruletka(tg_id: str):
    db = sqlite3.connect('modules/database.db')
    cursor = db.cursor()
    cursor.execute(f'''CREATE TABLE IF NOT EXISTS ruletka{str(tg_id)} (
     id INTEGER PRIMARY KEY,
     telegram_id INTEGER,
     money INTEGER,
     deal TEXT,
     datatime TEXT,
     nick TEXT)''')
    db.commit()


# Новый юзер создает таблицу в бд
def new_table_duel(tg_id: str):
    db = sqlite3.connect('modules/database.db')
    cursor = db.cursor()
    cursor.execute(f'''CREATE TABLE IF NOT EXISTS duel{str(tg_id)} (
     id INTEGER PRIMARY KEY,
     money INTEGER,
     active_btns TEXT,
     death_btn TEXT)''')
    db.commit()


# Новый юзер создает таблицу в бд
def new_user_log_table(tg_id: str):
    db = sqlite3.connect('modules/database.db')
    cursor = db.cursor()
    cursor.execute(f'''CREATE TABLE IF NOT EXISTS log{str(tg_id)} (
     id INTEGER PRIMARY KEY,
     info TEXT,
     money TEXT,
     chanel_id TEXT,
     victem_id TEXT,
     datatime TEXT)''')
    db.commit()


# Новый юзер создает таблицу в бд
def new_table_words(tg_id: str):
    db = sqlite3.connect('modules/database.db')
    cursor = db.cursor()
    cursor.execute(f'''CREATE TABLE IF NOT EXISTS words{str(tg_id)} (
     id INTEGER PRIMARY KEY,
     tg_id_1 INTEGER UNIQUE,
     tg_id_2 INTEGER,
     money INTEGER,
     start_time TEXT,
     score_1 INTEGER,
     score_2 INTEGER,
     words_1 TEXT, 
     words_2 TEXT,
     nick_1 TEXT, 
     nick_2 TEXT,
     status TEXT)''')
    db.commit()


# Создаем первую запись в бд
def insert_all_info_words(
        tg_id_1,
        tg_id_2,
        chat_id,
        money,
        start_time,
        score_1,
        score_2,
        words_1,
        words_2,
        nick_1,
        nick_2,
        status):
    connect = sqlite3.connect('modules/database.db')
    curs = connect.cursor()
    curs.execute(f"INSERT OR IGNORE INTO words VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                 (None, chat_id, tg_id_1, tg_id_2, money, f'{start_time}', score_1, score_2,
                  f'{words_1}', f'{words_2}', f'{nick_1}', f'{nick_2}', f'{status}', None))
    connect.commit()
    connect.close()


# Новый юзер создает таблицу в бд
def new_table_chat(tg_id: str):
    db = sqlite3.connect('modules/database.db')
    cursor = db.cursor()
    cursor.execute(f'''CREATE TABLE IF NOT EXISTS chat{tg_id} (
     id INTEGER PRIMARY KEY,
     tg_id INTEGER UNIQUE,
     roll_number INTEGER DEFAULT 0,
     mute TEXT,
     titul TEXT,
     filin TEXT DEFAULT 0,
     money INTEGER DEFAULT 0,
     deal INTEGER DEFAULT 0,
     income INTEGER DEFAULT 0,
     outcome INTEGER DEFAULT 0, 
     max_income INTEGER DEFAULT 0,
     words_score INTEGER DEFAULT 0, 
     words_lengs TEXT DEFAULT 0,
     words_len_word INTEGER DEFAULT 0,
     deal_day INTEGER DEFAULT 0,
     income_day INTEGER DEFAULT 0,
     outcome_day INTEGER DEFAULT 0,
     nick TEXT)''')
    db.commit()


# Создаем первую запись в бд ТИТУЛЫ
def insert_bill(
        tg_id,
        money,
        bill_id
):
    data = datetime.datetime.now()
    connect = sqlite3.connect('modules/database.db')
    curs = connect.cursor()
    curs.execute(f"INSERT OR IGNORE INTO bills VALUES (?, ?, ?, ?, ?, ?)",
                 (None, tg_id, money, bill_id, data, None))
    connect.commit()
    connect.close()


# Создаем первую запись в бд РОЗЫГРЫШИ
def insert_raffle(
        chanel_id: str,
        creator_id: int,
        money: int,
        tg_id: int
):
    connect = sqlite3.connect('modules/database.db')
    curs = connect.cursor()
    curs.execute(f"INSERT OR IGNORE INTO raffle VALUES (?, ?, ?, ?, ?)",
                 (None, chanel_id, creator_id, money, tg_id))
    connect.commit()
    connect.close()
