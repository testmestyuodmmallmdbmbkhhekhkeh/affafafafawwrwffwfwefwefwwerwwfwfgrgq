import asyncio
import datetime

from aiogram import types
from main import dp
from modules import sqLite
from modules.dispatcher import token
from modules.dispatcher import Donations
from modules.handlers.casino.read_and_save_data import save_after_pay_qiwi
from modules.keyboards import pay_sber_kb, qiwi_pay_bill
from pyqiwip2p import QiwiP2P


token = token.qiwi_token()
p2p = QiwiP2P(auth_key=token)


@dp.callback_query_handler(state=Donations.first_menu, text='qiwi_pay')
async def pay_sber(call: types.CallbackQuery):
    await call.message.answer("Выберите платеж.", reply_markup=pay_sber_kb)
    await Donations.second_menu_qiwi.set()


# Проверяем счет на оплату
@dp.callback_query_handler(state=Donations.second_menu_qiwi)
async def input_money(call: types.CallbackQuery):
    tg_id = call.from_user.id
    print(call.data[6:])
    price = int(call.data[6:])

    bill = p2p.bill(amount=price, lifetime=15, comment=str(tg_id))
    sqLite.insert_bill(tg_id=tg_id, money=price, bill_id=str(bill.bill_id))
    await call.message.edit_text(text=f'Совершить покупку в боте на {price} RUB',
                                 reply_markup=qiwi_pay_bill(bill.pay_url))
    end_time = datetime.datetime.now() + datetime.timedelta(minutes=15)
    process = True
    while datetime.datetime.now() < end_time and process:
        if str(p2p.check(bill_id=bill.bill_id).status) == 'PAID':
            await save_after_pay_qiwi(call)
            process = False
        else:
            await asyncio.sleep(10)
    if str(p2p.check(bill_id=bill.bill_id).status) == 'PAID':
        pass
    else:
        bill_data = sqLite.read_values_by_name(table='bills', id_name='bill_id', data=str(bill.bill_id))[0]
        sqLite.delete_str(table='bills', name='id', data=bill_data)
        await call.message.answer(f"Вы не оплатили выставленный счет вовремя. Счет на сумму <b>{price} RUB</b> "
                                  f"онулирован.", parse_mode='html')
