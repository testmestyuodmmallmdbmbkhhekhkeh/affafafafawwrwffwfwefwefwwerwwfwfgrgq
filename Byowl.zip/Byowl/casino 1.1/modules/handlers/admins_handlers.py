import datetime
from aiogram import types
from modules.handlers.func_for_all_handlers import all_handlers
from modules import sqLite
from modules.dispatcher import bot


# admin parse menu
async def _admin_pars(message: types.Message):
    text = message.text
    if text.startswith('/ban'):
        await admin_ban_user(message)
    elif text.startswith('/unban'):
        await admin_unban_user(message)
    elif text.startswith('/gban'):
        await ban_chat(message)
    elif text.startswith('/gunban'):
        await unban_chat(message)
    elif text.startswith('/glimit'):
        await limit_roll_chat(message)
    elif text.startswith('/givem'):
        await admin_give_licensy(message)
    elif text.startswith('/givevip'):
        await admin_give_vip_licensy(message)
    elif text.startswith('/plimit'):
        await admin_give_user_unlim(message)
    elif text.startswith('/history'):
        await admin_give_history(message)
    elif text.startswith('/tops'):
        await admin_give_tops(message)
    elif text.startswith('/owlt'):
        await admin_off_roll(message)
    elif text.startswith('/oltr'):
        await admin_off_words(message)
    elif text.startswith('/offTops'):
        await admin_off_tops(message)
    elif text.startswith('/owl'):
        await admin_off_bot(message)
    elif text.startswith('!кик') or text.startswith('!проветрись') or text.startswith('!отдохни') or \
            text.startswith('!душный'):
        if message.reply_to_message:
            await kick_user(message)
        else:
            pass
    elif text.startswith('!бан') or text.startswith('!небольшой расход') or text.startswith('!выйди нахуй') or \
            text.startswith('!съебался'):
        if message.reply_to_message:
            await ban_user(message)
        else:
            pass
    elif text.startswith('!текст') or text.startswith('!медиа') or text.startswith('!без порно'):
        if message.reply_to_message:
            await only_text_user(message)
        else:
            pass
    elif text.startswith('!мут') or text.startswith('!завались') or text.startswith('!минус ебало') or \
            text.startswith('!набрал воды'):
        if message.reply_to_message:
            await mut_user(message)
        else:
            pass

    else:
        await all_handlers(message)


# Profile menu
async def _main_admin_pars(message: types.Message):
    text = message.text
    if text.startswith('/ban'):
        await admin_ban_user(message)
    elif text.startswith('/unban'):
        await admin_unban_user(message)
    elif text.startswith('/giveadmine'):
        await give_main_admin(message)
    elif text.startswith('/giveadmin'):
        await give_admin(message)
    elif text.startswith('/nogiveadmin') or text.startswith('/nogiveadmine'):
        await delete_admin(message)
    elif text.startswith('/gban'):
        await ban_chat(message)
    elif text.startswith('/gunban'):
        await unban_chat(message)
    elif text.startswith('/glimit'):
        await limit_roll_chat(message)
    elif text.startswith('/givem'):
        await admin_give_licensy(message)
    elif text.startswith('/givevip'):
        await admin_give_vip_licensy(message)
    elif text.startswith('/givecoin'):
        await admin_give_coin(message)
    elif text.startswith('/plimit'):
        await admin_give_user_unlim(message)
    elif text.startswith('/history'):
        await admin_give_history(message)
    elif text.startswith('/tops'):
        await admin_give_tops(message)
    elif text.startswith('/owlt'):
        await admin_off_roll(message)
    elif text.startswith('/oltr'):
        await admin_off_words(message)
    elif text.startswith('/offTops'):
        await admin_off_tops(message)
    elif text.startswith('/owl'):
        await admin_off_bot(message)
    elif text.startswith('/give status'):
        await admin_give_status(message)
    elif text.startswith('/give pstatus'):
        await admin_give_text_status(message)
    elif text.startswith('/del status'):
        await admin_del_status(message)
    elif text.startswith('/give title'):
        await admin_give_titul(message)
    elif text.startswith('/del title'):
        await admin_del_tituls(message)
    elif text.startswith('!кик') or text.startswith('!проветрись') or text.startswith('!отдохни') or \
            text.startswith('!душный'):
        if message.reply_to_message:
            await kick_user(message)
        else:
            pass
    elif text.startswith('!бан') or text.startswith('!небольшой расход') or text.startswith('!выйди нахуй') or \
            text.startswith('!съебался'):
        if message.reply_to_message:
            await ban_user(message)
        else:
            pass
    elif text.startswith('!текст') or text.startswith('!медиа') or text.startswith('!без порно'):
        if message.reply_to_message:
            await only_text_user(message)
        else:
            pass
    elif text.startswith('!мут') or text.startswith('!завались') or text.startswith('!минус ебало') or \
            text.startswith('!набрал воды'):
        if message.reply_to_message:
            await mut_user(message)
        else:
            pass
    else:
        await all_handlers(message)


# Збанить пользователя
async def admin_ban_user(message: types.Message):
    text = message.text
    try:
        user_id = text.split('/ban ')[1]
        if user_id.isdigit():
            user_data = sqLite.read_values_by_name(table=f'all_users', data=user_id)
            if user_data is None:
                await message.answer("Пользователь не зарегистрирован")
            elif user_data[7] == "active":
                sqLite.insert_info(table=f'all_users', name='status', data='ban', telegram_id=user_id)
                await message.answer("Пользователь забанен")
            elif user_data[7] == "ban":
                await message.answer("Пользователь находится в бане")
            else:
                await message.answer("Пользователя нельзя забанить")
        else:
            await message.answer("Ошибка ввода данных\nПример:/ban 123456789")
    except:
        pass


# Разбанить пользователя
async def admin_unban_user(message: types.Message):
    text = message.text
    try:
        user_id = text.split('/unban ')[1]
        if user_id.isdigit():
            user_data = sqLite.read_values_by_name(table=f'all_users', data=user_id)
            if user_data is None:
                await message.answer("Пользователь не зарегистрирован")
            elif user_data[7] == "ban":
                sqLite.insert_info(table=f'all_users', name='status', data='active', telegram_id=user_id)
                await message.answer("Пользователь разбанен")
            elif user_data[7] == "active":
                await message.answer("Пользователь не находится в бане")
            else:
                await message.answer("Пользователя нельзя забанить")
        else:
            await message.answer("Ошибка ввода данных\nПример:/unban 123456789")
    except:
        pass


# Дать младшего админа
async def give_admin(message: types.Message):
    text = message.text
    try:
        user_id = text.split('/giveadmin ')[1]
        if user_id.isdigit():
            user_data = sqLite.read_values_by_name(table=f'all_users', data=user_id)
            if user_data is None:
                await message.answer("Пользователь не зарегистрирован")
            elif user_data[7] == "admin":
                await message.answer("Пользователь является администратором")
            else:
                sqLite.insert_info(table=f'all_users', name='status', data='admin', telegram_id=user_id)
                await message.answer("Пользователь назначен администратором")
        else:
            await message.answer("Ошибка ввода данных\nПример:/ban 123456789")
    except:
        pass


# Забрать младшего/старшего админа
async def delete_admin(message: types.Message):
    text = message.text
    try:
        user_id = text.split(' ')[1]
        if user_id.isdigit():
            user_data = sqLite.read_values_by_name(table=f'all_users', data=user_id)
            if user_data is None:
                await message.answer("Пользователь не зарегистрирован")
            elif user_data[7] == "active":
                await message.answer("Пользователь не является администратором")
            else:
                sqLite.insert_info(table=f'all_users', name='status', data='active', telegram_id=user_id)
                await message.answer("Пользователь удален из администраторов")
        else:
            await message.answer("Ошибка ввода данных\nПример:/ban 123456789")
    except:
        pass


# Дать старшего админа
async def give_main_admin(message: types.Message):
    text = message.text
    try:
        user_id = text.split('/giveadmine ')[1]
        if user_id.isdigit():
            user_data = sqLite.read_values_by_name(table=f'all_users', data=user_id)
            if user_data is None:
                await message.answer("Пользователь не зарегистрирован")
            elif user_data[7] == "mainAdmin":
                await message.answer("Пользователь является старшим администратором")
            else:
                sqLite.insert_info(table=f'all_users', name='status', data='mainAdmin', telegram_id=user_id)
                await message.answer("Пользователь назначен старшим администратором")
        else:
            await message.answer("Ошибка ввода данных\nПример:/ban 123456789")
    except:
        pass


# Бан группы
async def ban_chat(message: types.Message):
    text = message.text
    try:
        chat_id = text.split('/gban ')[1]
        if '-' in str(chat_id):
            user_data = sqLite.read_values_by_name(table=f'chats', data=str(chat_id), id_name='chat_id')
            if user_data is None:
                await message.answer("Группа с данным ID не найдена")
            elif user_data[3] == "ban":
                sqLite.insert_info(table=f'chats', name='status', data='active', telegram_id=chat_id, id_name='chat_id')
                await message.answer("Группа успешно разбанена")
            else:
                sqLite.insert_info(table=f'chats', name='status', data='ban', telegram_id=chat_id, id_name='chat_id')
                await message.answer("Группа успешно забанена")
        else:
            await message.answer("Ошибка ввода данных\nПример:/gban -123456789")
    except:
        pass


# РАЗБан группы
async def unban_chat(message: types.Message):
    text = message.text
    try:
        chat_id = text.split('/gunban ')[1]
        if '-' in str(chat_id):
            user_data = sqLite.read_values_by_name(table=f'chats', data=str(chat_id), id_name='chat_id')
            if user_data is None:
                await message.answer("Группа с данным ID не найдена")
            elif user_data[3] == "active":
                await message.answer("Группа не находится в бане")
            else:
                sqLite.insert_info(table=f'chats', name='status', data='active', telegram_id=chat_id, id_name='chat_id')
                await message.answer("Группа успешно разбанена")
        else:
            await message.answer("Ошибка ввода данных\nПример:/gunban -123456789")
    except:
        pass


# Снять лимиты в группе на рулетку
async def limit_roll_chat(message: types.Message):
    text = message.text
    try:
        chat_id = text.split('/glimit ')[1]
        if '-' in str(chat_id):
            user_data = sqLite.read_values_by_name(table=f'chats', data=str(chat_id), id_name='chat_id')
            if user_data is None:
                await message.answer("Группа с данным ID не найдена")
            elif user_data[2] == "0":
                await message.answer("Ограничения на рулетку сняты")
            else:
                sqLite.insert_info(table=f'chats', name='limits_rol', data='0', telegram_id=chat_id, id_name='chat_id')
                await message.answer("Вы приобрели снятие ограничения на рулетку")
        else:
            await message.answer("Ошибка ввода данных\nПример:/glimit -123456789")
    except:
        pass


# Дать лицензию простую
async def admin_give_licensy(message: types.Message):
    text = message.text
    try:

        if len(text.split(' ')) == 3:
            user_id = text.split(' ')[1]
            number_l = text.split(' ')[2]
            if user_id.isdigit() and number_l.isdigit():
                user_data = sqLite.read_values_by_name(table=f'all_users', data=user_id)
                if user_data is None:
                    await message.answer("Пользователь не зарегистрирован")
                else:
                    sqLite.insert_info(table=f'all_users', name='license', data=user_data[11] + int(number_l),
                                       telegram_id=user_id)
                    await message.answer(f"Вы успешно выдали {number_l} лицензий")

            else:
                await message.answer("Ошибка ввода данных\nПример:/givem 123456789 10")
        else:
            pass
    except:
        pass


# Дать VIP лицензию простую
async def admin_give_vip_licensy(message: types.Message):
    text = message.text
    try:

        if len(text.split(' ')) == 3:
            user_id = text.split(' ')[1]
            number_l = text.split(' ')[2]
            if user_id.isdigit() and number_l.isdigit():
                user_data = sqLite.read_values_by_name(table=f'all_users', data=user_id)
                if user_data is None:
                    await message.answer("Пользователь не зарегистрирован")
                else:
                    sqLite.insert_info(table=f'all_users', name='license_vip', data=user_data[14] + int(number_l),
                                       telegram_id=user_id)
                    await message.answer(f"Вы успешно выдали {number_l} VIP лицензий")

            else:
                await message.answer("Ошибка ввода данных\nПример:/givevip 123456789 10")
        else:
            pass
    except:
        pass


# Дать монет
async def admin_give_coin(message: types.Message):
    text = message.text
    try:

        if len(text.split(' ')) == 3:
            user_id = text.split(' ')[1]
            number_l = text.split(' ')[2]
            if user_id.isdigit() and number_l.isdigit():
                user_data = sqLite.read_values_by_name(table=f'all_users', data=user_id)
                if user_data is None:
                    await message.answer("Пользователь не зарегистрирован")
                else:
                    sqLite.insert_info(table=f'all_users', name='money', data=user_data[2] + int(number_l),
                                       telegram_id=user_id)
                    await message.answer(f"Вы успешно выдали {number_l} монет")

            else:
                await message.answer("Ошибка ввода данных\nПример:/givecoin 1000000")
        else:
            pass
    except:
        pass


# Снять лимит игроку
async def admin_give_user_unlim(message: types.Message):
    text = message.text
    try:

        if len(text.split(' ')) == 2:
            user_id = text.split(' ')[1]
            if user_id.isdigit():
                user_data = sqLite.read_values_by_name(table=f'all_users', data=user_id)
                if user_data is None:
                    await message.answer("Пользователь не зарегистрирован")
                else:
                    sqLite.insert_info(table=f'all_users', name='gift_time', data='1',
                                       telegram_id=user_id)
                    await message.answer(f"Вы успешно сняли лимит для {user_data[10]}")

            else:
                await message.answer("Ошибка ввода данных\nПример:/plimit 123456789")
        else:
            pass
    except:
        pass


# Показывает историю игрока
async def admin_give_history(message: types.Message):
    text = message.text
    try:
        if len(text.split(' ')) == 2:
            user_id = text.split(' ')[1]
            if user_id.isdigit():
                chat_data = sqLite.read_all(table=f'log{user_id}')
                if len(chat_data) > 40:
                    iteration = len(chat_data) - 40
                    for i in range(0, iteration):
                        id = chat_data[i][0]
                        sqLite.delete_str(table=f'log{user_id}', name='id', data=id)
                else:
                    pass

                text = ''
                chat_data = sqLite.read_all_log_sort(table=f'log{user_id}')
                for line in chat_data:
                    text = text + f"[{str(line[5]).split(' ')[1]}] {line[1]}: {line[2]}: {line[3]}: {line[4]}: \n"
                if text == '':
                    text = 'У пользователя нет записей'
                await message.answer(text=f"{text}", parse_mode='html')

            else:
                await message.answer("Ошибка ввода данных\nПример:/history 123456789")
        else:
            pass
    except:
        pass


# Показывает топ богатых по всем чатам
async def admin_give_tops(message: types.Message):
    text = '<b>Топ богачей бота:</b>\n'
    top_big_many = sqLite.give_top_bigmany()
    i = 0
    for user in top_big_many:
        text = text + f"{user[10]} : {user[2]}\n"
        i += 1
        if i > 30:
            break
    await message.answer(text=text, parse_mode='html')


# Кикнуть из группы без черного списка
async def kick_user(message: types.Message):
    chat_id = message.chat.id
    victem_id = message.reply_to_message.from_user.id
    try:
        await bot.ban_chat_member(chat_id=chat_id, user_id=victem_id)
        await bot.unban_chat_member(chat_id=chat_id, user_id=victem_id)
        await message.answer(f'{message.reply_to_message.from_user.first_name} прогнали на улицу.')
    except:
        await message.answer('Назначьте бота админом')


# бан
async def ban_user(message: types.Message):
    chat_id = message.chat.id
    victem_id = message.reply_to_message.from_user.id
    if '/' in message.text:
        try:
            minut = int(message.text.split('/')[1])
            hours = message.text.split(' ')[1]
            hours = int(hours.split('/')[0])
            ban_time = datetime.timedelta(hours=hours, minutes=minut)
            await bot.ban_chat_member(chat_id=chat_id, user_id=victem_id, until_date=ban_time)
            await message.answer(f'{message.reply_to_message.from_user.first_name} был забанен на {hours}ч '
                                 f'{minut}мин.')
        except:
            await message.answer('Назначьте бота админом либо не верно введены параметры времени h/m')
    else:
        try:
            await bot.ban_chat_member(chat_id=chat_id, user_id=victem_id)
            await message.answer(f'{message.reply_to_message.from_user.first_name} был забанен навсегда.')
        except:
            await message.answer('Назначьте бота админом')


# Запрещает отправку медиа
async def only_text_user(message: types.Message):
    chat_id = message.chat.id
    victem_id = message.reply_to_message.from_user.id
    if '/' in message.text:
        try:
            minut = int(message.text.split('/')[1])
            hours = message.text.split(' ')[1]
            hours = int(hours.split('/')[0])
            ban_time = datetime.datetime.now() + datetime.timedelta(hours=hours, minutes=minut)
            await bot.restrict_chat_member(chat_id=chat_id, user_id=victem_id, until_date=ban_time, can_send_messages=True)
            await message.answer(f'{message.reply_to_message.from_user.first_name} может писать только текстовые '
                                 f'сообщения в течении {hours}ч {minut}мин.')
        except:
            await message.answer('Назначьте бота админом либо не верно введены параметры времени h/m')
    else:
        try:
            await bot.restrict_chat_member(chat_id=chat_id, user_id=victem_id, can_send_messages=True)
            await message.answer(f'{message.reply_to_message.from_user.first_name} может писать только текстовые сообщения.')
        except:
            await message.answer('Назначьте бота админом')


# Запрещает отправку сообщений
async def mut_user(message: types.Message):
    chat_id = message.chat.id
    victem_id = message.reply_to_message.from_user.id
    if '/' in message.text:
        try:
            minut = int(message.text.split('/')[1])
            hours = message.text.split(' ')[1]
            hours = int(hours.split('/')[0])
            ban_time = datetime.datetime.now() + datetime.timedelta(hours=hours, minutes=minut)
            await bot.restrict_chat_member(chat_id=chat_id, user_id=victem_id, until_date=ban_time)
            await message.answer(f'{message.reply_to_message.from_user.first_name} затихнет на {hours}ч {minut}мин.')
        except:
            await message.answer('Назначьте бота админом либо не верно введены параметры времени h/m')
    else:
        try:
            await bot.restrict_chat_member(chat_id=chat_id, user_id=victem_id)
            await message.answer(f'{message.reply_to_message.from_user.first_name} затихнет навсегда.')
        except:
            await message.answer('Назначьте бота админом')


# Вкл/выкл рулетку
async def admin_off_roll(message: types.Message):
    chat_id = message.chat.id
    chat_data = sqLite.read_values_by_name(table=f'chats', data=str(chat_id), id_name='chat_id')[4]
    if chat_data == 0:
        sqLite.insert_info(table=f'chats', name='off_roll', data=1, telegram_id=str(chat_id), id_name='chat_id')
        await message.answer('Рулетка в этом чате запрещена')
    elif chat_data == 1:
        sqLite.insert_info(table=f'chats', name='off_roll', data=0, telegram_id=str(chat_id), id_name='chat_id')
        await message.answer('Рулетка в этом чате разрешена')


# Вкл/выкл буквы
async def admin_off_words(message: types.Message):
    chat_id = message.chat.id
    chat_data = sqLite.read_values_by_name(table=f'chats', data=str(chat_id), id_name='chat_id')[5]
    if chat_data == 0:
        sqLite.insert_info(table=f'chats', name='off_words', data=1, telegram_id=str(chat_id), id_name='chat_id')
        await message.answer('Буквы в этом чате запрещены')
    elif chat_data == 1:
        sqLite.insert_info(table=f'chats', name='off_words', data=0, telegram_id=str(chat_id), id_name='chat_id')
        await message.answer('Буквы в этом чате разрешены')


# Вкл/выкл топы
async def admin_off_tops(message: types.Message):
    chat_id = message.chat.id
    chat_data = sqLite.read_values_by_name(table=f'chats', data=str(chat_id), id_name='chat_id')[6]
    if chat_data == 0:
        sqLite.insert_info(table=f'chats', name='off_tops', data=1, telegram_id=str(chat_id), id_name='chat_id')
        await message.answer('Теперь я слушаюсь только администраторов чата')
    elif chat_data == 1:
        sqLite.insert_info(table=f'chats', name='off_tops', data=0, telegram_id=str(chat_id), id_name='chat_id')
        await message.answer('Теперь я слушаюсь всех пользователей')


# Вкл/выкл бот в чате
async def admin_off_bot(message: types.Message):
    chat_id = message.chat.id
    chat_data = sqLite.read_values_by_name(table=f'chats', data=str(chat_id), id_name='chat_id')[7]
    if chat_data == 0:
        sqLite.insert_info(table=f'chats', name='off_bot', data=1, telegram_id=str(chat_id), id_name='chat_id')
        await message.answer('Сова уснула,не буди ее')
    elif chat_data == 1:
        sqLite.insert_info(table=f'chats', name='off_bot', data=0, telegram_id=str(chat_id), id_name='chat_id')
        await message.answer('Сова проснулась,можешь играть')


# Даем статусы пользователю
async def admin_give_status(message: types.Message):
    chat_id = message.chat.id
    if len(message.text.split(' ')) == 4:
        status_number = message.text.split(' ')[3]
        tg_id = message.text.split(' ')[2]
        if status_number.isdigit() and tg_id.isdigit():
            now = str(datetime.datetime.now()).split('.')[0]
            user_data = sqLite.read_values_by_name(table='all_users', data=tg_id)
            if user_data is None:
                await message.answer('Пользователь не зарегистрирован')
            else:
                if int(status_number) == 1:
                    sqLite.insert_info(table=f'all_users', name='status_day', data=now, telegram_id=tg_id)
                    sqLite.insert_info(table=f'all_users', name='money', data=user_data[2] + 50000, telegram_id=tg_id)
                    sqLite.ins_log(tg_id=str(tg_id), info='Начисление за статус Дневной', money="+50,000",
                                   chanel_id=chat_id)
                    await message.answer('Выдан статус Дневной')

                elif int(status_number) == 2:
                    sqLite.insert_info(table=f'all_users', name='status_night', data=now, telegram_id=tg_id)
                    sqLite.insert_info(table=f'all_users', name='money', data=user_data[2] + 100000, telegram_id=tg_id)
                    sqLite.ins_log(tg_id=str(tg_id), info='Начисление за статус Ночной', money="+100,000",
                                   chanel_id=chat_id)
                    await message.answer('Выдан статус Ночной')

                elif int(status_number) == 3:
                    sqLite.insert_info(table=f'all_users', name='status_king', data=now, telegram_id=tg_id)
                    sqLite.insert_info(table=f'all_users', name='money', data=user_data[2] + 500000, telegram_id=tg_id)
                    sqLite.ins_log(tg_id=str(tg_id), info='Начисление за статус Королевский', money="+500,000",
                                   chanel_id=chat_id)
                    await message.answer('Выдан статус Королевский')

                elif int(status_number) == 4:
                    sqLite.insert_info(table=f'all_users', name='status_firm', data=now, telegram_id=tg_id)
                    sqLite.insert_info(table=f'all_users', name='money', data=user_data[2] + 1000000, telegram_id=tg_id)
                    sqLite.ins_log(tg_id=str(tg_id), info='Начисление за статус Фирменный', money="+1,000,000",
                                   chanel_id=chat_id)
                    await message.answer('Выдан статус Фирменный')

                elif int(status_number) == 5:
                    sqLite.insert_info(table=f'all_users', name='status_dekor', data=now, telegram_id=tg_id)
                    sqLite.ins_log(tg_id=str(tg_id), info='Получен статус Декоративный', money="-679 RUR",
                                   chanel_id=chat_id)
                    await message.answer('Выдан статус Декоративный')

        else:
            pass
    else:
        pass


# Даем статус текстовый
async def admin_give_text_status(message: types.Message):
    chat_id = message.chat.id
    if len(message.text.split(' ')) == 4:
        status_text = message.text.split(' ')[3]
        tg_id = message.text.split(' ')[2]
        if tg_id.isdigit():
            now = str(datetime.datetime.now()).split('.')[0]
            user_data = sqLite.read_values_by_name(table='all_users', data=tg_id)
            if user_data is None:
                await message.answer('Пользователь не зарегистрирован')
            else:
                if status_text != '':
                    sqLite.insert_info(table=f'all_users', name='status_text', data=status_text, telegram_id=tg_id)
                    sqLite.ins_log(tg_id=str(tg_id), info=f'Выдан статус {status_text}', money="text_STATUS",
                                   chanel_id=chat_id)
                    await message.answer(f'Выдан статус {status_text} {status_text}')
        else:
            pass
    else:
        pass


# Удаляет все статусы пользователю
async def admin_del_status(message: types.Message):
    chat_id = message.chat.id
    if len(message.text.split(' ')) == 3:
        tg_id = message.text.split(' ')[2]
        if tg_id.isdigit():
            user_data = sqLite.read_values_by_name(table='all_users', data=tg_id)
            if user_data is None:
                await message.answer('Пользователь не зарегистрирован')
            else:
                sqLite.insert_info(table=f'all_users', name='status_day', data=0, telegram_id=tg_id)
                sqLite.insert_info(table=f'all_users', name='status_night', data=0, telegram_id=tg_id)
                sqLite.insert_info(table=f'all_users', name='status_king', data=0, telegram_id=tg_id)
                sqLite.insert_info(table=f'all_users', name='status_firm', data=0, telegram_id=tg_id)
                sqLite.insert_info(table=f'all_users', name='status_dekor', data=0, telegram_id=tg_id)
                sqLite.insert_info(table=f'all_users', name='status_text', data='0', telegram_id=tg_id)
                sqLite.ins_log(tg_id=str(tg_id), info='cтатусы удалены', money="delete", chanel_id=chat_id)
                await message.answer('Все статусы удалены!')


        else:
            pass
    else:
        pass


# Пишем титулы в базу данных
def write_titule(user_id: int, name: str):
    data = sqLite.read_values_by_name(table='all_users', data=user_id, name=name)[0]
    sqLite.insert_info(table=f'all_users', name=name, data=data + 1, telegram_id=user_id)


# Даем титул пользователю
async def admin_give_titul(message: types.Message):
    chat_id = message.chat.id
    if len(message.text.split(' ')) == 4:
        status_number = message.text.split(' ')[3]
        tg_id = message.text.split(' ')[2]
        if status_number.isdigit() and tg_id.isdigit():
            user_data = sqLite.read_values_by_name(table='all_users', data=tg_id)
            if user_data is None:
                await message.answer('Пользователь не зарегистрирован')
            else:
                if int(status_number) == 1:
                    write_titule(user_id=int(tg_id), name='titul_chat')
                    sqLite.ins_log(tg_id=str(tg_id), info='Выдан титул Битва Чатов 🏆', money="titule",
                                   chanel_id=chat_id)
                    await message.answer('Выдан титул Битва Чатов 🏆')

                elif int(status_number) == 2:
                    write_titule(user_id=int(tg_id), name='titul_newman')
                    sqLite.ins_log(tg_id=str(tg_id), info='Выдан титул Турнир "Новички" 🏆', money="titule",
                                   chanel_id=chat_id)
                    await message.answer('Выдан титул Турнир "Новички" 🏆')

                elif int(status_number) == 3:
                    write_titule(user_id=int(tg_id), name='titul_simple')
                    sqLite.ins_log(tg_id=str(tg_id), info='Выдан титул Турнир «Продвинутые» 🏆', money="titule",
                                   chanel_id=chat_id)
                    await message.answer('Выдан титул Турнир «Продвинутые» 🏆')

                elif int(status_number) == 4:
                    write_titule(user_id=int(tg_id), name='titul_pro')
                    sqLite.ins_log(tg_id=str(tg_id), info='Выдан титул Турнир «Профи» 🏆', money="titule",
                                   chanel_id=chat_id)
                    await message.answer('Выдан титул Турнир «Профи» 🏆')

                elif int(status_number) == 5:
                    write_titule(user_id=int(tg_id), name='titul_couple')
                    sqLite.ins_log(tg_id=str(tg_id), info='Выдан титул Конкурс «Пара Месяца» 🏆', money="titule",
                                   chanel_id=chat_id)
                    await message.answer('Выдан титул Конкурс «Пара Месяца» 🏆')

        else:
            pass
    else:
        pass


# Удаляет все статусы пользователю
async def admin_del_tituls(message: types.Message):
    chat_id = message.chat.id
    if len(message.text.split(' ')) == 3:
        tg_id = message.text.split(' ')[2]
        if tg_id.isdigit():
            user_data = sqLite.read_values_by_name(table='all_users', data=tg_id)
            if user_data is None:
                await message.answer('Пользователь не зарегистрирован')
            else:
                sqLite.insert_info(table=f'all_users', name='titul_chat', data=0, telegram_id=tg_id)
                sqLite.insert_info(table=f'all_users', name='titul_newman', data=0, telegram_id=tg_id)
                sqLite.insert_info(table=f'all_users', name='titul_simple', data=0, telegram_id=tg_id)
                sqLite.insert_info(table=f'all_users', name='titul_pro', data=0, telegram_id=tg_id)
                sqLite.insert_info(table=f'all_users', name='titul_couple', data=0, telegram_id=tg_id)
                sqLite.ins_log(tg_id=str(tg_id), info='титулы удалены', money="delete", chanel_id=chat_id)
                await message.answer('Все титулы удалены!')


        else:
            pass
    else:
        pass
