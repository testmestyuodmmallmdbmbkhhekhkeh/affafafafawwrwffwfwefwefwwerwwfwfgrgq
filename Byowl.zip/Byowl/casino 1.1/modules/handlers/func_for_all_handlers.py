from aiogram import types
from modules.dispatcher import bot
from modules.handlers.casino.ruletka import callS_ruletka, ruletka, on_red, on_zero_mes, on_number_mes, on_range_mes, \
    on_range_short_mes, func_start_mes, func_double_mes, func_repitt_mes, my_deals, delete_all_mes, on_black, \
    func_start_mes_go
from modules.handlers.casino.stolen import stolen
from modules.handlers.casino.history import history
from modules.handlers.casino.raffle import raffle, pars_calls_raffle
from modules.handlers.casino.titule_filin import titule_filin, get_filins
from modules.handlers.casino.ignor import ignore
from modules.handlers.casino.tops import top_money, top_deal, top_millioners, top_loos, top_max_income, \
    top_words_score, top_words_lengs, top_roll_day
from modules.handlers.casino.gift import gift
from modules.handlers.casino.sertificat import send_weding_sertificat
from modules.handlers.casino.duel import duel, call_duel, main_duel, death_duel, close_duel
from modules.handlers.casino.xo import xo, call_xo, main_xo, close_xo, close_xo_on_start
from modules.handlers.casino.words import create_words, call_words, check_words, close_words, close_words_on_start
from modules.handlers.casino.weding import wedding, call_wedding
from modules.handlers.casino.weding_vip import wedding_vip, call_wedding_vip
from modules.handlers.casino.divorce import divorce, divorce_rep, call_divorce
from modules.handlers.casino.market import pars_calls_market


async def all_handlers(message: types.Message):
    if message.text.lower() == '!рулетка':
        await ruletka(message)
    elif message.text.lower() == 'рулетка' or message.text.lower() == '!рулетка':
        await ruletka(message)
    elif message.text.lower().startswith('!дуэль') or message.text.lower().startswith('дуэль'):
        if len(message.text.split(' ')) == 2:
            if not message.reply_to_message:
                await duel(message)
            else:
                rep_tg_id = message.reply_to_message.from_user.id
                await duel(message, rep_tg_id)

    elif message.text.lower().startswith('!крестики') or message.text.lower().startswith('крестики'):
        if len(message.text.split(' ')) == 2:
            if not message.reply_to_message:
                await xo(message)
            else:
                rep_tg_id = message.reply_to_message.from_user.id
                await xo(message, rep_tg_id)

    elif message.text.lower().startswith('!буквы') or message.text.lower() == 'буквы':
        if not message.reply_to_message:
            await create_words(message)
        else:
            rep_tg_id = message.reply_to_message.from_user.id
            await create_words(message, rep_tg_id)

    elif message.text.lower().startswith('!розыгрыш'):
        if len(message.text.split(' ')) == 2:
            if message.reply_to_message:
                pass
            else:
                await raffle(message)
    elif message.text.startswith('-'):
        if (message.text.split('-')[1]).isdigit():
            if len(message.text.split('-')) == 2:
                if not message.reply_to_message:
                    pass
                else:
                    await stolen(message)
    elif message.text.startswith('+'):
        if (str(message.text.split(' ')[0])[1:]).isdigit():
            if len(message.text.split('+')) == 2:
                if not message.reply_to_message:
                    pass
                else:
                    await gift(message)
    elif (message.text.split(' ')[0]).isdigit():
        if 'на к' in message.text.lower():
            await on_red(message)
        elif 'к' in message.text.lower():
            await on_red(message)
        elif 'на ч' in message.text.lower():
            await on_black(message)
        elif 'ч' in message.text.lower():
            await on_black(message)
        elif ' на ' in message.text:
            if message.text.split(' на ')[0].isdigit():
                if message.text.split(' на ')[1].isdigit():
                    if 0 < int(message.text.split(' на ')[1]) < 13:
                        await on_number_mes(message)
                    else:
                        if 'на 0' in message.text:
                            await on_zero_mes(message)
                        else:
                            pass
                elif '-' in message.text.split(' на ')[1]:
                    await on_range_mes(message)
                else:
                    print(message.text)
        elif '-' in str(message.text.split(' ')[1]):
            await on_range_short_mes(message)

        elif ' 0' in message.text:
            await on_zero_mes(message)
        elif message.text.split(' ')[1].isdigit():
            data = message.text.split(' ')[1]
            try:
                if 0 < int(message.text.split(' ')[1]) < 13:
                    await on_number_mes(message)
                elif '-' in str(data):
                    await on_range_short_mes(message)
                else:
                    pass
            except:
                pass

    elif 'го' == message.text.lower():
        await func_start_mes_go(message)
    elif 'вертеть' == message.text.lower():
        await func_start_mes(message)
    elif 'крутить' == message.text.lower():
        await func_start_mes(message)
    elif 'поехали' == message.text.lower():
        await func_start_mes(message)
    elif 'go' == message.text.lower():
        await func_start_mes(message)
    elif 'удвоить' == message.text.lower():
        await func_double_mes(message)
    elif 'повторить' == message.text.lower():
        await func_repitt_mes(message)
    elif 'ставки' == message.text.lower():
        await my_deals(message)
    elif 'отмена' == message.text.lower():
        await delete_all_mes(message)
    elif 'отменить' == message.text.lower():
        await delete_all_mes(message)
    elif '!свадьба' == message.text.lower():
        await wedding(message)
    elif 'свадьба' == message.text.lower():
        await wedding(message)
    elif '!свадьба vip' == message.text.lower():
        await wedding_vip(message)
    elif '!свадьба v' == message.text.lower():
        await wedding_vip(message)
    elif '!свадьба vipowl' == message.text.lower():
        await wedding_vip(message)
    elif 'свадьба vip' == message.text.lower():
        await wedding_vip(message)
    elif 'свадьба v' == message.text.lower():
        await wedding_vip(message)
    elif 'свадьба vipowl' == message.text.lower():
        await wedding_vip(message)
    elif '!сдаться' == message.text.lower():
        await close_words(message)
    elif '!развод' == message.text.lower() or '!развод vip' == message.text.lower():
        if not message.reply_to_message:
            await divorce(message)
        else:
            await divorce_rep(message)
    elif message.text == 'бот игнор':
        if not message.reply_to_message:
            pass
        else:
            await ignore(message)
    elif message.text.lower() == 'история':
        await history(message)
    elif message.text.lower() == '!топ':
        await top_money(message)
    elif message.text.lower() == 'топ ставки':
        await top_deal(message)
    elif message.text.lower() == 'топ выиграно':
        await top_millioners(message)
    elif message.text.lower() == 'топ проиграно':
        await top_loos(message)
    elif message.text.lower() == 'топ выигрышей':
        await top_max_income(message)
    elif message.text.lower() == '!топ буквы':
        await top_words_score(message)
    elif message.text.lower() == '!топ слово':
        await top_words_lengs(message)
    elif message.text.lower() == 'рекорды рулетки дня':
        await top_roll_day(message)
    elif message.text.lower() == 'титулы':
        await get_filins(message)
    elif 'дня' in message.text:
        if message.text.startswith('!'):
            await titule_filin(message)
    else:
        await check_words(message)


# Profile menu
async def all_cals(call: types.CallbackQuery):
    if str(call.data).startswith('ruletka_'):
        await callS_ruletka(call)
    elif str(call.data).startswith('s_duel_'):
        await call_duel(call)
    elif str(call.data).startswith('live'):
        await main_duel(call)
    elif str(call.data).startswith('death'):
        await death_duel(call)
    elif str(call.data).startswith('close_duel'):
        await close_duel(call)
    elif str(call.data).startswith('s_xo_'):
        await call_xo(call)
    elif str(call.data).startswith('x_'):
        await main_xo(call)
    elif str(call.data).startswith('close_x_'):
        await close_xo(call)
    elif str(call.data).startswith('s_xo_close_'):
        await close_xo_on_start(call)
    elif str(call.data).startswith('s_words'):
        if call.from_user.id == int(call.data.split('_')[3]):
            await bot.answer_callback_query(call.id)
        else:
            await call_words(call)
    elif str(call.data).startswith('close_words'):
        await close_words(call)
    elif str(call.data).startswith('words_closeons_'):
        await close_words_on_start(call)
    elif str(call.data).startswith('wedding_'):
        await call_wedding(call)
    elif str(call.data).startswith('wedvip_'):
        await call_wedding_vip(call)
    elif str(call.data).startswith('divorce_'):
        await call_divorce(call)
    elif str(call.data).startswith('market_'):
        await pars_calls_market(call)
    elif str(call.data).startswith('raffle_'):
        await pars_calls_raffle(call)
    else:
        await bot.answer_callback_query(call.id)
        print(call.data)
