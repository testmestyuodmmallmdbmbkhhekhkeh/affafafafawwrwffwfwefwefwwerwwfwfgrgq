from aiogram import types
from modules import sqLite


# Топ чата по монетам
async def top_money(message: types.Message):
    chat_id = str(message.chat.id)
    user_id = message.from_user.id
    user_data = sqLite.read_values_by_name(table=f'all_users', data=user_id)[7]
    off_tops = sqLite.read_values_by_name(table=f'chats', data=chat_id, id_name='chat_id')[6]
    if off_tops == 0 or 'dmin' in user_data:
        chat_data = sqLite.give_top_bigmany(table=f'chat{chat_id[1:]}')
        text = "<b>Топ по количеству монет </b>\n"
        i = 0
        for user in chat_data:
            i += 1
            text = text + f"{user[17]} : {user[6]}\n"
            if i > 100:
                break
        await message.answer(text=text, parse_mode='html')
    else:
        await message.answer("Топы в этом чате отключены")



# Топ чата по сумме ставок
async def top_deal(message: types.Message):
    chat_id = str(message.chat.id)
    user_id = message.from_user.id
    user_data = sqLite.read_values_by_name(table=f'all_users', data=user_id)[7]
    off_tops = sqLite.read_values_by_name(table=f'chats', data=chat_id, id_name='chat_id')[6]
    if off_tops == 0 or 'dmin' in user_data:
        chat_data = sqLite.give_top_bigmany(table=f'chat{chat_id[1:]}', sort_name='deal')
        text = "<b>Топ по сумме ставок </b>\n"
        i = 0
        for user in chat_data:
            i += 1
            text = text + f"{user[17]} : {user[7]}\n"
            if i > 100:
                break
        await message.answer(text=text, parse_mode='html')
    else:
        await message.answer("Топы в этом чате отключены")


# Топ чата самых везучих
async def top_millioners(message: types.Message):
    chat_id = str(message.chat.id)
    user_id = message.from_user.id
    user_data = sqLite.read_values_by_name(table=f'all_users', data=user_id)[7]
    off_tops = sqLite.read_values_by_name(table=f'chats', data=chat_id, id_name='chat_id')[6]
    if off_tops == 0 or 'dmin' in user_data:
        chat_data = sqLite.give_top_bigmany(table=f'chat{chat_id[1:]}', sort_name='income')
        text = "<b>Топ по сумме выигранных монет в рулетке.</b>\n"
        i = 0
        for user in chat_data:
            i += 1
            text = text + f"{user[17]} : {user[8]}\n"
            if i > 100:
                break
        await message.answer(text=text, parse_mode='html')
    else:
        await message.answer("Топы в этом чате отключены")


# Топ чата самых не везучих
async def top_loos(message: types.Message):
    chat_id = str(message.chat.id)
    user_id = message.from_user.id
    user_data = sqLite.read_values_by_name(table=f'all_users', data=user_id)[7]
    off_tops = sqLite.read_values_by_name(table=f'chats', data=chat_id, id_name='chat_id')[6]
    if off_tops == 0 or 'dmin' in user_data:
        chat_data = sqLite.give_top_bigmany(table=f'chat{chat_id[1:]}', sort_name='outcome')
        text = "<b>Топ по сумме проигранных монет в рулетке.</b>\n"
        i = 0
        for user in chat_data:
            i += 1
            text = text + f"{user[17]} : {user[9]}\n"
            if i > 100:
                break
        await message.answer(text=text, parse_mode='html')
    else:
        await message.answer("Топы в этом чате отключены")


# Топ максимальных выигрышей монет в рулетке за одну прокрутку.
async def top_max_income(message: types.Message):
    chat_id = str(message.chat.id)
    user_id = message.from_user.id
    user_data = sqLite.read_values_by_name(table=f'all_users', data=user_id)[7]
    off_tops = sqLite.read_values_by_name(table=f'chats', data=chat_id, id_name='chat_id')[6]
    if off_tops == 0 or 'dmin' in user_data:
        chat_data = sqLite.give_top_bigmany(table=f'chat{chat_id[1:]}', sort_name='max_income')
        text = "<b>Топ максимальных выигрышей монет в рулетке за одну прокрутку.</b>\n"
        i = 0
        for user in chat_data:
            i += 1
            text = text + f"{user[17]} : {user[10]}\n"
            if i > 100:
                break
        await message.answer(text=text, parse_mode='html')
    else:
        await message.answer("Топы в этом чате отключены")


# Топ по игре в буквы по очкам.
async def top_words_score(message: types.Message):
    chat_id = str(message.chat.id)
    user_id = message.from_user.id
    user_data = sqLite.read_values_by_name(table=f'all_users', data=user_id)[7]
    off_tops = sqLite.read_values_by_name(table=f'chats', data=chat_id, id_name='chat_id')[6]
    if off_tops == 0 or 'dmin' in user_data:
        chat_data = sqLite.give_top_bigmany(table=f'chat{chat_id[1:]}', sort_name='words_score')
        text = "<b>Топ очков за всё время в игру буквы</b>\n"
        i = 0
        for user in chat_data:
            i += 1
            text = text + f"{user[17]} : {user[11]}\n"
            if i > 100:
                break
        await message.answer(text=text, parse_mode='html')
    else:
        await message.answer("Топы в этом чате отключены")


# топ самых длинных использованных слов
async def top_words_lengs(message: types.Message):
    chat_id = str(message.chat.id)
    user_id = message.from_user.id
    user_data = sqLite.read_values_by_name(table=f'all_users', data=user_id)[7]
    off_tops = sqLite.read_values_by_name(table=f'chats', data=chat_id, id_name='chat_id')[6]
    if off_tops == 0 or 'dmin' in user_data:
        chat_data = sqLite.give_top_bigmany(table=f'chat{chat_id[1:]}', sort_name='words_len_word')
        text = "<b>Топ самых длинных использованных слов</b>\n"
        i = 0
        for user in chat_data:
            i += 1
            text = text + f"{user[17]} : {user[12]}\n"
            if i > 100:
                break
        await message.answer(text=text, parse_mode='html')
    else:
        await message.answer("Топы в этом чате отключены")


# Просмотр рекордов рулетки за сегодняшний день
async def top_roll_day(message: types.Message):
    chat_id = str(message.chat.id)
    user_id = message.from_user.id
    user_data = sqLite.read_values_by_name(table=f'all_users', data=user_id)[7]
    off_tops = sqLite.read_values_by_name(table=f'chats', data=chat_id, id_name='chat_id')[6]
    if off_tops == 0 or 'dmin' in user_data:
        chat_deal_day = sqLite.give_top_bigmany(table=f'chat{chat_id[1:]}', sort_name='deal_day')
        chat_income_day = sqLite.give_top_bigmany(table=f'chat{chat_id[1:]}', sort_name='income_day')
        chat_outcome_day = sqLite.give_top_bigmany(table=f'chat{chat_id[1:]}', sort_name='outcome_day')
        text_deal = "<b>Топ сделок за день</b>\n"
        text_income = "<b>Топ суммы выигрышей за день</b>\n"
        text_outcome = "<b>Топ суммы проигрышей за день</b>\n"
        i = 0
        for user in chat_deal_day:
            i += 1
            text_deal = text_deal + f"{user[17]} : {user[14]}\n"
            if i > 50:
                break
        i = 0
        for user in chat_income_day:
            i += 1
            text_income = text_income + f"{user[17]} : {user[15]}\n"
            if i > 50:
                break
        i = 0
        for user in chat_outcome_day:
            i += 1
            text_outcome = text_outcome + f"{user[17]} : {user[16]}\n"
            if i > 50:
                break
        await message.answer(text=text_deal, parse_mode='html')
        await message.answer(text=text_income, parse_mode='html')
        await message.answer(text=text_outcome, parse_mode='html')
    else:
        await message.answer("Топы в этом чате отключены")
