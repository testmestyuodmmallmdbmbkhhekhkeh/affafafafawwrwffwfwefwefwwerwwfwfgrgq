import datetime

from aiogram import types
from modules import sqLite


async def money_transfer(message: types.Message, money: int, smail: str):
    chat_id = message.chat.id
    user_id = message.from_user.id
    victem_id = message.reply_to_message.from_user.id
    user_data = sqLite.read_values_by_name(table=f'all_users', data=user_id)
    victem_data = sqLite.read_values_by_name(table=f'all_users', data=victem_id)
    # Обновляем деньги у пользователей
    sqLite.insert_info(table=f'all_users', name='money', data=victem_data[2] + money,
                       telegram_id=victem_id)
    sqLite.insert_info(table=f'all_users', name='money', data=user_data[2] - money,
                       telegram_id=user_id)
    # Пишем в историю каждого из пользователей
    sqLite.ins_log(tg_id=str(user_id), info=f'перевод игроку {victem_data[10]}', money=f"-{money}", chanel_id=chat_id,
                   victem_id=str(victem_id))
    sqLite.ins_log(tg_id=str(victem_id), info=f'перевод от игрока {user_data[10]}', money=f"+{money}", chanel_id=chat_id,
                   victem_id=str(user_id))

    await message.answer(
        f"{message.from_user.first_name} передал {money} монет {message.reply_to_message.from_user.first_name} {smail}")


# Передаем деньги
async def gift(message: types.Message):
    user_id = message.from_user.id
    user_data = sqLite.read_values_by_name(table=f'all_users', data=user_id)
    now = datetime.datetime.now() - datetime.timedelta(hours=12)
    gift_time = lambda x: "2021-10-12 10:23:45" if x == '0' else str(user_data[19])
    gift_time = gift_time(str(user_data[19]))
    try:
        smail = message.text.split(' ')[1]
    except:
        smail = ''
    money = int(message.text.split(' ')[0][1:])
    money = int(money)

    if gift_time == '1':
        # без лимита и с
        await money_transfer(message, money, smail)

    elif money > 20000:
        if datetime.datetime.strptime(gift_time, "%Y-%m-%d %H:%M:%S") < now:
            await message.answer(f'Лимит на передачу 20000 монет за 12 часов. Вы еще можете передать: 20000')
        else:
            await message.answer(f'Лимит на передачу 20000 монет за 12 часов. Вы еще можете передать: '
                                 f'{20000 - user_data[18]}')
    elif money <= 20000:
        # Если последний перевод был больше 12 ч назад
        if datetime.datetime.strptime(gift_time, "%Y-%m-%d %H:%M:%S") < now:
            await money_transfer(message, money, smail)
            # Обновляем данные об сумме перевода
            sqLite.insert_info(table=f'all_users', name='gift_limit', data=money,
                               telegram_id=user_id)
            sqLite.insert_info(table=f'all_users', name='gift_time', data=str(datetime.datetime.now()).split('.')[0],
                               telegram_id=user_id)

        else:
            # Проверка сколько можно передать
            if 20000 - user_data[18] >= money:
                await money_transfer(message, money, smail)
                # Обновляем данные об сумме перевода
                sqLite.insert_info(table=f'all_users', name='gift_limit', data=user_data[18] + money,
                                   telegram_id=user_id)
                sqLite.insert_info(table=f'all_users', name='gift_time',
                                   data=str(datetime.datetime.now()).split('.')[0],
                                   telegram_id=user_id)
            else:
                await message.answer(f'Лимит на передачу 20000 монет за 12 часов. Вы еще можете передать: '
                                     f'{20000 - user_data[18]}')
