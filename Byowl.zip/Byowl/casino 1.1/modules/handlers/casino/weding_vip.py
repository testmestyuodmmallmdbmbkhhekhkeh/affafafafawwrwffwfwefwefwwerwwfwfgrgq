import datetime

from modules import sqLite
from modules.dispatcher import bot
from aiogram import types
from modules.keyboards import wedding_vip_start_kb
import random


def random_licensy():
    sumbols = '123456789abcdefghiklmnopqrstuvwxyz'
    licensi_n = ''
    for i in range(0, 15):
        licensi_n = licensi_n + random.choice(sumbols)
    return licensi_n


def send_main_text(name: str = ' ',
                   man: str = ' ',
                   woman: str = ' ',
                   weetnes_m: str = ' ',
                   sons: str = ' ',
                   daughter: str = ' ',
                   weetnes_w: str = ' ',
                   registr: str = ' ',
                   guests: str = ' '):
    text = f'💎💎💎🤴❤️VipOwl❤️👸💎💎💎\n' \
           f'➖➖➖➖➖➖➖➖➖➖➖➖➖\n' \
           f'{name} предлагает провести церемонию бракосочетания💏\n\n' \
           f'🤵Жених: {man}\n' \
           f'👰Невеста: {woman}\n\n' \
           f'🙍‍♂️Сыновья: {sons}\n' \
           f'🙍‍♀️Дочери: {daughter}\n' \
           f'👨Свидетель: {weetnes_m}\n' \
           f'👩‍Свидетельница: {weetnes_w}\n\n' \
           f'👩🏼💼Регистратор: {registr}\n\n' \
           f'💃Гости: {guests}\n' \
           f'➖➖➖➖➖➖➖➖➖➖➖➖➖\n' \
           f'💎💎💎🦉❤️VipOwl❤️🦉💎💎💎'
    return text


def random_text():
    text = ("— Ты правда хочешь, чтобы мы были всё же на «ты»? \n— Я хочу, чтобы мы были же-на-ты.",
            "Мало быть мужем и женой, надо ещё стать друзьями и любовниками, чтобы потом не искать их на стороне…",
            "Брак — настоящий аттракцион. И я рад, что ты мой ремень безопасности. Он тоже боялся. Но и понимал, что если они не сделают этот шаг вместе, то дальше им придётся идти в одиночестве. До конца жизни, потому что ничего подобного с ними уже никогда не произойдёт, а на меньшее они не согласятся...",
            "Он тоже боялся. Но и понимал, что если они не сделают этот шаг вместе, то дальше им придётся идти в одиночестве. До конца жизни, потому что ничего подобного с ними уже никогда не произойдёт, а на меньшее они не согласятся...",
            "— Слушай, а почему ты не выходила замуж? \n"
            "— Тебя ждала...",
            "Брак – это мирное сосуществование двух нервных систем.",
            "Я не хочу только спать с тобой. Я хочу жениться, чтобы делить с тобой все, что у тебя внутри.",
            "Хорошая семья та, в которой муж и жена днем забывают, что они любовники, а ночью — о том, что они супруги.",
            "Он готов умереть за тебя, и больше того – он хочет на тебе жениться.",
            "Любовь, как выяснилось, — это нечто большее, чем три слова, оброненные перед сном. Любовь поддерживается действием. Нежностью даже в тех вещах, которые мы делаем друг для друга изо дня в день.",
            "Смысл брака не в том. чтобы думать одинаково, а в том, чтобы думать вместе.",
            "Брак представляет собой отношения между мужчиной и женщиной, где независимость обеих сторон одинакова, зависимость обоюдна, а обязательства взаимны.")
    return random.choice(text)


# Создаем свадьбу
async def wedding_vip(message: types.Message):
    chat_id = message.chat.id
    if '-' not in str(chat_id):
        pass
    else:
        tg_id = message.from_user.id
        licensi_w = int(sqLite.read_values_by_name(table='all_users', data=tg_id)[14])
        if licensi_w < 1:
            await message.answer(f'У вас отсутствует VIP лицензия,вы можете приобрести ее в донате.')
        else:
            sqLite.insert_info(table='all_users', name="license_vip", data=(licensi_w - 1), telegram_id=tg_id)
            # создаем номер лицензии
            check = '123'
            licensi_n = ""
            while check is not None:
                licensi_n = random_licensy()
                check = sqLite.read_values_by_name(table='weddings', id_name='wedding_id', data=licensi_n)
            sqLite.insert_first_note(table='weddings', id_name='wedding_id', telegram_id=licensi_n)
            sqLite.insert_info(table='weddings', name='chat', data=message.chat.title, id_name='wedding_id',
                               telegram_id=licensi_n)
            sqLite.insert_info(table='weddings', name='status', data='work_vip', id_name='wedding_id',
                               telegram_id=licensi_n)
            sqLite.ins_log(tg_id=tg_id, info=f'Создал свадьбу VIP', money='-1', chanel_id=message.chat.id)
            await message.answer(text=send_main_text(name=message.from_user.first_name),
                                 reply_markup=wedding_vip_start_kb(licensi_n, message.from_user.id))


# Заполняем поля
async def in_wedding_vip(call: types.CallbackQuery):
    nick = call.from_user.first_name
    role = call.data.split('_')[1]
    licensi_n = call.data.split('_')[2]
    creator = call.data.split('_')[3]
    check = sqLite.read_values_by_name(table='weddings', id_name='wedding_id', data=licensi_n, name=role)[0]
    if check is None:
        data = sqLite.read_values_by_name(table='weddings', id_name='wedding_id', data=licensi_n)
        if f"{nick}#№%{call.from_user.id}" in str(data):
            await bot.answer_callback_query(call.id)
        else:
            sqLite.insert_info(table='weddings', name=role, data=f"{nick}#№%{call.from_user.id}", id_name='wedding_id',
                               telegram_id=licensi_n)
            data = sqLite.read_values_by_name(table='weddings', id_name='wedding_id', data=licensi_n)
            first_name = sqLite.read_values_by_name(table='all_users', data=int(creator))[10]
            person = lambda x: " " if str(x) == 'None' or str(x) == '0' else str(x)
            son = person(str(data[11]))
            daughter = person(str(data[12]))
            man = person(str(data[2]).split("#№%")[0])
            woman = person(str(data[3]).split("#№%")[0])
            weetnes_m = person(str(data[4]).split("#№%")[0])
            weetnes_w = person(str(data[5]).split("#№%")[0])
            registr = person(str(data[6]).split("#№%")[0])
            guests = person(str(data[7]))
            await call.message.edit_text(text=send_main_text(name=first_name,
                                                             man=man,
                                                             sons=son,
                                                             daughter=daughter,
                                                             woman=woman,
                                                             weetnes_m=weetnes_m,
                                                             weetnes_w=weetnes_w,
                                                             registr=registr,
                                                             guests=guests),
                                         reply_markup=wedding_vip_start_kb(licensi_n, creator))
    else:
        await bot.answer_callback_query(call.id)


# Заполняем поля за гостей
async def in_guests_wedding_vip(call: types.CallbackQuery):
    nick = call.from_user.first_name
    licensi_n = call.data.split('_')[2]
    creator = call.data.split('_')[3]

    data = sqLite.read_values_by_name(table='weddings', id_name='wedding_id', data=licensi_n)
    if f"{nick}" in str(data):
        await bot.answer_callback_query(call.id)
    else:
        if str(data[7]) == 'None':
            sqLite.insert_info(table='weddings', name='guests', data=f"{nick}", id_name='wedding_id',
                               telegram_id=licensi_n)
        else:
            sqLite.insert_info(table='weddings', name='guests', data=f"{data[7]}, {nick}", id_name='wedding_id',
                               telegram_id=licensi_n)
        data = sqLite.read_values_by_name(table='weddings', id_name='wedding_id', data=licensi_n)
        first_name = sqLite.read_values_by_name(table='all_users', data=int(creator))[10]
        person = lambda x: " " if str(x) == 'None' or str(x) == '0' else str(x)
        son = person(str(data[11]))
        daughter = person(str(data[12]))
        man = person(str(data[2]).split("#№%")[0])
        woman = person(str(data[3]).split("#№%")[0])
        weetnes_m = person(str(data[4]).split("#№%")[0])
        weetnes_w = person(str(data[5]).split("#№%")[0])
        registr = person(str(data[6]).split("#№%")[0])
        guests = person(str(data[7]))
        await call.message.edit_text(text=send_main_text(name=first_name,
                                                         man=man,
                                                         sons=son,
                                                         daughter=daughter,
                                                         woman=woman,
                                                         weetnes_m=weetnes_m,
                                                         weetnes_w=weetnes_w,
                                                         registr=registr,
                                                         guests=guests),
                                     reply_markup=wedding_vip_start_kb(licensi_n, creator))


# Заполняем поля за сыновей и дочерей
async def in_sons_wedding_vip(call: types.CallbackQuery):
    nick = call.from_user.first_name
    licensi_n = call.data.split('_')[2]
    creator = call.data.split('_')[3]
    role = call.data.split('_')[1]
    data = sqLite.read_values_by_name(table='weddings', id_name='wedding_id', data=licensi_n)
    if f"{nick}" in str(data):
        await bot.answer_callback_query(call.id)
    else:
        old_data = sqLite.read_values_by_name(table='weddings', id_name='wedding_id', data=licensi_n, name=role)
        all_sons = str(old_data[0]).split(', ')
        if len(all_sons) >= 3:
            await bot.answer_callback_query(call.id)
        else:
            if str(old_data[0]) == '0':
                sqLite.insert_info(table='weddings', name=role, data=f"{nick}", id_name='wedding_id',
                                   telegram_id=licensi_n)
            else:
                sqLite.insert_info(table='weddings', name=role, data=f"{old_data[0]}, {nick}", id_name='wedding_id',
                                   telegram_id=licensi_n)
            data = sqLite.read_values_by_name(table='weddings', id_name='wedding_id', data=licensi_n)
            first_name = sqLite.read_values_by_name(table='all_users', data=int(creator))[10]
            person = lambda x: " " if str(x) == 'None' or str(x) == '0' else str(x)
            son = person(str(data[11]))
            daughter = person(str(data[12]))
            man = person(str(data[2]).split("#№%")[0])
            woman = person(str(data[3]).split("#№%")[0])
            weetnes_m = person(str(data[4]).split("#№%")[0])
            weetnes_w = person(str(data[5]).split("#№%")[0])
            registr = person(str(data[6]).split("#№%")[0])
            guests = person(str(data[7]))
            await call.message.edit_text(text=send_main_text(name=first_name,
                                                             man=man,
                                                             sons=son,
                                                             daughter=daughter,
                                                             woman=woman,
                                                             weetnes_m=weetnes_m,
                                                             weetnes_w=weetnes_w,
                                                             registr=registr,
                                                             guests=guests),
                                         reply_markup=wedding_vip_start_kb(licensi_n, creator))


# Жених и невеста ставят подписи
async def sing_wedding_vip(call: types.CallbackQuery):
    nick = call.from_user.first_name
    licensi_n = call.data.split('_')[2]
    creator = call.data.split('_')[3]
    wedding_data = sqLite.read_values_by_name(table='weddings', id_name='wedding_id', data=licensi_n)
    if f"{nick}#№%{call.from_user.id}" == str(wedding_data[2]):
        sqLite.insert_info(table='weddings', name='man', data=f"❤️{nick}#№%{call.from_user.id}", id_name='wedding_id',
                           telegram_id=licensi_n)
        data = sqLite.read_values_by_name(table='weddings', id_name='wedding_id', data=licensi_n)
        first_name = sqLite.read_values_by_name(table='all_users', data=int(creator))[10]
        person = lambda x: " " if str(x) == 'None' or str(x) == '0' else str(x)
        son = person(str(data[11]))
        daughter = person(str(data[12]))
        man = person(str(data[2]).split("#№%")[0])
        woman = person(str(data[3]).split("#№%")[0])
        weetnes_m = person(str(data[4]).split("#№%")[0])
        weetnes_w = person(str(data[5]).split("#№%")[0])
        registr = person(str(data[6]).split("#№%")[0])
        guests = person(str(data[7]))
        await call.message.edit_text(text=send_main_text(name=first_name,
                                                         man=man,
                                                         sons=son,
                                                         daughter=daughter,
                                                         woman=woman,
                                                         weetnes_m=weetnes_m,
                                                         weetnes_w=weetnes_w,
                                                         registr=registr,
                                                         guests=guests),
                                     reply_markup=wedding_vip_start_kb(licensi_n, creator))
    elif f"{nick}#№%{call.from_user.id}" == str(wedding_data[3]):
        sqLite.insert_info(table='weddings', name="woman", data=f"❤️{nick}#№%{call.from_user.id}", id_name='wedding_id',
                           telegram_id=licensi_n)
        data = sqLite.read_values_by_name(table='weddings', id_name='wedding_id', data=licensi_n)
        first_name = sqLite.read_values_by_name(table='all_users', data=int(creator))[10]
        person = lambda x: " " if str(x) == 'None' or str(x) == '0' else str(x)
        son = person(str(data[11]))
        daughter = person(str(data[12]))
        man = person(str(data[2]).split("#№%")[0])
        woman = person(str(data[3]).split("#№%")[0])
        weetnes_m = person(str(data[4]).split("#№%")[0])
        weetnes_w = person(str(data[5]).split("#№%")[0])
        registr = person(str(data[6]).split("#№%")[0])
        guests = person(str(data[7]))
        await call.message.edit_text(text=send_main_text(name=first_name,
                                                         man=man,
                                                         sons=son,
                                                         daughter=daughter,
                                                         woman=woman,
                                                         weetnes_m=weetnes_m,
                                                         weetnes_w=weetnes_w,
                                                         registr=registr,
                                                         guests=guests),
                                     reply_markup=wedding_vip_start_kb(licensi_n, creator))
    else:
        await bot.answer_callback_query(call.id)


# Заключаем брак
async def registr_wedding_vip(call: types.CallbackQuery):
    await bot.answer_callback_query(call.id)
    licensi_n = call.data.split('_')[2]
    wedding_data = sqLite.read_values_by_name(table='weddings', id_name='wedding_id', data=licensi_n)
    print(15)
    if f"❤️" in str(wedding_data[2]) and f"❤️" in str(wedding_data[3]):
        print(2)
        proces = True
        for k in wedding_data:
            if k is None:
                proces = False
            else:
                pass
        check_guests = str(wedding_data[7]).split(', ')
        if len(check_guests) < 2:
            pass
        else:
            if proces:
                data = sqLite.read_values_by_name(table='weddings', id_name='wedding_id', data=licensi_n)
                man_id = str(data[2]).split("#№%")[1]
                woman_id = str(data[3]).split("#№%")[1]
                data_man = sqLite.read_values_by_name(table='all_users', data=man_id)
                data_woman = sqLite.read_values_by_name(table='all_users', data=woman_id)

                man = str(data[2]).split("#№%")[0]
                woman = str(data[3]).split("#№%")[0]
                # собираем детей
                if str(data[11]) == '0' and str(data[12]) == '0':
                    kids = f"0"
                elif str(data[11]) != '0' and str(data[12]) == '0':
                    kids = f"{str(data[11])}"
                elif str(data[11]) == '0' and str(data[12]) != '0':
                    kids = f"{str(data[12])}"
                else:
                    kids = f"{str(data[11])}, {str(data[12])}"

                sqLite.insert_info(table='weddings', name="data_d",
                                   data=str(datetime.datetime.now()).split('.')[0],
                                   id_name='wedding_id',
                                   telegram_id=licensi_n)
                sqLite.insert_info(table='weddings', name="status",
                                   data="wedding_vip",
                                   id_name='wedding_id',
                                   telegram_id=licensi_n)
                # Сохраняем свидетельства
                sqLite.insert_info(table='all_users', name="wedding",
                                   data=licensi_n,
                                   telegram_id=man_id)
                sqLite.insert_info(table='all_users', name="wedding",
                                   data=licensi_n,
                                   telegram_id=woman_id)
                # Сохраняем супругов
                sqLite.insert_info(table='all_users', name="hasben",
                                   data=woman[2:],
                                   telegram_id=man_id)
                sqLite.insert_info(table='all_users', name="hasben",
                                   data=man[2:],
                                   telegram_id=woman_id)

                # Сохраняем детей
                sqLite.insert_info(table='all_users', name="kids",
                                   data=kids,
                                   telegram_id=man_id)
                sqLite.insert_info(table='all_users', name="kids",
                                   data=kids,
                                   telegram_id=woman_id)

                # Сохраняем обновляем имена в свидетельстве
                sqLite.insert_info(table='weddings', name="man",
                                   data=str(data[2])[1:],
                                   id_name='wedding_id',
                                   telegram_id=licensi_n)
                sqLite.insert_info(table='weddings', name="woman",
                                   data=str(data[3])[1:],
                                   id_name='wedding_id',
                                   telegram_id=licensi_n)
                if kids == '0':
                    kids = ''
                else:
                    kids = f'Дети: {kids}\n'
                man = str(data[2]).split("#№%")[0]
                woman = str(data[3]).split("#№%")[0]
                weetnes_m = str(data[4]).split("#№%")[0]
                weetnes_w = str(data[5]).split("#№%")[0]
                registr = str(data[6]).split("#№%")[0]
                guests = str(data[7])
                await call.message.edit_text(text=f'Брак зарегистрирован\n\n'
                                                  f'{random_text()}\n\n'
                                                  f'с уважением регистрация @ByOwl_Technical_Support')
                await call.message.answer(text=f'💎💎💎🤴❤️VipOwl❤️👸💎💎💎\n'
                                               f'➖➖➖➖➖➖➖➖➖➖➖➖➖\n'
                                               f'{man[1:]} и {woman[1:]}\n'
                                               f'заключили брак в чате {str(data[1])}\n'
                                               f'Регистратор: {registr}\n{kids}'
                                               f'Свидетель: {weetnes_m}\n'
                                               f'Свидетельница: {weetnes_w}\n'
                                               f'Гости: {guests}\n'
                                               f'Дата: {str(data[9])}\n'
                                               f'Код: {licensi_n}\n'
                                               f'➖➖➖➖➖➖➖➖➖➖➖➖➖\n'
                                               f'💎💎💎🦉❤️VipOwl❤️🦉💎💎💎')
    else:
        print(333)
        await bot.answer_callback_query(call.id)


# Парсим все колбэки
async def call_wedding_vip(call: types.CallbackQuery):
    data = call.data
    if data.startswith('wedvip_man_'):
        await in_wedding_vip(call)
    elif data.startswith('wedvip_woman_'):
        await in_wedding_vip(call)
    elif data.startswith('wedvip_son'):
        await in_sons_wedding_vip(call)
    elif data.startswith('wedvip_daughter_'):
        await in_sons_wedding_vip(call)
    elif data.startswith('wedvip_guests_'):
        await in_guests_wedding_vip(call)
    elif data.startswith('wedvip_witnessw_'):
        await in_wedding_vip(call)
    elif data.startswith('wedvip_witnessm_'):
        await in_wedding_vip(call)
    elif data.startswith('wedvip_start_'):
        print(1)
        await registr_wedding_vip(call)
    elif data.startswith('wedvip_sing_'):
        await sing_wedding_vip(call)
    elif data.startswith('wedvip_registrar_'):
        await in_wedding_vip(call)
    elif data.startswith('wedvip_cancel_'):
        if call.from_user.id == int(data.split('_')[3]):

            licensi_w = str(data.split('_')[2])
            wedding_data = str(sqLite.read_values_by_name(table='weddings', id_name='wedding_id', data=licensi_w)[10])
            check_brack = sqLite.read_values_by_name(table='all_users', data=call.from_user.id)
            if 'vip' in wedding_data:
                sqLite.insert_info(table='all_users', name="license_vip", data=(int(check_brack[14]) + 1),
                                   telegram_id=call.from_user.id)
            else:
                sqLite.insert_info(table='all_users', name="license", data=(int(check_brack[11]) + 1),
                                   telegram_id=call.from_user.id)
            data = sqLite.read_values_by_name(table='weddings', id_name='wedding_id', data=str(data.split('_')[2]))[0]
            sqLite.delete_str(table='weddings', name='id', data=int(data))
            sqLite.ins_log(tg_id=data.split('_')[3], info=f'VIP свадьба отменена', money='+1',
                           chanel_id=call.message.chat.id)
            await call.message.edit_text("Свадьба отменена")
        else:
            await bot.answer_callback_query(call.id)
            print(data)
