from aiogram import types
from modules.dispatcher import bot, Market
from modules import sqLite


# Покупаем лицензию
async def buy_licensy(call: types.CallbackQuery):
    chat_id = call.message.chat.id
    user_id = call.from_user.id
    user_data = sqLite.read_values_by_name(table=f'all_users', data=user_id)
    if user_data[2] < 50000:
        await call.message.answer(f"Вам не хватает {50000 - user_data[2]} монет на лицензию")
    else:
        sqLite.ins_log(tg_id=str(user_id), info=f'покупка лицензии', money="-50000", chanel_id=chat_id)
        sqLite.insert_info(table=f'all_users', name='money', data=user_data[2] - 50000, telegram_id=user_id)
        sqLite.insert_info(table=f'all_users', name='license', data=user_data[11] + 1, telegram_id=user_id)
        await call.message.answer('Лицензия куплена!')


# Покупаем лицензию VIP
async def buy_licensy_vip(call: types.CallbackQuery):
    chat_id = call.message.chat.id
    user_id = call.from_user.id
    user_data = sqLite.read_values_by_name(table=f'all_users', data=user_id)
    if user_data[2] < 1000000:
        await call.message.answer(f"Вам не хватает {1000000 - user_data[2]} монет на VIP лицензию")
    else:
        sqLite.ins_log(tg_id=str(user_id), info=f'покупка VIP лицензии', money="-1000000",  chanel_id=chat_id)
        sqLite.insert_info(table=f'all_users', name='money', data=user_data[2] - 1000000, telegram_id=user_id)
        sqLite.insert_info(table=f'all_users', name='license_vip', data=user_data[14] + 1, telegram_id=user_id)
        await call.message.answer('VIP лицензия куплена!')


# Снимаем лимит в группе на рулетку.
async def buy_no_roll_limits(call: types.CallbackQuery):
    user_id = call.from_user.id
    user_data = sqLite.read_values_by_name(table=f'all_users', data=user_id)
    if user_data[2] < 2000000:
        await call.message.answer(f"Вам не хватает {2000000 - user_data[2]} монет на снятие ограничения на рулетку")
    else:
        await call.message.answer('Введите id группы\n'
                                  'Пример:-12536554522')
        await Market.roll_limits.set()


# Покупаем защиту от игнор
async def buy_un_ignore(call: types.CallbackQuery):
    chat_id = call.message.chat.id
    user_id = call.from_user.id
    user_data = sqLite.read_values_by_name(table=f'all_users', data=user_id)
    if user_data[2] < 1000000:
        await call.message.answer(f"Вам не хватает {1000000 - user_data[2]} монет на защиту от !игнор")
    elif user_data[16] == 1:
        await call.message.answer(f"У вас уже есть защита от !игнор")
    else:
        sqLite.ins_log(tg_id=str(user_id), info=f'покупка защиты от !игнор', money="-1000000", chanel_id=chat_id)
        sqLite.insert_info(table=f'all_users', name='money', data=user_data[2] - 1000000, telegram_id=user_id)
        sqLite.insert_info(table=f'all_users', name='ignor', data=1, telegram_id=user_id)
        await call.message.answer('Защита от !игнор успешно активирована!')


# Покупаем защиту от игнор и мут
async def buy_un_ignore_mut(call: types.CallbackQuery):
    chat_id = call.message.chat.id
    user_id = call.from_user.id
    user_data = sqLite.read_values_by_name(table=f'all_users', data=user_id)
    if user_data[2] < 4000000:
        await call.message.answer(f"Вам не хватает {4000000 - user_data[2]} монет на защиту от !игнор и !!мут")
    elif user_data[17] == 1:
        await call.message.answer(f"У вас уже есть защита от !игнор и !!мут")
    else:
        sqLite.ins_log(tg_id=str(user_id), info=f'покупка защиты от !игнор и !!мут', money="-4000000",
                       chanel_id=chat_id)
        sqLite.insert_info(table=f'all_users', name='money', data=user_data[2] - 4000000, telegram_id=user_id)
        sqLite.insert_info(table=f'all_users', name='mut_ignor', data=1, telegram_id=user_id)
        await call.message.answer('Защита от !!мут и !игнор успешно активирована!')


# Парсим все колбэки
async def pars_calls_market(call: types.CallbackQuery):
    await bot.answer_callback_query(call.id)
    data = str(call.data)
    if data == 'market_licensy_btn':
        await buy_licensy(call)
    elif data == 'market_licensy_vip_btn':
        await buy_licensy_vip(call)
    elif data == 'market_ruletka_btn':
        await buy_no_roll_limits(call)
    elif data == 'market_ignor_protect_btn':
        await buy_un_ignore(call)
    elif data == 'market_mut_protect_btn':
        await buy_un_ignore_mut(call)
