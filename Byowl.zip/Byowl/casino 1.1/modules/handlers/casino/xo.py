from modules import sqLite
from modules.handlers.casino.read_and_save_data import read_and_save_data
from modules.dispatcher import bot
from aiogram import types
from modules.keyboards import xo_start_kb, xo_keyb, xo_playe_keyb


async def xo(message: types.Message, rep_tg_id: int = None):
    chanel_id = message.chat.id
    deal = message.text.split(' ')[1]
    user_id = message.from_user.id
    tg_id = message.from_user.id
    money = int(sqLite.read_values_by_name(table='all_users', data=tg_id)[2])
    if money < int(deal):
        await message.answer(f'{message.from_user.first_name}, ставка не может превышать ваши средства')
    else:
        if rep_tg_id is None:
            await message.answer(f'{message.from_user.first_name} предлагает сыграть в Крестики Нолики! Ставка: {deal}',
                                 reply_markup=xo_start_kb(user_id, deal))

            sqLite.ins_log(tg_id=str(user_id), info=f'Предлагает сыграть в крестики-нолики', money=f'{deal}',
                           chanel_id=f'{chanel_id}')
        else:
            await message.answer(f'{message.from_user.first_name} предлагает сыграть в Крестики Нолики! Ставка: {deal}',
                                 reply_markup=xo_start_kb(user_id, deal, rep_tg_id))
            sqLite.ins_log(tg_id=str(user_id), info=f'Предлагает сыграть в крестики-нолики', money=f'{deal}')


# Начинаем игру
async def start_xo(call: types.CallbackQuery):
    tg_id_start = call.data.split('_')[2]
    deal = call.data.split('_')[4]
    money = sqLite.read_values_by_name(table='all_users', data=call.from_user.id)
    if int(money[2]) < int(deal):
        await call.message.answer(f'{call.from_user.first_name}, ставка не может превышать ваши средства')
    else:

        if call.from_user.id == int(tg_id_start):
            await bot.answer_callback_query(call.id)
        else:
            await bot.answer_callback_query(call.id)
            user_start = sqLite.read_values_by_name(table='all_users', data=tg_id_start)

            sqLite.insert_info(table=f'all_users', name='money', data=int(money[2]) - int(deal),
                               telegram_id=call.from_user.id)
            sqLite.insert_info(table=f'all_users', name='money', data=int(user_start[2]) - int(deal),
                               telegram_id=tg_id_start)
            await call.message.edit_text(f'1, {user_start[10]}\n'
                                         f'2, {call.from_user.first_name}\n'
                                         f'Сейчас ходит : {user_start[10]}',
                                         reply_markup=xo_keyb(user_start[1], call.from_user.id, deal))


# Условие победы
def win(cod: str):
    if cod[0] == cod[1] and cod[0] == cod[2] and cod[0] != '0':
        return True
    elif cod[3] == cod[4] and cod[3] == cod[5] and cod[3] != '0':
        return True
    elif cod[6] == cod[7] and cod[6] == cod[8] and cod[6] != '0':
        return True
    elif cod[0] == cod[3] and cod[0] == cod[6] and cod[0] != '0':
        return True
    elif cod[1] == cod[4] and cod[1] == cod[7] and cod[1] != '0':
        return True
    elif cod[2] == cod[5] and cod[2] == cod[8] and cod[2] != '0':
        return True
    elif cod[0] == cod[4] and cod[0] == cod[8] and cod[0] != '0':
        return True
    elif cod[6] == cod[4] and cod[6] == cod[2] and cod[6] != '0':
        return True
    else:
        return False


# Основная игра
async def main_xo(call: types.CallbackQuery):
    chanel_id = call.message.chat.id
    tg_id_next = int(call.data.split('_')[3])
    tg_id_start = int(call.data.split('_')[2])
    cod = call.data.split('_')[4]
    deal = call.data.split('_')[5]
    btn = int(call.data.split('_')[1])
    if call.from_user.id != int(tg_id_start):
        await bot.answer_callback_query(call.id)
    else:
        await bot.answer_callback_query(call.id)
        ho = ''
        for l in cod:
            if l == '0':
                pass
            else:
                ho = ho + l
        i = 1
        new_cod = ''
        for k in cod:
            if i == btn:
                if len(ho) % 2 == 0:
                    new_cod = new_cod + '1'
                else:
                    new_cod = new_cod + '2'
            else:
                new_cod = new_cod + k
            i += 1
        if win(new_cod) and '0' in cod:
            user_1 = sqLite.read_values_by_name(table='all_users', data=tg_id_next)
            user_2 = sqLite.read_values_by_name(table='all_users', data=tg_id_start)
            if call.from_user.id == tg_id_start:
                read_and_save_data(tg_id=tg_id_start, deal=int(deal), income=int(deal) * 2)

                sqLite.ins_log(tg_id=str(tg_id_start), info=f'победа в крестики-нолики', money=f'+{deal}',
                               chanel_id=str(chanel_id), victem_id=str(tg_id_next))
                sqLite.ins_log(tg_id=str(tg_id_next), info=f'проигрыш в крестики-нолики', money=f'-{deal}',
                               chanel_id=str(chanel_id), victem_id=str(tg_id_start))

                await call.message.edit_text(f'Игра окончена!\n\n'
                                          f'Победитель {user_2[10]}\n'
                                          f'Проиграл {user_1[10]}\n\n'
                                          f'Выигрыш: {deal} монет')
            else:
                read_and_save_data(tg_id=tg_id_next, deal=int(deal), income=int(deal) * 2)

                sqLite.ins_log(tg_id=str(tg_id_next), info=f'победа в крестики-нолики', money=f'+{deal}',
                               chanel_id=str(chanel_id), victem_id=str(tg_id_start))
                sqLite.ins_log(tg_id=str(tg_id_start), info=f'проигрыш в крестики-нолики', money=f'-{deal}',
                               chanel_id=str(chanel_id), victem_id=str(tg_id_next))

                await call.message.edit_text(f'Игра окончена!\n\n'
                                          f'Победитель {user_1[10]}\n'
                                          f'Проиграл {user_2[10]}\n\n'
                                          f'Выигрыш: {deal} монет')
        elif '0' not in new_cod:
            read_and_save_data(tg_id=tg_id_start, deal=int(deal), income=int(deal))
            sqLite.ins_log(tg_id=str(tg_id_start), info=f'Ничья в крестики-нолики', money=f'0',
                           chanel_id=str(chanel_id), victem_id=str(tg_id_next))
            sqLite.ins_log(tg_id=str(tg_id_next), info='Ничья в крестики-нолики', money=f'0',
                           chanel_id=str(chanel_id), victem_id=str(tg_id_start))
            await call.message.edit_text(f'Игра окончена!\n\n'
                                         f'Победителя нет')
            read_and_save_data(tg_id=tg_id_next, deal=int(deal), income=int(deal))
        else:
            user_start = sqLite.read_values_by_name(table='all_users', data=tg_id_next)
            if len(ho) % 2 == 0:
                await call.message.edit_text(f'1, {call.from_user.first_name}\n'
                                             f'2, {user_start[10]}\n'
                                             f'Сейчас ходит : {user_start[10]}',
                                             reply_markup=xo_playe_keyb(user_1_id=user_start[1],
                                                                        user_2_id=call.from_user.id,
                                                                        cod=new_cod, deal=deal))
            else:
                await call.message.edit_text(f'1, {user_start[10]}\n'
                                             f'2, {call.from_user.first_name}\n'
                                             f'Сейчас ходит : {user_start[10]}',
                                             reply_markup=xo_playe_keyb(user_1_id=user_start[1],
                                                                        user_2_id=call.from_user.id,
                                                                        cod=new_cod, deal=deal))


# Конец игры когда сдался
async def close_xo(call: types.CallbackQuery):
    chanel_id = call.message.chat.id
    tg_1 = int(call.data.split('_')[2])
    tg_2 = int(call.data.split('_')[3])
    deal = int(call.data.split('_')[4])
    user_1 = sqLite.read_values_by_name(table='all_users', data=tg_1)
    user_2 = sqLite.read_values_by_name(table='all_users', data=tg_2)
    if call.from_user.id != tg_1 and call.from_user.id != tg_2:
        await bot.answer_callback_query(call.id)
    else:
        await bot.answer_callback_query(call.id)
        if call.from_user.id == tg_1:
            read_and_save_data(tg_id=tg_2, deal=deal, income=deal * 2)
            sqLite.ins_log(tg_id=str(tg_2), info=f'победа в крестики-нолики', money=f'+{deal}',
                           chanel_id=str(chanel_id), victem_id=str(tg_1))
            sqLite.ins_log(tg_id=str(tg_1), info=f'проигрыш в крестики-нолики', money=f'-{deal}',
                           chanel_id=str(chanel_id), victem_id=str(tg_2))
            await call.message.edit_text(f'Игра окончена!\n\n'
                                         f'Победитель {user_2[10]}\n'
                                         f'Проиграл {user_1[10]}\n\n'
                                         f'Выигрыш: {deal} монет')
        else:
            read_and_save_data(tg_id=tg_1, deal=deal, income=deal * 2)
            sqLite.ins_log(tg_id=str(tg_1), info=f'победа в крестики-нолики', money=f'+{deal}',
                           chanel_id=str(chanel_id), victem_id=str(tg_2))
            sqLite.ins_log(tg_id=str(tg_2), info=f'проигрыш в крестики-нолики', money=f'-{deal}',
                           chanel_id=str(chanel_id), victem_id=str(tg_1))
            await call.message.edit_text(f'Игра окончена!\n\n'
                                         f'Победитель {user_1[10]}\n'
                                         f'Проиграл {user_2[10]}\n\n'
                                         f'Выигрыш: {deal} монет')


# Отмена игры до начала
async def close_xo_on_start(call: types.CallbackQuery):
    tg_1 = int(call.data.split('_')[3])
    tg_2 = call.data.split('_')[4]
    if tg_2 == 'free':
        if call.from_user.id == tg_1:
            await call.message.edit_text("Игра была отменена")
        else:
            pass
    else:
        if call.from_user.id == tg_1 or call.from_user.id == int(tg_2):
            await call.message.edit_text("Игра была отменена")
        else:
            pass


# Парсим все колбэки
async def call_xo(call: types.CallbackQuery):
    data = call.data
    if data.split('_')[3] == 'free':
        await start_xo(call)
    elif data.startswith('s_xo_close_'):
        await close_xo_on_start(call)
    else:
        tg_id = int(call.data.split('_')[3])
        await bot.answer_callback_query(call.id)
        if tg_id == call.from_user.id:
            await start_xo(call)
        else:
            pass
