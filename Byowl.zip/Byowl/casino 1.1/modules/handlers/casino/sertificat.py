import datetime

from modules import sqLite
from modules.dispatcher import bot
from aiogram import types
from modules.keyboards import wedding_start_kb
import random


def random_licensy():
    sumbols = '123456789abcdefghiklmnopqrstuvwxyz'
    licensi_n = ''
    for i in range(0, 15):
        licensi_n = licensi_n + random.choice(sumbols)
    return licensi_n


def weding_text(name: str = ' ',
                man: str = ' ',
                woman: str = ' ',
                weetnes_m: str = ' ',
                weetnes_w: str = ' ',
                registr: str = ' ',
                guests: str = ' ',
                data: str = ' '):
    text = f'{name} провел церемонию бракосочетания💏\n\n' \
           f'🤵Жених: {man}\n' \
           f'👰Невеста: {woman}\n\n' \
           f'👨Свидетель: {weetnes_m}\n' \
           f'👩Свидетельница: {weetnes_w}\n\n' \
           f'👩🏼💼Регистратор: {registr}\n' \
           f'Дата проведения: {data}\n\n' \
           f'💃Гости: {guests}'
    return text


def weding_text_vip(name: str = ' ',
                    man: str = ' ',
                    woman: str = ' ',
                    weetnes_m: str = ' ',
                    sons: str = ' ',
                    daughter: str = ' ',
                    weetnes_w: str = ' ',
                    registr: str = ' ',
                    guests: str = ' ',
                    data: str = ' '):
    text = f'💎💎💎🤴❤️VipOwl❤️👸💎💎💎\n' \
           f'➖➖➖➖➖➖➖➖➖➖➖➖➖\n' \
           f'{name} провел церемонию бракосочетания💏\n\n' \
           f'🤵Жених: {man}\n' \
           f'👰Невеста: {woman}\n\n'
    if sons == '0':
        pass
    else:
        text = text + f'🙍‍♂️Сыновья: {sons}\n'

    if daughter == '0':
        pass
    else:
        text = text + f'🙍‍♀️Дочери: {daughter}\n'

    text = text + f'👨Свидетель: {weetnes_m}\n' \
                  f'👩‍Свидетельница: {weetnes_w}\n\n' \
                  f'👩🏼💼Регистратор: {registr}\n' \
                  f'Дата проведения: {data}\n\n' \
                  f'💃Гости: {guests}\n' \
                  f'➖➖➖➖➖➖➖➖➖➖➖➖➖\n' \
                  f'💎💎💎🦉❤️VipOwl❤️🦉💎💎💎'
    return text


# Выдаем сертификат при запросе
async def send_weding_sertificat(message: types.Message):
    user_id = message.from_user.id
    user_data = sqLite.read_values_by_name(table=f'all_users', data=user_id)
    sertificat = user_data[12]
    if str(sertificat) != '0':
        weading_data = sqLite.read_values_by_name(table=f'weddings', data=sertificat, id_name='wedding_id')
        if str(weading_data[10]) == 'wedding_vip':
            text = weding_text_vip(name=str(weading_data[6]).split('#№%')[0],
                                   man=str(weading_data[2]).split('#№%')[0],
                                   woman=str(weading_data[3]).split('#№%')[0],
                                   sons=str(weading_data[11]).split('#№%')[0],
                                   daughter=str(weading_data[12]).split('#№%')[0],
                                   weetnes_m=str(weading_data[4]).split('#№%')[0],
                                   weetnes_w=str(weading_data[5]).split('#№%')[0],
                                   registr=str(weading_data[6]).split('#№%')[0],
                                   data=str(weading_data[9]).split(' ')[0],
                                   guests=str(weading_data[7]).split('#№%')[0])
        elif str(weading_data[10]) == 'wedding':

            text = weding_text(name=str(weading_data[6]).split('#№%')[0],
                               man=str(weading_data[2]).split('#№%')[0],
                               woman=str(weading_data[3]).split('#№%')[0],
                               weetnes_m=str(weading_data[4]).split('#№%')[0],
                               weetnes_w=str(weading_data[5]).split('#№%')[0],
                               registr=str(weading_data[6]).split('#№%')[0],
                               data=str(weading_data[9]).split(' ')[0],
                               guests=str(weading_data[7]).split('#№%')[0])
        else:
            return
    else:
        await message.answer('У вас нет сертификатов')
        return
    await message.answer(text=text)
