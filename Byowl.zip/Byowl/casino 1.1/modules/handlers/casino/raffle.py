import random
from aiogram import types
from modules import sqLite
from modules.keyboards import raffle_start_kb


# Генератор победителей
def pick_users(all_chat_users: tuple, number: int):
    user_1 = random.choice(all_chat_users)
    all_wins_users = [user_1]
    i = 1
    while i < number:
        user_2 = random.choice(all_chat_users)
        if user_2 in all_wins_users:
            pass
        else:
            all_wins_users.append(user_2)
            i += 1
    return all_wins_users


# Начисляем деньги каждому пользователю пишем лог
def send_money(user: tuple, money: float, chat_id: str, koefic: float):
    user_data = sqLite.read_values_by_name(table=f'all_users', data=user[4])
    sqLite.insert_info(table=f'all_users', name='money', data=user_data[2] + int(money*koefic), telegram_id=user[4])
    sqLite.ins_log(tg_id=str(user[4]), info=f'Выигрыш в розыгрыше', money=f"+{int(money*koefic)}", chanel_id=chat_id)
    virus_text = f" {user_data[10]} {int(100*koefic)}🦉\n"
    return f'<a href="tg://user?id={user_data[1]}">{user_data[10]}</a> выиграл {int(money*koefic)}\n', virus_text


# Разделяем деньги и собираем текст победителей
def win_users_gifts(winn_users: list, money: int, chat_id: str, creator_nick: str):
    users_number = len(winn_users)

    if users_number == 2:
        text1, virus_text1 = send_money(user=winn_users[0], money=money, chat_id=chat_id, koefic=0.67)
        text2, virus_text2 = send_money(user=winn_users[1], money=money, chat_id=chat_id, koefic=0.33)
        text = text1 + text2
        virus_text = virus_text1 + virus_text2

    elif users_number == 3:
        text1, virus_text1 = send_money(user=winn_users[0], money=money, chat_id=chat_id, koefic=0.50)
        text2, virus_text2 = send_money(user=winn_users[1], money=money, chat_id=chat_id, koefic=0.33)
        text3, virus_text3 = send_money(user=winn_users[2], money=money, chat_id=chat_id, koefic=0.17)
        text = text1 + text2 + text3
        virus_text = virus_text1 + virus_text2 + virus_text3

    elif users_number == 4:
        text1, virus_text1 = send_money(user=winn_users[0], money=money, chat_id=chat_id, koefic=0.40)
        text2, virus_text2 = send_money(user=winn_users[1], money=money, chat_id=chat_id, koefic=0.30)
        text3, virus_text3 = send_money(user=winn_users[2], money=money, chat_id=chat_id, koefic=0.20)
        text4, virus_text4 = send_money(user=winn_users[3], money=money, chat_id=chat_id, koefic=0.10)
        text = text1 + text2 + text3 + text4
        virus_text = virus_text1 + virus_text2 + virus_text3 + virus_text4

    elif users_number == 5:
        text1, virus_text1 = send_money(user=winn_users[0], money=money, chat_id=chat_id, koefic=0.33)
        text2, virus_text2 = send_money(user=winn_users[1], money=money, chat_id=chat_id, koefic=0.27)
        text3, virus_text3 = send_money(user=winn_users[2], money=money, chat_id=chat_id, koefic=0.20)
        text4, virus_text4 = send_money(user=winn_users[3], money=money, chat_id=chat_id, koefic=0.13)
        text5, virus_text5 = send_money(user=winn_users[4], money=money, chat_id=chat_id, koefic=0.07)
        text = text1 + text2 + text3 + text4 + text5
        virus_text = virus_text1 + virus_text2 + virus_text3 + virus_text4 + virus_text5

    elif users_number == 6:
        text1, virus_text1 = send_money(user=winn_users[0], money=money, chat_id=chat_id, koefic=0.29)
        text2, virus_text2 = send_money(user=winn_users[1], money=money, chat_id=chat_id, koefic=0.24)
        text3, virus_text3 = send_money(user=winn_users[2], money=money, chat_id=chat_id, koefic=0.19)
        text4, virus_text4 = send_money(user=winn_users[3], money=money, chat_id=chat_id, koefic=0.14)
        text5, virus_text5 = send_money(user=winn_users[4], money=money, chat_id=chat_id, koefic=0.09)
        text6, virus_text6 = send_money(user=winn_users[5], money=money, chat_id=chat_id, koefic=0.05)
        text = text1 + text2 + text3 + text4 + text5 + text6
        virus_text = virus_text1 + virus_text2 + virus_text3 + virus_text4 + virus_text5 + virus_text6

    elif users_number == 7:
        text1, virus_text1 = send_money(user=winn_users[0], money=money, chat_id=chat_id, koefic=0.25)
        text2, virus_text2 = send_money(user=winn_users[1], money=money, chat_id=chat_id, koefic=0.21)
        text3, virus_text3 = send_money(user=winn_users[2], money=money, chat_id=chat_id, koefic=0.18)
        text4, virus_text4 = send_money(user=winn_users[3], money=money, chat_id=chat_id, koefic=0.14)
        text5, virus_text5 = send_money(user=winn_users[4], money=money, chat_id=chat_id, koefic=0.11)
        text6, virus_text6 = send_money(user=winn_users[5], money=money, chat_id=chat_id, koefic=0.07)
        text7, virus_text7 = send_money(user=winn_users[6], money=money, chat_id=chat_id, koefic=0.04)
        text = text1 + text2 + text3 + text4 + text5 + text6 + text7
        virus_text = virus_text1 + virus_text2 + virus_text3 + virus_text4 + virus_text5 + virus_text6 + virus_text7

    elif users_number == 8:
        text1, virus_text1 = send_money(user=winn_users[0], money=money, chat_id=chat_id, koefic=0.22)
        text2, virus_text2 = send_money(user=winn_users[1], money=money, chat_id=chat_id, koefic=0.19)
        text3, virus_text3 = send_money(user=winn_users[2], money=money, chat_id=chat_id, koefic=0.17)
        text4, virus_text4 = send_money(user=winn_users[3], money=money, chat_id=chat_id, koefic=0.14)
        text5, virus_text5 = send_money(user=winn_users[4], money=money, chat_id=chat_id, koefic=0.11)
        text6, virus_text6 = send_money(user=winn_users[5], money=money, chat_id=chat_id, koefic=0.08)
        text7, virus_text7 = send_money(user=winn_users[6], money=money, chat_id=chat_id, koefic=0.06)
        text8, virus_text8 = send_money(user=winn_users[7], money=money, chat_id=chat_id, koefic=0.03)
        text = text1 + text2 + text3 + text4 + text5 + text6 + text7 + text8
        virus_text = virus_text1 + virus_text2 + virus_text3 + virus_text4 + virus_text5 + virus_text6 + virus_text7 + \
                     virus_text8

    elif users_number == 9:
        text1, virus_text1 = send_money(user=winn_users[0], money=money, chat_id=chat_id, koefic=0.20)
        text2, virus_text2 = send_money(user=winn_users[1], money=money, chat_id=chat_id, koefic=0.18)
        text3, virus_text3 = send_money(user=winn_users[2], money=money, chat_id=chat_id, koefic=0.16)
        text4, virus_text4 = send_money(user=winn_users[3], money=money, chat_id=chat_id, koefic=0.13)
        text5, virus_text5 = send_money(user=winn_users[4], money=money, chat_id=chat_id, koefic=0.11)
        text6, virus_text6 = send_money(user=winn_users[5], money=money, chat_id=chat_id, koefic=0.09)
        text7, virus_text7 = send_money(user=winn_users[6], money=money, chat_id=chat_id, koefic=0.07)
        text8, virus_text8 = send_money(user=winn_users[7], money=money, chat_id=chat_id, koefic=0.04)
        text9, virus_text9 = send_money(user=winn_users[8], money=money, chat_id=chat_id, koefic=0.02)
        text = text1 + text2 + text3 + text4 + text5 + text6 + text7 + text8 + text9
        virus_text = virus_text1 + virus_text2 + virus_text3 + virus_text4 + virus_text5 + virus_text6 + virus_text7 + \
                     virus_text8 + virus_text9

    elif users_number == 10:
        text1, virus_text1 = send_money(user=winn_users[0], money=money, chat_id=chat_id, koefic=0.18)
        text2, virus_text2 = send_money(user=winn_users[1], money=money, chat_id=chat_id, koefic=0.16)
        text3, virus_text3 = send_money(user=winn_users[2], money=money, chat_id=chat_id, koefic=0.15)
        text4, virus_text4 = send_money(user=winn_users[3], money=money, chat_id=chat_id, koefic=0.13)
        text5, virus_text5 = send_money(user=winn_users[4], money=money, chat_id=chat_id, koefic=0.11)
        text6, virus_text6 = send_money(user=winn_users[5], money=money, chat_id=chat_id, koefic=0.09)
        text7, virus_text7 = send_money(user=winn_users[6], money=money, chat_id=chat_id, koefic=0.07)
        text8, virus_text8 = send_money(user=winn_users[7], money=money, chat_id=chat_id, koefic=0.05)
        text9, virus_text9 = send_money(user=winn_users[8], money=money, chat_id=chat_id, koefic=0.04)
        text10, virus_text10 = send_money(user=winn_users[9], money=money, chat_id=chat_id, koefic=0.02)
        text = text1 + text2 + text3 + text4 + text5 + text6 + text7 + text8 + text9 + text10
        virus_text = virus_text1 + virus_text2 + virus_text3 + virus_text4 + virus_text5 + virus_text6 + virus_text7 + \
                     virus_text8 + virus_text9 + virus_text10

    elif users_number == 11:
        text1, virus_text1 = send_money(user=winn_users[0], money=money, chat_id=chat_id, koefic=0.17)
        text2, virus_text2 = send_money(user=winn_users[1], money=money, chat_id=chat_id, koefic=0.15)
        text3, virus_text3 = send_money(user=winn_users[2], money=money, chat_id=chat_id, koefic=0.14)
        text4, virus_text4 = send_money(user=winn_users[3], money=money, chat_id=chat_id, koefic=0.12)
        text5, virus_text5 = send_money(user=winn_users[4], money=money, chat_id=chat_id, koefic=0.11)
        text6, virus_text6 = send_money(user=winn_users[5], money=money, chat_id=chat_id, koefic=0.09)
        text7, virus_text7 = send_money(user=winn_users[6], money=money, chat_id=chat_id, koefic=0.07)
        text8, virus_text8 = send_money(user=winn_users[7], money=money, chat_id=chat_id, koefic=0.06)
        text9, virus_text9 = send_money(user=winn_users[8], money=money, chat_id=chat_id, koefic=0.05)
        text10, virus_text10 = send_money(user=winn_users[9], money=money, chat_id=chat_id, koefic=0.03)
        text11, virus_text11 = send_money(user=winn_users[10], money=money, chat_id=chat_id, koefic=0.01)
        text = text1 + text2 + text3 + text4 + text5 + text6 + text7 + text8 + text9 + text10 + text11
        virus_text = virus_text1 + virus_text2 + virus_text3 + virus_text4 + virus_text5 + virus_text6 + virus_text7 + \
                     virus_text8 + virus_text9 + virus_text10 + virus_text11

    elif users_number == 12:
        text1, virus_text1 = send_money(user=winn_users[0], money=money, chat_id=chat_id, koefic=0.15)
        text2, virus_text2 = send_money(user=winn_users[1], money=money, chat_id=chat_id, koefic=0.14)
        text3, virus_text3 = send_money(user=winn_users[2], money=money, chat_id=chat_id, koefic=0.13)
        text4, virus_text4 = send_money(user=winn_users[3], money=money, chat_id=chat_id, koefic=0.12)
        text5, virus_text5 = send_money(user=winn_users[4], money=money, chat_id=chat_id, koefic=0.10)
        text6, virus_text6 = send_money(user=winn_users[5], money=money, chat_id=chat_id, koefic=0.09)
        text7, virus_text7 = send_money(user=winn_users[6], money=money, chat_id=chat_id, koefic=0.08)
        text8, virus_text8 = send_money(user=winn_users[7], money=money, chat_id=chat_id, koefic=0.06)
        text9, virus_text9 = send_money(user=winn_users[8], money=money, chat_id=chat_id, koefic=0.05)
        text10, virus_text10 = send_money(user=winn_users[9], money=money, chat_id=chat_id, koefic=0.04)
        text11, virus_text11 = send_money(user=winn_users[10], money=money, chat_id=chat_id, koefic=0.03)
        text12, virus_text12= send_money(user=winn_users[11], money=money, chat_id=chat_id, koefic=0.01)
        text = text1 + text2 + text3 + text4 + text5 + text6 + text7 + text8 + text9 + text10 + text11 + text12
        virus_text = virus_text1 + virus_text2 + virus_text3 + virus_text4 + virus_text5 + virus_text6 + virus_text7 + \
                     virus_text8 + virus_text9 + virus_text10 + virus_text11 + virus_text12

    elif users_number == 13:
        text1, virus_text1 = send_money(user=winn_users[0], money=money, chat_id=chat_id, koefic=0.14)
        text2, virus_text2 = send_money(user=winn_users[1], money=money, chat_id=chat_id, koefic=0.13)
        text3, virus_text3 = send_money(user=winn_users[2], money=money, chat_id=chat_id, koefic=0.12)
        text4, virus_text4 = send_money(user=winn_users[3], money=money, chat_id=chat_id, koefic=0.11)
        text5, virus_text5 = send_money(user=winn_users[4], money=money, chat_id=chat_id, koefic=0.10)
        text6, virus_text6 = send_money(user=winn_users[5], money=money, chat_id=chat_id, koefic=0.09)
        text7, virus_text7 = send_money(user=winn_users[6], money=money, chat_id=chat_id, koefic=0.08)
        text8, virus_text8 = send_money(user=winn_users[7], money=money, chat_id=chat_id, koefic=0.07)
        text9, virus_text9 = send_money(user=winn_users[8], money=money, chat_id=chat_id, koefic=0.06)
        text10, virus_text10 = send_money(user=winn_users[9], money=money, chat_id=chat_id, koefic=0.04)
        text11, virus_text11 = send_money(user=winn_users[10], money=money, chat_id=chat_id, koefic=0.03)
        text12, virus_text12 = send_money(user=winn_users[11], money=money, chat_id=chat_id, koefic=0.02)
        text13, virus_text13 = send_money(user=winn_users[12], money=money, chat_id=chat_id, koefic=0.01)
        text = text1 + text2 + text3 + text4 + text5 + text6 + text7 + text8 + text9 + text10 + text11 + text12 + text13
        virus_text = virus_text1 + virus_text2 + virus_text3 + virus_text4 + virus_text5 + virus_text6 + virus_text7 + \
                     virus_text8 + virus_text9 + virus_text10 + virus_text11 + virus_text12 + virus_text13
    text = 'Розыгрыш окончен\n\n' + virus_text + '\n' + f"{creator_nick} провел розыгрыш\n\n" + text
    return text


# Розыгрыш
async def raffle(message: types.Message):
    creator = message.from_user.id
    money = int(message.text.split(' ')[1])
    chat_id = message.chat.id
    number = 1
    user_id = message.from_user.id
    user_data = sqLite.read_values_by_name(table=f'all_users', data=user_id)
    is_raffle_work = sqLite.read_values_by_name(table=f'raffle', data=str(chat_id), id_name='chanel_id')

    if is_raffle_work is not None:
        await message.answer('Розыгрыш уже запущен')
        return

    if money < 2500 and 'dmin' not in user_data[7]:
        await message.answer('Минимальная сумма розыгрыша 2500 монет')
        return

    if user_data[2] < money:
        await message.answer('У вас недостаточно монет')
        return
    if money > 50000 and 'dmin' not in user_data[7]:
        await message.answer('Максимальная сумма розыгрыша 50к монет')
        return
    sqLite.insert_raffle(chanel_id=chat_id, creator_id=int(creator), money=int(money), tg_id=message.from_user.id)
    sqLite.insert_info(table=f'all_users', name='money', data=user_data[2] - money,
                       telegram_id=user_id)
    sqLite.ins_log(tg_id=str(user_id),
                   info=f'оплата розыгрыша в {message.chat.title}',
                   money=f"-{money}", chanel_id=message.chat.id)
    text = f"{message.from_user.first_name} предлагает принять участие в розыгрыше {money} монет, максимальное число " \
           f"участников 50.\n\n" \
           f"Участники:\n\n" \
           f"всего: {number}"
    await message.answer(text=text, reply_markup=raffle_start_kb(tg_id=creator, chat_id=chat_id, deal=str(money)))


# Розыгрыш присоедeняемся к розыгрышу
async def raffle_attach(call: types.CallbackQuery):
    creator = call.data.split('_')[3]
    money = call.data.split('_')[4]
    chat_id = call.message.chat.id
    number = sqLite.read_value_table_name(table='raffle', id_name='chanel_id', telegram_id=str(chat_id))
    check = False
    for raffle_man in number:
        if raffle_man[1] == call.from_user.id:
            check = True
        else:
            pass

    if len(number) >= 50:
        await call.message.answer('Максимальное число участников 50')
    elif check:
        pass
    else:
        sqLite.insert_raffle(chanel_id=chat_id, creator_id=int(creator), money=int(money), tg_id=call.from_user.id)
        user_data = sqLite.read_values_by_name(table=f'all_users', data=creator)
        text = f"{user_data[10]} предлагает принять участие в розыгрыше {money} монет, максимальное число " \
               f"участников 50.\n\n" \
               f"Участники:\n\n" \
               f"всего: {len(number)+1}"
        await call.message.edit_text(text=text, reply_markup=raffle_start_kb(tg_id=int(creator), chat_id=chat_id,
                                                                             deal=money))


# Розыгрыш отмена
async def raffle_close(call: types.CallbackQuery):
    creator = call.data.split('_')[3]
    money = call.data.split('_')[4]
    chat_id = call.data.split('_')[2]
    user_id = call.from_user.id
    if user_id == int(creator):
        user_data = sqLite.read_values_by_name(table=f'all_users', data=user_id)
        all_chat_users = sqLite.read_value_table_name(table=f'raffle', id_name='chanel_id',
                                                      telegram_id=str(chat_id))
        clear_raffle(all_chat_users)

        sqLite.insert_info(table=f'all_users', name='money', data=user_data[2] + int(money),
                           telegram_id=user_id)
        sqLite.ins_log(tg_id=str(user_id),
                       info=f'возврат за отмену розыгрыша {call.message.chat.title}',
                       money=f"+{money}", chanel_id=call.message.chat.id)

        await call.message.edit_text('Розыгрыш отменен')


# Удаляем всех лишних из базы данных
def clear_raffle(all_chat_users: tuple):
    for user in all_chat_users:
        sqLite.delete_str(table='raffle', name="id", data=user[0])


# Розыгрыш запуск
async def raffle_start_btn(call: types.CallbackQuery):
    chat_id = call.message.chat.id
    user_id = call.from_user.id
    money = call.data.split('_')[4]
    creator = call.data.split('_')[3]
    if user_id != int(creator):
        return
    if money.isdigit():
        if user_id == chat_id:
            pass
        else:
            all_chat_users = sqLite.read_value_table_name(table=f'raffle', id_name='chanel_id',
                                                          telegram_id=str(chat_id))
            users_number = len(all_chat_users)

            user_data = sqLite.read_values_by_name(table=f'all_users', data=user_id)
            if user_data[2] < int(money):
                await call.message.answer("У вас недостаточно монет")
            elif int(money) > 50000:
                await call.message.answer("Максимальная сумма 50k монет")
            else:

                if 2 <= users_number <= 7:
                    win_users = pick_users(all_chat_users=all_chat_users, number=2)

                elif 8 <= users_number <= 11:
                    win_users = pick_users(all_chat_users=all_chat_users, number=3)

                elif 12 <= users_number <= 15:
                    win_users = pick_users(all_chat_users=all_chat_users, number=4)

                elif 16 <= users_number <= 19:
                    win_users = pick_users(all_chat_users=all_chat_users, number=5)

                elif 20 <= users_number <= 23:
                    win_users = pick_users(all_chat_users=all_chat_users, number=6)

                elif 24 <= users_number <= 27:
                    win_users = pick_users(all_chat_users=all_chat_users, number=7)

                elif 28 <= users_number <= 31:
                    win_users = pick_users(all_chat_users=all_chat_users, number=8)

                elif 32 <= users_number <= 35:
                    win_users = pick_users(all_chat_users=all_chat_users, number=9)

                elif 36 <= users_number <= 39:
                    win_users = pick_users(all_chat_users=all_chat_users, number=10)

                elif 40 <= users_number <= 43:
                    win_users = pick_users(all_chat_users=all_chat_users, number=11)

                elif 44 <= users_number <= 47:
                    win_users = pick_users(all_chat_users=all_chat_users, number=12)

                else:
                    win_users = pick_users(all_chat_users=all_chat_users, number=13)

                text = win_users_gifts(winn_users=win_users, chat_id=str(chat_id), money=int(money),
                                       creator_nick=call.from_user.first_name)

                await call.message.edit_text(text=f"{text}", parse_mode='html')
                clear_raffle(all_chat_users)


# парсим колбэки
async def pars_calls_raffle(call: types.CallbackQuery):
    call_data = call.data
    if call_data.startswith('raffle_attach_'):
        await raffle_attach(call)
    elif call_data.startswith('raffle_close_'):
        await raffle_close(call)
    elif call_data.startswith('raffle_start_'):
        await raffle_start_btn(call)
    else:
        pass
