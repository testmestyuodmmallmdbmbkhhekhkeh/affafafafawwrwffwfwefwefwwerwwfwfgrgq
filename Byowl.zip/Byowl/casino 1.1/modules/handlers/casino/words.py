import asyncio
import datetime
import random
from modules import sqLite
from modules.handlers.casino.read_and_save_data import read_and_save_data, read_and_save_words
from modules.dispatcher import bot
from aiogram import types
from modules.keyboards import words_start_kb

letters = 'абвгдеёжзийклмнопрстуфхцчшщъыьэюя'


async def create_words(message: types.Message, rep_tg_id: int = None):
    tg_id = message.chat.id
    chat_data = sqLite.read_values_by_name(table=f'chats', data=str(tg_id), id_name='chat_id')[5]
    if chat_data == 1:
        await message.answer('Буквы в этом чате запрещены')
    elif chat_data == 0:
        try:
            deal = message.text.split(' ')[1]
        except:
            deal = 500
        user_id = message.from_user.id
        money = int(sqLite.read_values_by_name(table='all_users', data=user_id)[2])
        if money < int(deal):
            await message.answer(f'{message.from_user.first_name}, ставка не может превышать ваши средства')
        else:
            if rep_tg_id is None:
                await message.answer(f'{message.from_user.first_name} предлагает сыграть в буквы! Ставка: {deal}',
                                     reply_markup=words_start_kb(chat_id=tg_id, tg_id=message.from_user.id, deal=deal))
                sqLite.ins_log(tg_id=str(user_id), info=f'Предлагает сыграть в буквы', money=f"{deal}", chanel_id=tg_id)
            else:
                await message.answer(f'{message.from_user.first_name} предлагает сыграть в буквы! Ставка: {deal}',
                                     reply_markup=words_start_kb(chat_id=tg_id, tg_id=message.from_user.id, deal=deal,
                                                                 rep_tg_id=rep_tg_id))
                sqLite.ins_log(tg_id=str(user_id), info=f'Предлагает сыграть в буквы', money=f"{deal}", chanel_id=tg_id)


# Начинаем игру
async def start_words(call: types.CallbackQuery):
    chat_id = call.data.split('_')[2]
    if '-' in str(chat_id):
        chat_id = str(chat_id)[1:]
    else:
        chat_id = str(chat_id)
    money = call.data.split('_')[5]
    tg_user_1 = call.data.split('_')[3]
    tg_user_2 = call.from_user.id
    user_data = sqLite.read_values_by_name(table=f'all_users', data=tg_user_1)
    user_1 = user_data[10]
    user_2 = call.from_user.first_name
    number_1 = 0
    number_2 = 0
    l_array = ''
    user_data_2 = sqLite.read_values_by_name(table='all_users', data=tg_user_2)

    sqLite.insert_info(table=f'all_users', name='money', data=int(user_data[2]) - int(money),
                       telegram_id=tg_user_1)
    sqLite.insert_info(table=f'all_users', name='money', data=int(user_data_2[2]) - int(money),
                       telegram_id=tg_user_2)
    for i in range(0, 36):
        l_array = l_array + random.choice(letters)
    sqLite.insert_all_info_words(chat_id=chat_id, tg_id_1=tg_user_1, tg_id_2=tg_user_2, money=money,
                                 start_time=datetime.datetime.now(), score_1=0, score_2=0, words_1=str(l_array),
                                 words_2=str(l_array), nick_1=user_1, nick_2=user_2, status='active')

    time = 180
    l_2 = l_1 = l_array.upper()
    minuts = time // 60
    seconds = time % 60

    text = f"1️⃣{user_1}: {number_1}💡\n" \
           f"2️⃣{user_2}: {number_2}💡\n" \
           f"          1           |           2          \n" \
           f"---------------------------\n" \
           f"<code>{l_1[0]} {l_1[1]} {l_1[2]} {l_1[3]}   |   {l_2[0]} {l_2[1]} {l_2[2]} {l_2[3]} \n" \
           f"{l_1[4]} {l_1[5]} {l_1[6]} {l_1[7]}   |   {l_2[4]} {l_2[5]} {l_2[6]} {l_2[7]} \n" \
           f"{l_1[8]} {l_1[9]} {l_1[10]} {l_1[11]}   |   {l_2[8]} {l_2[9]} {l_2[10]} {l_2[11]}\n" \
           f"{l_1[12]} {l_1[13]} {l_1[14]} {l_1[15]}   |   {l_2[12]} {l_2[13]} {l_2[14]} {l_2[15]}\n" \
           f"{l_1[16]} {l_1[17]} {l_1[18]} {l_1[19]}   |   {l_2[16]} {l_2[17]} {l_2[18]} {l_2[19]}\n" \
           f"{l_1[20]} {l_1[21]} {l_1[22]} {l_1[23]}   |   {l_2[20]} {l_2[21]} {l_2[22]} {l_2[23]}\n" \
           f"{l_1[24]} {l_1[25]} {l_1[26]} {l_1[27]}   |   {l_2[24]} {l_2[25]} {l_2[26]} {l_2[27]}\n" \
           f"{l_1[28]} {l_1[29]} {l_1[30]} {l_1[31]}   |   {l_2[28]} {l_2[29]} {l_2[30]} {l_2[31]}\n" \
           f"{l_1[32]} {l_1[33]} {l_1[34]} {l_1[35]}   |   {l_2[32]} {l_2[33]} {l_2[34]} {l_2[35]}\n</code>" \
           f"Использованные слова: <b></b>\n" \
           f"осталось: {minuts}м {seconds}с"
    await call.message.edit_text(text=text, parse_mode='html')
    status = 'active'
    while time > 0 and status == 'active':
        await asyncio.sleep(5)
        status = str(sqLite.read_values_by_name(table=f'words', id_name='tg_id_1', data=int(tg_user_1))[12])
        time = time - 5
        minuts = time // 60
        seconds = time % 60
        text = f"1️⃣{user_1}: {number_1}💡\n" \
               f"2️⃣{user_2}: {number_2}💡\n" \
               f"          1           |           2          \n" \
               f"---------------------------\n" \
               f"<code>{l_1[0]} {l_1[1]} {l_1[2]} {l_1[3]}   |   {l_2[0]} {l_2[1]} {l_2[2]} {l_2[3]} \n" \
               f"{l_1[4]} {l_1[5]} {l_1[6]} {l_1[7]}   |   {l_2[4]} {l_2[5]} {l_2[6]} {l_2[7]} \n" \
               f"{l_1[8]} {l_1[9]} {l_1[10]} {l_1[11]}   |   {l_2[8]} {l_2[9]} {l_2[10]} {l_2[11]}\n" \
               f"{l_1[12]} {l_1[13]} {l_1[14]} {l_1[15]}   |   {l_2[12]} {l_2[13]} {l_2[14]} {l_2[15]}\n" \
               f"{l_1[16]} {l_1[17]} {l_1[18]} {l_1[19]}   |   {l_2[16]} {l_2[17]} {l_2[18]} {l_2[19]}\n" \
               f"{l_1[20]} {l_1[21]} {l_1[22]} {l_1[23]}   |   {l_2[20]} {l_2[21]} {l_2[22]} {l_2[23]}\n" \
               f"{l_1[24]} {l_1[25]} {l_1[26]} {l_1[27]}   |   {l_2[24]} {l_2[25]} {l_2[26]} {l_2[27]}\n" \
               f"{l_1[28]} {l_1[29]} {l_1[30]} {l_1[31]}   |   {l_2[28]} {l_2[29]} {l_2[30]} {l_2[31]}\n" \
               f"{l_1[32]} {l_1[33]} {l_1[34]} {l_1[35]}   |   {l_2[32]} {l_2[33]} {l_2[34]} {l_2[35]}\n</code>" \
               f"Использованные слова: <b></b>\n" \
               f"осталось: {minuts}м {seconds}с"
        await call.message.edit_text(text=text, parse_mode='html')
    if status == 'close':
        try:
            await bot.delete_message(message_id=call.message.message_id, chat_id=call.message.chat.id)
        except:
            pass
        sqLite.delete_str(table=f'words', name='tg_id_1', data=int(tg_user_1))
    elif status != 'active':
        try:
            await bot.delete_message(message_id=call.message.message_id, chat_id=call.message.chat.id)
        except:
            pass
    if time <= 0:
        read_and_save_data(tg_id=int(tg_user_1), deal=int(user_data[2]), income=int(money))
        read_and_save_data(tg_id=tg_user_2, deal=int(user_data_2[2]), income=int(money))
        sqLite.ins_log(tg_id=str(tg_user_1), info=f'ничья в буквы', money=f"{money}", chanel_id=f'{chat_id}',
                       victem_id=str(tg_user_2))
        sqLite.ins_log(tg_id=str(tg_user_2), info=f'ничья в буквы', money=f"{money}", chanel_id=f'{chat_id}',
                       victem_id=str(tg_user_1))
        text = f"Игра окончена!\n" \
               f"Победителя нет\n" \
               f"Использованные слова: "
        await bot.edit_message_text(text=text, parse_mode='html', chat_id=call.message.chat.id,
                                    message_id=call.message.message_id + 1)


# Продолжаем
async def main_words(message: types.Message):
    tg_user_1 = message.from_user.id
    with open('modules/ru.txt', 'r', encoding='utf-8') as file:
        diction = file.read()
        diction = diction.split('\n')
        line_1 = sqLite.read_values_by_name(table=f'words', id_name='tg_id_1', data=tg_user_1)
        line_2 = sqLite.read_values_by_name(table=f'words', id_name='tg_id_2', data=tg_user_1)

        if line_1 is None:
            if line_2 is None:
                print('Ошибка БД')
            else:
                if str(line_2[1]) == str(message.chat.id)[1:]:
                    line = line_2[9]
                    await words_line_2(diction, line, message)

        elif str(line_1[1]) == str(message.chat.id)[1:]:
            line = line_1[8]
            await words_line_1(diction, line, message)


# выносная функция для line1
async def words_line_1(diction, line: str, message: types.Message):
    chanel_id = message.chat.id
    tg_user_1 = message.from_user.id
    line_1 = sqLite.read_values_by_name(table=f'words', id_name='tg_id_1', data=tg_user_1)
    # проверяем есть ли слово в словаре
    if message.text.lower() in diction:
        # проверка на есть ли такие буквы
        status = True
        for b in message.text.lower():
            if b in line:
                parts = line.split(b)
                line = parts[0] + '*' + str(line[len(parts[0]) + 1:])

            else:
                status = False
                break

        #  Пропускаем если нет всех таких букв:
        if not status or message.text.lower() in str(line_1[13]).lower():
            pass
        else:
            if 'None' == str(line_1[13]):
                words = message.text.lower()
            else:
                words = f"{str(line_1[13])}, {message.text.lower()}"
            sqLite.insert_info(table=f'words', id_name='tg_id_1', telegram_id=tg_user_1, name='words',
                               data=words)
            line_1 = sqLite.read_values_by_name(table=f'words', id_name='tg_id_1', data=tg_user_1)
            number_1 = int(line_1[6]) + len(message.text) * len(message.text)
            number_2 = str(line_1[7])
            user_1 = str(line_1[10])
            user_2 = str(line_1[11])
            await read_and_save_words(message)
            l_1 = line.upper()
            l_2 = str(line_1[9]).upper()
            # Получаем и определяем оставшееся время
            start_time = str(line_1[5]).split('.')[0]
            start_time = datetime.datetime.strptime(str(start_time), "%Y-%m-%d %H:%M:%S")
            time_deal = datetime.datetime.now() - start_time

            time = 180 - int(time_deal.seconds)
            sqLite.insert_info(table=f'words', id_name='tg_id_1', telegram_id=tg_user_1, name='score_1',
                               data=number_1)
            sqLite.insert_info(table=f'words', id_name='tg_id_1', telegram_id=tg_user_1, name='words_1',
                               data=line)
            sqLite.insert_info(table=f'words', id_name='tg_id_1', telegram_id=tg_user_1, name='status',
                               data='off')

            minuts = time // 60
            seconds = time % 60

            text = f"1️⃣{user_1}: {number_1}💡\n" \
                   f"2️⃣{user_2}: {number_2}💡\n" \
                   f"          1           |           2          \n" \
                   f"---------------------------\n" \
                   f"<code>{l_1[0]} {l_1[1]} {l_1[2]} {l_1[3]}   |   {l_2[0]} {l_2[1]} {l_2[2]} {l_2[3]} \n" \
                   f"{l_1[4]} {l_1[5]} {l_1[6]} {l_1[7]}   |   {l_2[4]} {l_2[5]} {l_2[6]} {l_2[7]} \n" \
                   f"{l_1[8]} {l_1[9]} {l_1[10]} {l_1[11]}   |   {l_2[8]} {l_2[9]} {l_2[10]} {l_2[11]}\n" \
                   f"{l_1[12]} {l_1[13]} {l_1[14]} {l_1[15]}   |   {l_2[12]} {l_2[13]} {l_2[14]} {l_2[15]}\n" \
                   f"{l_1[16]} {l_1[17]} {l_1[18]} {l_1[19]}   |   {l_2[16]} {l_2[17]} {l_2[18]} {l_2[19]}\n" \
                   f"{l_1[20]} {l_1[21]} {l_1[22]} {l_1[23]}   |   {l_2[20]} {l_2[21]} {l_2[22]} {l_2[23]}\n" \
                   f"{l_1[24]} {l_1[25]} {l_1[26]} {l_1[27]}   |   {l_2[24]} {l_2[25]} {l_2[26]} {l_2[27]}\n" \
                   f"{l_1[28]} {l_1[29]} {l_1[30]} {l_1[31]}   |   {l_2[28]} {l_2[29]} {l_2[30]} {l_2[31]}\n" \
                   f"{l_1[32]} {l_1[33]} {l_1[34]} {l_1[35]}   |   {l_2[32]} {l_2[33]} {l_2[34]} {l_2[35]}\n</code>" \
                   f"Использованные слова: <b>{line_1[13]}</b>\n" \
                   f"осталось: {minuts}м {seconds}с"
            await message.answer(text=text, parse_mode='html')
            await asyncio.sleep(5)
            sqLite.insert_info(table=f'words', id_name='tg_id_1', telegram_id=tg_user_1, name='status',
                               data='active')
            status = 'active'
            while time > 0 and status == 'active':

                status = str(sqLite.read_values_by_name(table=f'words', id_name='tg_id_1', data=int(tg_user_1))[12])
                time = time - 5
                if time < 0:
                    time = 0
                minuts = time // 60
                seconds = time % 60

                text = f"1️⃣{user_1}: {number_1}💡\n" \
                       f"2️⃣{user_2}: {number_2}💡\n" \
                       f"          1           |           2          \n" \
                       f"---------------------------\n" \
                       f"<code>{l_1[0]} {l_1[1]} {l_1[2]} {l_1[3]}   |   {l_2[0]} {l_2[1]} {l_2[2]} {l_2[3]} \n" \
                       f"{l_1[4]} {l_1[5]} {l_1[6]} {l_1[7]}   |   {l_2[4]} {l_2[5]} {l_2[6]} {l_2[7]} \n" \
                       f"{l_1[8]} {l_1[9]} {l_1[10]} {l_1[11]}   |   {l_2[8]} {l_2[9]} {l_2[10]} {l_2[11]}\n" \
                       f"{l_1[12]} {l_1[13]} {l_1[14]} {l_1[15]}   |   {l_2[12]} {l_2[13]} {l_2[14]} {l_2[15]}\n" \
                       f"{l_1[16]} {l_1[17]} {l_1[18]} {l_1[19]}   |   {l_2[16]} {l_2[17]} {l_2[18]} {l_2[19]}\n" \
                       f"{l_1[20]} {l_1[21]} {l_1[22]} {l_1[23]}   |   {l_2[20]} {l_2[21]} {l_2[22]} {l_2[23]}\n" \
                       f"{l_1[24]} {l_1[25]} {l_1[26]} {l_1[27]}   |   {l_2[24]} {l_2[25]} {l_2[26]} {l_2[27]}\n" \
                       f"{l_1[28]} {l_1[29]} {l_1[30]} {l_1[31]}   |   {l_2[28]} {l_2[29]} {l_2[30]} {l_2[31]}\n" \
                       f"{l_1[32]} {l_1[33]} {l_1[34]} {l_1[35]}   |   {l_2[32]} {l_2[33]} {l_2[34]} {l_2[35]}\n" \
                       f"</code>" \
                       f"Использованные слова: <b>{line_1[13]}</b>\n" \
                       f"осталось: {minuts}м {seconds}с"
                await bot.edit_message_text(text=text, parse_mode='html', chat_id=message.chat.id,
                                            message_id=message.message_id + 1)
                await asyncio.sleep(5)
            if status == 'close':
                try:
                    await bot.delete_message(message_id=message.message_id, chat_id=message.chat.id)
                except:
                    pass
                sqLite.delete_str(table=f'words', name='tg_id_1', data=int(tg_user_1))
            elif status != 'active':
                try:
                    await bot.delete_message(message_id=message.message_id + 1, chat_id=message.chat.id)
                except:
                    pass
            if time <= 0:
                if number_1 > int(number_2):
                    read_and_save_data(tg_id=tg_user_1, deal=int(line_1[4]), income=int(line_1[4]) * 2)
                    sqLite.ins_log(tg_id=tg_user_1, info=f'выигрыш в буквы', money=f'+{line_1[4]}',
                                   chanel_id=f'{chanel_id}', victem_id=line_1[3])
                    sqLite.ins_log(tg_id=line_1[3], info=f'проигрыш в буквы', money=f'-{line_1[4]}',
                                   chanel_id=f'{chanel_id}', victem_id=tg_user_1)
                    text = f'Игра окончена!\n\n' \
                           f'Победитель {user_1}\n' \
                           f'Проиграл {user_2}\n\n' \
                           f'Выигрыш: {int(line_1[4]) * 2} монет\n' \
                           f'Использованные слова: {line_1[13]}'
                elif number_1 < int(number_2):
                    read_and_save_data(tg_id=line_1[3], deal=int(line_1[4]), income=int(line_1[4]) * 2)
                    sqLite.ins_log(tg_id=line_1[3], info=f'выигрыш в буквы', money=f'+{line_1[4]}',
                                   chanel_id=f'{chanel_id}', victem_id=tg_user_1)
                    sqLite.ins_log(tg_id=tg_user_1, info=f'проигрыш в буквы', money=f'-{line_1[4]}',
                                   chanel_id=f'{chanel_id}', victem_id=line_1[3])
                    text = f'Игра окончена!\n\n' \
                           f'Победитель {user_2}\n' \
                           f'Проиграл {user_1}\n\n' \
                           f'Выигрыш: {int(line_1[4]) * 2} монет\n' \
                           f'Использованные слова: {line_1[13]}'
                else:
                    read_and_save_data(tg_id=tg_user_1, deal=int(line_1[4]), income=int(line_1[4]))
                    read_and_save_data(tg_id=line_1[3], deal=int(line_1[4]), income=int(line_1[4]))
                    sqLite.ins_log(tg_id=str(tg_user_1), info=f'ничья в буквы', money=f'{line_1[4]}',
                                   chanel_id=f'{chanel_id}', victem_id=line_1[3])
                    sqLite.ins_log(tg_id=str(line_1[3]), info=f'ничья в буквы', money=f'{line_1[4]}',
                                   chanel_id=f'{chanel_id}', victem_id=tg_user_1)
                    text = f"Игра окончена!\n" \
                           f"Победителя нет\n" \
                           f"Использованные слова: {line_1[13]}"

                await bot.edit_message_text(text=text, parse_mode='html', chat_id=message.chat.id,
                                            message_id=message.message_id + 1)
                sqLite.delete_str(table=f'words', name='tg_id_1', data=tg_user_1)


# выносная функция для line2
async def words_line_2(diction, line: str, message: types.Message):
    chanel_id = message.chat.id
    tg_user_2 = message.from_user.id
    line_2 = sqLite.read_values_by_name(table=f'words', id_name='tg_id_2', data=tg_user_2)
    # проверяем есть ли слово в словаре
    if message.text.lower() in diction:
        #         проверка на есть ли такие буквы
        status = True
        for b in message.text.lower():
            if b in line:
                parts = line.split(b)
                line = parts[0] + '*' + str(line[len(parts[0]) + 1:])

            else:
                status = False
                break

        #  Пропускаем если нет всех таких букв:
        if not status or message.text.lower() in str(line_2[13]).lower():
            pass
        else:
            if 'None' == str(line_2[13]):
                words = message.text.lower()
            else:
                words = f"{str(line_2[13])}, {message.text.lower()}"
            sqLite.insert_info(table=f'words', id_name='tg_id_2', telegram_id=tg_user_2, name='words',
                               data=words)
            line_1 = sqLite.read_values_by_name(table=f'words', id_name='tg_id_2', data=tg_user_2)
            number_1 = str(line_1[6])
            number_2 = int(line_1[7]) + len(message.text) * len(message.text)
            user_1 = str(line_1[10])
            user_2 = str(line_1[11])
            l_1 = str(line_1[8]).upper()
            l_2 = line.upper()
            await read_and_save_words(message)
            # Получаем и определяем оставшееся время
            start_time = str(line_1[5]).split('.')[0]
            start_time = datetime.datetime.strptime(str(start_time), "%Y-%m-%d %H:%M:%S")
            time_deal = datetime.datetime.now() - start_time

            time = 180 - int(time_deal.seconds)
            sqLite.insert_info(table=f'words', id_name='tg_id_2', telegram_id=tg_user_2, name='score_2',
                               data=number_2)
            sqLite.insert_info(table=f'words', id_name='tg_id_2', telegram_id=tg_user_2, name='words_2',
                               data=line)
            sqLite.insert_info(table=f'words', id_name='tg_id_2', telegram_id=tg_user_2, name='status',
                               data='off')

            minuts = time // 60
            seconds = time % 60
            text = f"1️⃣{user_1}: {number_1}💡\n" \
                   f"2️⃣{user_2}: {number_2}💡\n" \
                   f"          1           |           2          \n" \
                   f"---------------------------\n" \
                   f"<code>{l_1[0]} {l_1[1]} {l_1[2]} {l_1[3]}   |   {l_2[0]} {l_2[1]} {l_2[2]} {l_2[3]} \n" \
                   f"{l_1[4]} {l_1[5]} {l_1[6]} {l_1[7]}   |   {l_2[4]} {l_2[5]} {l_2[6]} {l_2[7]} \n" \
                   f"{l_1[8]} {l_1[9]} {l_1[10]} {l_1[11]}   |   {l_2[8]} {l_2[9]} {l_2[10]} {l_2[11]}\n" \
                   f"{l_1[12]} {l_1[13]} {l_1[14]} {l_1[15]}   |   {l_2[12]} {l_2[13]} {l_2[14]} {l_2[15]}\n" \
                   f"{l_1[16]} {l_1[17]} {l_1[18]} {l_1[19]}   |   {l_2[16]} {l_2[17]} {l_2[18]} {l_2[19]}\n" \
                   f"{l_1[20]} {l_1[21]} {l_1[22]} {l_1[23]}   |   {l_2[20]} {l_2[21]} {l_2[22]} {l_2[23]}\n" \
                   f"{l_1[24]} {l_1[25]} {l_1[26]} {l_1[27]}   |   {l_2[24]} {l_2[25]} {l_2[26]} {l_2[27]}\n" \
                   f"{l_1[28]} {l_1[29]} {l_1[30]} {l_1[31]}   |   {l_2[28]} {l_2[29]} {l_2[30]} {l_2[31]}\n" \
                   f"{l_1[32]} {l_1[33]} {l_1[34]} {l_1[35]}   |   {l_2[32]} {l_2[33]} {l_2[34]} {l_2[35]}\n</code>" \
                   f"Использованные слова: <b>{line_1[13]}</b>\n" \
                   f"осталось: {minuts}м {seconds}с"
            await message.answer(text=text, parse_mode='html')
            await asyncio.sleep(5)
            sqLite.insert_info(table=f'words', id_name='tg_id_2', telegram_id=tg_user_2, name='status',
                               data='active')
            status = 'active'
            while time > 0 and status == 'active':

                status = str(sqLite.read_values_by_name(table=f'words', id_name='tg_id_2', data=int(tg_user_2))[12])
                time = time - 5
                if time < 0:
                    time = 0
                minuts = time // 60
                seconds = time % 60
                text = f"1️⃣{user_1}: {number_1}💡\n" \
                       f"2️⃣{user_2}: {number_2}💡\n" \
                       f"          1           |           2          \n" \
                       f"---------------------------\n" \
                       f"<code>{l_1[0]} {l_1[1]} {l_1[2]} {l_1[3]}   |   {l_2[0]} {l_2[1]} {l_2[2]} {l_2[3]} \n" \
                       f"{l_1[4]} {l_1[5]} {l_1[6]} {l_1[7]}   |   {l_2[4]} {l_2[5]} {l_2[6]} {l_2[7]} \n" \
                       f"{l_1[8]} {l_1[9]} {l_1[10]} {l_1[11]}   |   {l_2[8]} {l_2[9]} {l_2[10]} {l_2[11]}\n" \
                       f"{l_1[12]} {l_1[13]} {l_1[14]} {l_1[15]}   |   {l_2[12]} {l_2[13]} {l_2[14]} {l_2[15]}\n" \
                       f"{l_1[16]} {l_1[17]} {l_1[18]} {l_1[19]}   |   {l_2[16]} {l_2[17]} {l_2[18]} {l_2[19]}\n" \
                       f"{l_1[20]} {l_1[21]} {l_1[22]} {l_1[23]}   |   {l_2[20]} {l_2[21]} {l_2[22]} {l_2[23]}\n" \
                       f"{l_1[24]} {l_1[25]} {l_1[26]} {l_1[27]}   |   {l_2[24]} {l_2[25]} {l_2[26]} {l_2[27]}\n" \
                       f"{l_1[28]} {l_1[29]} {l_1[30]} {l_1[31]}   |   {l_2[28]} {l_2[29]} {l_2[30]} {l_2[31]}\n" \
                       f"{l_1[32]} {l_1[33]} {l_1[34]} {l_1[35]}   |   {l_2[32]} {l_2[33]} {l_2[34]} {l_2[35]}\n" \
                       f"</code>" \
                       f"Использованные слова: <b>{line_1[13]}</b>\n" \
                       f"осталось: {minuts}м {seconds}с"
                await bot.edit_message_text(text=text, parse_mode='html', chat_id=message.chat.id,
                                            message_id=message.message_id + 1)
                await asyncio.sleep(5)
            if status == 'close':
                try:
                    await bot.delete_message(message_id=message.message_id, chat_id=message.chat.id)
                except:
                    pass
                sqLite.delete_str(table=f'words', name='tg_id_2', data=int(tg_user_2))
            elif status != 'active':
                await bot.delete_message(message_id=message.message_id + 1, chat_id=message.chat.id)
            if time <= 0:
                if int(number_1) > number_2:
                    read_and_save_data(tg_id=line_1[2], deal=int(line_1[4]), income=int(line_1[4]) * 2)

                    sqLite.ins_log(tg_id=line_1[2], info=f'победа в буквы', money=f'+{line_1[4]}',
                                   chanel_id=f'{chanel_id}', victem_id=tg_user_2)
                    sqLite.ins_log(tg_id=tg_user_2, info=f'проигрыш в буквы', money=f'-{line_1[4]}',
                                   chanel_id=f'{chanel_id}', victem_id=line_1[2])

                    text = f'Игра окончена!\n\n' \
                           f'Победитель {user_1}\n' \
                           f'Проиграл {user_2}\n\n' \
                           f'Выигрыш: {int(line_1[4]) * 2} монет\n' \
                           f'Использованные слова: {line_1[13]}'
                elif int(number_1) < number_2:
                    read_and_save_data(tg_id=tg_user_2, deal=int(line_1[4]), income=int(line_1[4]) * 2)
                    sqLite.ins_log(tg_id=tg_user_2, info=f'выигрыш в буквы', money=f'+{line_1[4]}', chanel_id=f'{chanel_id}', victem_id=line_1[2])
                    sqLite.ins_log(tg_id=line_1[2], info=f'проигрыш в буквы', money=f'-{line_1[4]}', chanel_id=f'{chanel_id}', victem_id=tg_user_2)
                    text = f'Игра окончена!\n\n' \
                           f'Победитель {user_2}\n' \
                           f'Проиграл {user_1}\n\n' \
                           f'Выигрыш: {int(line_1[4]) * 2} монет\n' \
                           f'Использованные слова: {line_1[13]}'
                else:
                    read_and_save_data(tg_id=tg_user_2, deal=int(line_1[4]), income=int(line_1[4]))
                    read_and_save_data(tg_id=line_1[2], deal=int(line_1[4]), income=int(line_1[4]))
                    sqLite.ins_log(tg_id=tg_user_2, info=f'ничья в буквы', money=f'{line_1[4]}',
                                   chanel_id=f'{chanel_id}', victem_id=line_1[2])
                    sqLite.ins_log(tg_id=line_1[2], info=f'ничья в буквы', money=f'{line_1[4]}',
                                   chanel_id=f'{chanel_id}', victem_id=tg_user_2)
                    text = f"Игра окончена!\n" \
                           f"Победителя нет\n" \
                           f"Использованные слова: {line_1[13]}"

                await bot.edit_message_text(text=text, parse_mode='html', chat_id=message.chat.id,
                                            message_id=message.message_id + 1)
                sqLite.delete_str(table=f'words', name='tg_id_2', data=tg_user_2)


# Конец игры когда сдался
async def close_words(message: types.Message):
    chanel_id = message.chat.id
    line_1 = sqLite.read_values_by_name(table=f'words', id_name='tg_id_1', data=message.from_user.id)
    line_2 = sqLite.read_values_by_name(table=f'words', id_name='tg_id_2', data=message.from_user.id)

    if line_1 is None:
        if line_2 is None:
            print('Ошибка БД')
        else:
            if str(line_2[1]) == str(message.chat.id)[1:]:
                tg_1 = int(line_2[2])
                tg_2 = int(line_2[3])
                deal = int(line_2[4])

    elif str(line_1[1]) == str(message.chat.id)[1:]:
        tg_1 = int(line_1[2])
        tg_2 = int(line_1[3])
        deal = int(line_1[4])

    sqLite.insert_info(table=f'words', id_name='tg_id_1', telegram_id=tg_1, name='status',
                       data='close')

    user_1 = sqLite.read_values_by_name(table='all_users', data=tg_1)
    user_2 = sqLite.read_values_by_name(table='all_users', data=tg_2)
    if message.from_user.id == tg_1:
        sqLite.ins_log(tg_id=str(tg_2), info=f'выигрыш в буквы', money=f'+{line_1[4]}', chanel_id=f'{chanel_id}',
                       victem_id=str(tg_1))
        sqLite.ins_log(tg_id=str(tg_1), info=f'проигрыш в буквы', money=f'-{line_1[4]}', chanel_id=f'{chanel_id}',
                       victem_id=str(tg_2))
        read_and_save_data(tg_id=tg_2, deal=deal, income=deal * 2)
        await message.answer(f'Игра окончена!\n\n'
                             f'Победитель {user_2[10]}\n'
                             f'Проиграл {user_1[10]}\n\n'
                             f'Выигрыш: {deal} монет')
    else:
        sqLite.ins_log(tg_id=str(tg_1), info=f'выигрыш в буквы', money=f'+{line_2[4]}', chanel_id=f'{chanel_id}',
                       victem_id=str(tg_2))
        sqLite.ins_log(tg_id=str(tg_2), info=f'проигрыш в буквы', money=f'-{line_2[4]}', chanel_id=f'{chanel_id}',
                       victem_id=str(tg_1))

        read_and_save_data(tg_id=tg_1, deal=deal, income=deal * 2)
        await message.answer(f'Игра окончена!\n\n'
                             f'Победитель {user_1[10]}\n'
                             f'Проиграл {user_2[10]}\n\n'
                             f'Выигрыш: {deal} монет')


# Отмена игры до начала
async def close_words_on_start(call: types.CallbackQuery):
    tg_1 = int(call.data.split('_')[3])
    tg_2 = call.data.split('_')[4]
    if tg_2 == 'free':
        if call.from_user.id == tg_1:
            await call.message.edit_text("Игра была отменена")

        else:
            await bot.answer_callback_query(call.id)
    else:
        if call.from_user.id == tg_1 or call.from_user.id == int(tg_2):
            await call.message.edit_text("Игра была отменена")
        else:
            await bot.answer_callback_query(call.id)


def match(mes_text, alphabet):
    alphabet = set(alphabet)
    return set(mes_text.lower()).issubset(alphabet)


async def check_words(message: types.Message):
    text = message.text.lower()
    alphabet = set(letters)
    if len(text) < 2:
        pass
    elif set(text).issubset(alphabet):
        await main_words(message)


# Проверяем на free
async def call_words(call: types.CallbackQuery):
    await bot.answer_callback_query(call.id)
    chat_id = call.data.split('_')[2]
    tg_user_id = call.data.split('_')[4]
    if int(chat_id) == call.message.chat.id:
        if tg_user_id == 'free':
            await start_words(call)
        else:
            if int(tg_user_id) == call.from_user.id:
                await start_words(call)
            else:
                pass
