from aiogram import types
from modules import sqLite


# Показываем историю
async def history(message: types.Message):
    user_id = message.from_user.id
    user_data = sqLite.read_values_by_name(table=f'all_users', data=user_id)[7]
    chat_data = sqLite.read_all(table=f'log{user_id}')
    if len(chat_data) > 40:
        iteration = len(chat_data) - 40
        for i in range(0, iteration):
            id = chat_data[i][0]
            sqLite.delete_str(table=f'log{user_id}', name='id', data=id)
    else:
        pass

    if str(user_data) == 'mainAdmin' or str(user_data) == 'admin':
        text = ''
        chat_data = sqLite.read_all_log_sort(table=f'log{user_id}')
        for line in chat_data:
            text = text + f"[{str(line[5]).split(' ')[1]}] {line[1]}: {line[2]}: {line[3]}: {line[4]}: \n"
    else:
        text = ''
        chat_data = sqLite.read_all_log_sort(table=f'log{user_id}')
        i = 0
        for line in chat_data:
            text = text + f"[{str(line[5]).split(' ')[1]}] {line[1]}: {line[2]}\n"
            i += 1
            if i > 20:
                break
    if text == '':
        new_text = 'У вас нет записей'
    else:
        text = text.split('\n')[::-1]
        new_text = ''
        for line in text:
            new_text = new_text + line + '\n'
    await message.answer(text=f"{new_text}", parse_mode='html')

