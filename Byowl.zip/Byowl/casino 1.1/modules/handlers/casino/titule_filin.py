import datetime
import random

from aiogram import types
from modules import sqLite


# Определяем нужно ли дать монеты сейчас
async def pick_user_for_titule(chat_id: str,
                               titule: str,
                               message: types.Message):
    all_chat_users = sqLite.read_all(table=f'chat{chat_id[1:]}')
    pick_user = random.choice(all_chat_users)
    sqLite.insert_tituls(chat_id=chat_id, nick=pick_user[17], titule=titule)
    await message.answer(f'{pick_user[17]} - {titule}')


# Назначение титулов филинов
async def titule_filin(message: types.Message):
    chat_id = message.chat.id
    user_id = message.from_user.id
    filin = message.text[1:-4]
    # фильтруем личку
    if chat_id == user_id:
        pass
    else:
        now = datetime.datetime.now()
        chat_data = sqLite.read_values_by_name(table=f'chats', id_name='chat_id', data=str(chat_id))
        str_to_data = lambda x: datetime.datetime.strptime(x.split('.')[0], "%Y-%m-%d %H:%M:%S")

        if chat_data[8] == '0':
            sqLite.insert_info(table=f'chats', name='titule_time', data=now, id_name='chat_id', telegram_id=chat_id)
            await pick_user_for_titule(chat_id=str(chat_id), titule=filin, message=message)

        elif str_to_data(chat_data[8]) + datetime.timedelta(minutes=60) > now:
            lust_time = now - str_to_data(chat_data[8])
            lust_time = str(lust_time).split(':')[1]
            lust_time = 60 - int(lust_time)
            await message.answer(f'Титул дня можно будет выбрать через {lust_time}м')

        elif str_to_data(chat_data[8]) + datetime.timedelta(minutes=60) < now:
            sqLite.insert_info(table=f'chats', name='titule_time', data=now, id_name='chat_id', telegram_id=chat_id)
            await pick_user_for_titule(chat_id=str(chat_id), titule=filin, message=message)
        else:
            print("Ошибка филины")


# Получаем список титулов и выводим в чат
async def get_filins(message: types.Message):
    chat_id = message.chat.id
    user_id = message.from_user.id
    if user_id == chat_id:
        pass
    else:
        all_chat_users = sqLite.read_value_table_name(table=f'filins', id_name="chat_id", telegram_id=str(chat_id))
        filins = '[Титулы дня]\n\n'
        for user in all_chat_users:
            filins = filins + f"{user[2]} - {user[3]}\n"
        await message.answer(text=filins)