import datetime
from modules.dispatcher import Market

from modules import sqLite
from aiogram import types


# Проверка макс сделки и запись данных после розыгрыше
def read_and_save_data(tg_id: int, deal: int, income: int):
    user_data = sqLite.read_values_by_name(table='all_users', data=tg_id)
    money = user_data[2]
    all_income = user_data[3]
    all_outcome = user_data[4]
    max_income = user_data[5]
    max_deal = user_data[6]
    money = money + income
    if max_income < income - deal:
        sqLite.insert_info(table='all_users', name='max_income', data=income - deal, telegram_id=tg_id)
    if max_deal < deal:
        sqLite.insert_info(table='all_users', name='max_deal', data=deal, telegram_id=tg_id)
    if income > 0:
        sqLite.insert_info(table='all_users', name='income', data=all_income + income-deal, telegram_id=tg_id)
    if income == 0:
        sqLite.insert_info(table='all_users', name='outcome', data=all_outcome + deal, telegram_id=tg_id)
    sqLite.insert_info(table='all_users', name='money', data=money, telegram_id=tg_id)


# Проверка макс сделки и запись данных после розыгрыше
def read_and_save_data_chat(tg_id: int, deal: int, income: int, chat_id: int):
    chat_id = str(chat_id)
    user_data = sqLite.read_values_by_name(table='all_users', data=tg_id)
    chat_data = sqLite.read_values_by_name(table=f'chat{chat_id[1:]}', data=tg_id, id_name='tg_id')
    money = user_data[2]
    sum_deals = chat_data[7] + deal
    sum_deals_day = chat_data[14] + deal
    sum_income = chat_data[8] + income
    sum_income_day = chat_data[15] + income
    if income == 0:
        outcome = deal
    else:
        outcome = 0
    sum_outcome = chat_data[9] + outcome
    sum_outcome_day = chat_data[16] + outcome
    if chat_data[10] > income:
        max_inc = chat_data[10]
    else:
        max_inc = income
    sqLite.insert_info_roll(table=f'chat{chat_id[1:]}',
                            tg_id=tg_id,
                            money=money,
                            deal=sum_deals,
                            income=sum_income,
                            outcome=sum_outcome,
                            max_income=max_inc,
                            deal_day=sum_deals_day,
                            income_day=sum_income_day,
                            outcome_day=sum_outcome_day)


# Пишем топы в игре буквы
async def read_and_save_words(message: types.Message):
    word = message.text
    chat_id = str(message.chat.id)
    tg_id = message.from_user.id
    user_data = sqLite.read_values_by_name(table='all_users', data=tg_id)
    chat_data = sqLite.read_values_by_name(table=f'chat{chat_id[1:]}', data=tg_id, id_name='tg_id')
    money = user_data[2]
    words_score = chat_data[11] + len(word)**2
    if len(chat_data[12]) > len(word):
        max_lengs_word = chat_data[12]
    else:
        max_lengs_word = word
    sqLite.insert_info(table=f'chat{chat_id[1:]}', name='words_score', data=words_score, telegram_id=tg_id,
                       id_name='tg_id')
    sqLite.insert_info(table=f'chat{chat_id[1:]}', name='money', data=money, telegram_id=tg_id, id_name='tg_id')
    sqLite.insert_info(table=f'chat{chat_id[1:]}', name='words_lengs', data=max_lengs_word, telegram_id=tg_id,
                       id_name='tg_id')
    sqLite.insert_info(table=f'chat{chat_id[1:]}', name='words_len_word', data=len(max_lengs_word), telegram_id=tg_id,
                       id_name='tg_id')


# Начисляем после оплаты
async def save_after_pay(message: types.Message):
    money = int(message.successful_payment.invoice_payload.split('pay_')[1])/100
    chat_id = str(message.chat.id)
    tg_id = message.from_user.id
    user_data = sqLite.read_values_by_name(table='all_users', data=tg_id)
    now = str(datetime.datetime.now()).split('.')[0]

    if money == 99:
        sqLite.ins_log(tg_id=str(tg_id),
                       info=f'Пополнение баланса', money=f"+100,000", chanel_id=message.chat.id)
        sqLite.insert_info(table=f'all_users', name='money', data=user_data[2] + 100000, telegram_id=tg_id)
        await message.answer('Баланс успешно пополнен на 100,000 монет')

    elif money == 399:
        sqLite.ins_log(tg_id=str(tg_id),
                       info=f'Пополнение баланса', money=f"+500,000", chanel_id=message.chat.id)
        sqLite.insert_info(table=f'all_users', name='money', data=user_data[2] + 500000, telegram_id=tg_id)
        await message.answer('Баланс успешно пополнен на 500,000 монет')

    elif money == 699:
        sqLite.ins_log(tg_id=str(tg_id),
                       info=f'Пополнение баланса', money=f"+1.000.000", chanel_id=message.chat.id)
        sqLite.insert_info(table=f'all_users', name='money', data=user_data[2] + 1000000, telegram_id=tg_id)
        await message.answer('Баланс успешно пополнен на 1,000.000 монет')

    elif money == 3399:
        sqLite.ins_log(tg_id=str(tg_id),
                       info=f'Пополнение баланса', money=f"+5.000.000", chanel_id=message.chat.id)
        sqLite.insert_info(table=f'all_users', name='money', data=user_data[2] + 5000000, telegram_id=tg_id)
        await message.answer('Баланс успешно пополнен на 5,000.000 монет')

    elif money == 5999:
        sqLite.ins_log(tg_id=str(tg_id),
                       info=f'Пополнение баланса', money=f"+10.000.000", chanel_id=message.chat.id)
        sqLite.insert_info(table=f'all_users', name='money', data=user_data[2] + 10000000, telegram_id=tg_id)
        await message.answer('Баланс успешно пополнен на 10,000,000 монет')

    # Статусы
    # Статус Дневной
    elif money == 499:
        sqLite.ins_log(tg_id=str(tg_id),
                       info=f'Получен статус Дневной', money=f"status Day", chanel_id=message.chat.id)
        sqLite.insert_info(table=f'all_users', name='status_day', data=now, telegram_id=tg_id)
        sqLite.insert_info(table=f'all_users', name='money', data=user_data[2] + 50000, telegram_id=tg_id)
        sqLite.ins_log(tg_id=str(tg_id), info=f'Начисление за статус Дневной', money="+50,000", chanel_id=chat_id)
        await message.answer('Статус [🌝] Дневной успешно получен!')

    # Статусы
    elif money == 1999:
        sqLite.ins_log(tg_id=str(tg_id),
                       info=f'Получен статус Ночной', money=f"status Night", chanel_id=message.chat.id)
        sqLite.insert_info(table=f'all_users', name='status_night', data=now, telegram_id=tg_id)
        sqLite.insert_info(table=f'all_users', name='money', data=user_data[2] + 200000, telegram_id=tg_id)
        sqLite.ins_log(tg_id=str(tg_id), info=f'Начисление за статус Ночной', money="+200,000", chanel_id=chat_id)
        await message.answer('Статус [🌚] Ночной успешно получен!')

    # Статусы
    elif money == 4999:
        sqLite.ins_log(tg_id=str(tg_id),
                       info=f'Получен статус Королевский', money=f"status King", chanel_id=message.chat.id)
        sqLite.insert_info(table=f'all_users', name='status_king', data=now, telegram_id=tg_id)
        sqLite.insert_info(table=f'all_users', name='money', data=user_data[2] + 500000, telegram_id=tg_id)
        sqLite.ins_log(tg_id=str(tg_id), info=f'Начисление за статус Королевский', money="+500,000", chanel_id=chat_id)
        await message.answer('Статус [👑] Королевский успешно получен!')

    # Статусы фирменный
    elif money == 9999:
        sqLite.ins_log(tg_id=str(tg_id),
                       info=f'Получен статус Фирменный', money=f"status Firm", chanel_id=message.chat.id)
        sqLite.insert_info(table=f'all_users', name='status_firm', data=now, telegram_id=tg_id)
        sqLite.insert_info(table=f'all_users', name='money', data=user_data[2] + 1000000, telegram_id=tg_id)
        sqLite.ins_log(tg_id=str(tg_id), info=f'Начисление за статус Фирменный', money="+1,000,000", chanel_id=chat_id)
        await message.answer('Статус [🦉] Фирменный успешно получен!')

    # Статус декоративный
    elif money == 679:
        sqLite.ins_log(tg_id=str(tg_id),
                       info=f'Получен статус Декоративный', money=f"status Decor", chanel_id=message.chat.id)
        sqLite.insert_info(table=f'all_users', name='status_dekor', data=now, telegram_id=tg_id)
        await message.answer('Статус [🎩] Декоративный успешно получен!')

    # Статусы
    elif money == 599:
        sqLite.ins_log(tg_id=str(tg_id),
                       info=f'Снятие лимитов группы за Донат', money=f"-599 RUR", chanel_id=message.chat.id)

        await message.answer('Введите id группы\nПример:-12536554522')
        await Market.roll_limits_pay.set()

    # Vip Лицензия
    elif money == 299:
        chat_id = message.chat.id
        user_id = message.from_user.id
        user_data = sqLite.read_values_by_name(table=f'all_users', data=user_id)
        sqLite.ins_log(tg_id=str(user_id), info=f'покупка VIP лицензии', money="-299 RUR", chanel_id=chat_id)
        sqLite.insert_info(table=f'all_users', name='license_vip', data=user_data[14] + 1, telegram_id=user_id)
        await message.answer('VIP лицензия куплена!')


# ---------------------------------------
# Оплата через QIWI
# Начисляем после оплаты
async def save_after_pay_qiwi(call: types.CallbackQuery):
    money = int(call.data[6:])
    chat_id = str(call.message.chat.id)
    tg_id = call.from_user.id
    user_data = sqLite.read_values_by_name(table='all_users', data=tg_id)
    now = str(datetime.datetime.now()).split('.')[0]

    if money == 99:
        sqLite.ins_log(tg_id=str(tg_id),
                       info=f'Пополнение баланса', money=f"+100,000", chanel_id=call.message.chat.id)
        sqLite.insert_info(table=f'all_users', name='money', data=user_data[2] + 100000, telegram_id=tg_id)
        await call.message.answer('Баланс успешно пополнен на 100,000 монет')

    elif money == 399:
        sqLite.ins_log(tg_id=str(tg_id),
                       info=f'Пополнение баланса', money=f"+500,000", chanel_id=call.message.chat.id)
        sqLite.insert_info(table=f'all_users', name='money', data=user_data[2] + 500000, telegram_id=tg_id)
        await call.message.answer('Баланс успешно пополнен на 500,000 монет')

    elif money == 699:
        sqLite.ins_log(tg_id=str(tg_id),
                       info=f'Пополнение баланса', money=f"+1.000.000", chanel_id=call.message.chat.id)
        sqLite.insert_info(table=f'all_users', name='money', data=user_data[2] + 1000000, telegram_id=tg_id)
        await call.message.answer('Баланс успешно пополнен на 1,000.000 монет')

    elif money == 3399:
        sqLite.ins_log(tg_id=str(tg_id),
                       info=f'Пополнение баланса', money=f"+5.000.000", chanel_id=call.message.chat.id)
        sqLite.insert_info(table=f'all_users', name='money', data=user_data[2] + 5000000, telegram_id=tg_id)
        await call.message.answer('Баланс успешно пополнен на 5,000.000 монет')

    elif money == 5999:
        sqLite.ins_log(tg_id=str(tg_id),
                       info=f'Пополнение баланса', money=f"+10.000.000", chanel_id=call.message.chat.id)
        sqLite.insert_info(table=f'all_users', name='money', data=user_data[2] + 10000000, telegram_id=tg_id)
        await call.message.answer('Баланс успешно пополнен на 10,000,000 монет')

    # Статусы
    # Статус Дневной
    elif money == 499:
        sqLite.ins_log(tg_id=str(tg_id),
                       info=f'Получен статус Дневной', money=f"status Day", chanel_id=call.message.chat.id)
        sqLite.insert_info(table=f'all_users', name='status_day', data=now, telegram_id=tg_id)
        sqLite.insert_info(table=f'all_users', name='money', data=user_data[2] + 50000, telegram_id=tg_id)
        sqLite.ins_log(tg_id=str(tg_id), info=f'Начисление за статус Дневной', money="+50,000", chanel_id=chat_id)
        await call.message.answer('Статус [🌝] Дневной успешно получен!')

    # Статусы
    elif money == 1999:
        sqLite.ins_log(tg_id=str(tg_id),
                       info=f'Получен статус Ночной', money=f"status Night", chanel_id=call.message.chat.id)
        sqLite.insert_info(table=f'all_users', name='status_night', data=now, telegram_id=tg_id)
        sqLite.insert_info(table=f'all_users', name='money', data=user_data[2] + 200000, telegram_id=tg_id)
        sqLite.ins_log(tg_id=str(tg_id), info=f'Начисление за статус Ночной', money="+200,000", chanel_id=chat_id)
        await call.message.answer('Статус [🌚] Ночной успешно получен!')

    # Статусы
    elif money == 4999:
        sqLite.ins_log(tg_id=str(tg_id),
                       info=f'Получен статус Королевский', money=f"status King", chanel_id=call.message.chat.id)
        sqLite.insert_info(table=f'all_users', name='status_king', data=now, telegram_id=tg_id)
        sqLite.insert_info(table=f'all_users', name='money', data=user_data[2] + 500000, telegram_id=tg_id)
        sqLite.ins_log(tg_id=str(tg_id), info=f'Начисление за статус Королевский', money="+500,000", chanel_id=chat_id)
        await call.message.answer('Статус [👑] Королевский успешно получен!')

    # Статусы фирменный
    elif money == 9999:
        sqLite.ins_log(tg_id=str(tg_id),
                       info=f'Получен статус Фирменный', money=f"status Firm", chanel_id=call.message.chat.id)
        sqLite.insert_info(table=f'all_users', name='status_firm', data=now, telegram_id=tg_id)
        sqLite.insert_info(table=f'all_users', name='money', data=user_data[2] + 1000000, telegram_id=tg_id)
        sqLite.ins_log(tg_id=str(tg_id), info=f'Начисление за статус Фирменный', money="+1,000,000", chanel_id=chat_id)
        await call.message.answer('Статус [🦉] Фирменный успешно получен!')

    # Статус декоративный
    elif money == 679:
        sqLite.ins_log(tg_id=str(tg_id),
                       info=f'Получен статус Декоративный', money=f"status Decor", chanel_id=call.message.chat.id)
        sqLite.insert_info(table=f'all_users', name='status_dekor', data=now, telegram_id=tg_id)
        await call.message.answer('Статус [🎩] Декоративный успешно получен!')

    # Статусы
    elif money == 599:
        sqLite.ins_log(tg_id=str(tg_id),
                       info=f'Снятие лимитов группы за Донат', money=f"-599 RUR", chanel_id=call.message.chat.id)

        await call.message.answer('Введите id группы\nПример:-12536554522')
        await Market.roll_limits_pay.set()

    # Vip Лицензия
    elif money == 299:
        chat_id = call.message.chat.id
        user_id = call.from_user.id
        user_data = sqLite.read_values_by_name(table=f'all_users', data=user_id)
        sqLite.ins_log(tg_id=str(user_id), info=f'покупка VIP лицензии', money="-299 RUR", chanel_id=chat_id)
        sqLite.insert_info(table=f'all_users', name='license_vip', data=user_data[14] + 1, telegram_id=user_id)
        await call.message.answer('VIP лицензия куплена!')
