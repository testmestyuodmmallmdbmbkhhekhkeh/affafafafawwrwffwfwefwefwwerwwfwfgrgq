import random
import datetime
from datetime import timedelta
from aiogram import types
from modules import sqLite


# Грабеж основная функция
async def stolen(message: types.Message):
    user_id = message.from_user.id
    victem_id = message.reply_to_message.from_user.id
    user_data = sqLite.read_values_by_name(table=f'all_users', data=user_id)
    # парсим время последнего грабежа
    if '.' in str(user_data[9]):
        lust_deal = str(user_data[9]).split('.')[0]
    else:
        lust_deal = str('2021-09-20 00:34:51')
    lust_deal = datetime.datetime.strptime(str(lust_deal), "%Y-%m-%d %H:%M:%S")
    lust_deal = lust_deal + timedelta(hours=1)
    # проверям можно ли грабить по времени
    if lust_deal > datetime.datetime.now():
        await message.reply('Ты уже грабил недавно')
    else:
        victem_data = sqLite.read_values_by_name(table=f'all_users', data=victem_id)
        if user_data[2]*10 < int(message.text):
            await message.reply('Жадность фраера сгубила')
        else:
            if victem_data[2] < int(message.text):
                await message.reply(f'У {message.reply_to_message.from_user.first_name} недостаточно средств')
            else:
                number = random.randrange(1, 5)
                if number == 2:
                    money = random.randrange(0, int(message.text[1:]))
                    sqLite.insert_info(table=f'all_users', name='money', data=victem_data[2] - money,
                                       telegram_id=victem_id)
                    sqLite.insert_info(table=f'all_users', name='money', data=user_data[2] + money,
                                       telegram_id=user_id)
                    await message.reply(
                        f"Тебе удалось украсть у {message.reply_to_message.from_user.first_name} {money} монет")
                    sqLite.ins_log(tg_id=str(user_id),
                                   info=f'украл у {message.reply_to_message.from_user.first_name}',
                                   money=f"+{money}", chanel_id=message.chat.id)
                    sqLite.ins_log(tg_id=str(user_id),
                                   info=f'у вас украл {message.from_user.first_name}',
                                   money=f"-{money}", chanel_id=message.chat.id)
                else:
                    await message.reply(f"К сожалению, тебе не удалось ограбить "
                                        f"{message.reply_to_message.from_user.first_name}")
    sqLite.insert_info(table=f'all_users', name='stolen', data=datetime.datetime.now(), telegram_id=user_id)
