import asyncio
import random
from datetime import datetime
from aiogram import types
from modules.handlers.casino.read_and_save_data import read_and_save_data, read_and_save_data_chat
from modules import sqLite
from modules.dispatcher import bot
from modules.keyboards import ruletka_kb


# Запуск рулетки
async def ruletka(message: types.Message):
    tg_id = message.chat.id
    if '-' in str(tg_id):
        name_id = str(tg_id)[1:]
    else:
        name_id = str(tg_id)
    try:
        data = sqLite.read_all(table=f'ruletka{name_id}')
        await bot.send_message(text='Рулетка уже запущена, наберите крутить', chat_id=tg_id)
    except:
        sqLite.new_table_ruletka(name_id)

        await bot.send_message(text='Минирулетка\n'
                                    'Угадайте число из:\n'
                                    '0💚\n'
                                    '1🔴 2⚫️ 3🔴 4⚫️ 5🔴 6⚫️\n'
                                    '7🔴 8⚫️ 9🔴10⚫️11🔴12⚫️\n'
                                    'Ставки можно текстом:\n'
                                    '10 на красное |  5 на 12', chat_id=tg_id,
                               reply_markup=ruletka_kb)


# Если колбэк от и до
async def func_start_to_finish(call: types.CallbackQuery, start: int, finish: int, *, deal: int = 0):
    user_id = call.from_user.id
    chat_id = call.message.chat.id
    if '-' in str(chat_id):
        table_name = str(chat_id)[1:]
    else:
        table_name = str(chat_id)
    user_data = sqLite.read_values_by_name(table=f'all_users', data=user_id)
    if deal == 0:
        lust_deal = int(user_data[8])
    else:
        lust_deal = deal
    if int(user_data[2]) < lust_deal:
        await bot.send_message(text=f'{call.from_user.first_name}, ставка не может превышать ваши средства',
                               chat_id=chat_id)
    else:
        sqLite.insert_info(table=f'all_users', name='money', data=int(user_data[2]) - lust_deal, telegram_id=user_id)
        now = str(datetime.now()).split('.')[0]
        sqLite.insert_all_info_casino(table=f'ruletka{table_name}', money=lust_deal, deal=f'{start}-{finish}',
                                      telegram_id=user_id, datatime=now, nick=call.from_user.first_name)
        await bot.send_message(text=f'Ставка принята: {call.from_user.first_name} {lust_deal} монет на {start}-'
                                    f'{finish}', chat_id=chat_id)


# На красное
async def func_red(call: types.CallbackQuery, *, deal: int = 0):
    user_id = call.from_user.id
    chat_id = call.message.chat.id
    if '-' in str(chat_id):
        table_name = str(chat_id)[1:]
    else:
        table_name = str(chat_id)
    user_data = sqLite.read_values_by_name(table=f'all_users', data=user_id)
    if deal == 0:
        lust_deal = int(user_data[8])
    else:
        lust_deal = deal
    if int(user_data[2]) < lust_deal:
        await bot.send_message(text=f'{call.from_user.first_name}, ставка не может превышать ваши средства',
                               chat_id=chat_id)
    else:
        sqLite.insert_info(table=f'all_users', name='money', data=int(user_data[2]) - lust_deal, telegram_id=user_id)
        now = str(datetime.now()).split('.')[0]
        sqLite.insert_all_info_casino(table=f'ruletka{table_name}', money=lust_deal, deal=f'красное',
                                      telegram_id=user_id, datatime=now, nick=call.from_user.first_name)
        await bot.send_message(text=f'Ставка принята: {call.from_user.first_name} {lust_deal} монет на красное 🔴',
                               chat_id=chat_id)


# На черное
async def func_black(call: types.CallbackQuery, *, deal: int = 0):
    user_id = call.from_user.id
    chat_id = call.message.chat.id
    if '-' in str(chat_id):
        table_name = str(chat_id)[1:]
    else:
        table_name = str(chat_id)
    user_data = sqLite.read_values_by_name(table=f'all_users', data=user_id)
    if deal == 0:
        lust_deal = int(user_data[8])
    else:
        lust_deal = deal
    if int(user_data[2]) < lust_deal:
        await bot.send_message(text=f'{call.from_user.first_name}, ставка не может превышать ваши средства',
                               chat_id=chat_id)
    else:
        sqLite.insert_info(table=f'all_users', name='money', data=int(user_data[2]) - lust_deal, telegram_id=user_id)
        now = str(datetime.now()).split('.')[0]
        sqLite.insert_all_info_casino(table=f'ruletka{table_name}', money=lust_deal, deal=f'черное',
                                      telegram_id=user_id, datatime=now, nick=call.from_user.first_name)
        await bot.send_message(text=f'Ставка принята: {call.from_user.first_name} {lust_deal} монет на черное ⚫️',
                               chat_id=chat_id)


# На зеро
async def func_zero(call: types.CallbackQuery, *, deal: int = 0):
    user_id = call.from_user.id
    chat_id = call.message.chat.id
    if '-' in str(chat_id):
        table_name = str(chat_id)[1:]
    else:
        table_name = str(chat_id)
    user_data = sqLite.read_values_by_name(table=f'all_users', data=user_id)
    if deal == 0:
        lust_deal = int(user_data[8])
    else:
        lust_deal = deal
    if int(user_data[2]) < lust_deal:
        await bot.send_message(text=f'{call.from_user.first_name}, ставка не может превышать ваши средства',
                               chat_id=chat_id)
    else:
        sqLite.insert_info(table=f'all_users', name='money', data=int(user_data[2]) - lust_deal, telegram_id=user_id)
        now = str(datetime.now()).split('.')[0]
        sqLite.insert_all_info_casino(table=f'ruletka{table_name}', money=lust_deal, deal=f'zero',
                                      telegram_id=user_id, datatime=now, nick=call.from_user.first_name)
        await bot.send_message(text=f'Ставка принята: {call.from_user.first_name} {lust_deal} монет на 0💚',
                               chat_id=chat_id)


# Повторить
async def func_repitt(call: types.CallbackQuery):
    user_id = call.from_user.id
    chat_id = call.message.chat.id
    if '-' in str(chat_id):
        table_name = str(chat_id)[1:]
    else:
        table_name = str(chat_id)
    user_data = sqLite.read_values_by_name(table=f'all_users', data=user_id)
    deals_ruletka = sqLite.read_value_table_name(table=f'ruletka{table_name}', telegram_id=user_id, graph='*')
    lengs = len(deals_ruletka)
    lust_deal_data = (deals_ruletka[lengs - 1])
    lust_deal = lust_deal_data[2]
    if int(user_data[2]) < lust_deal:
        await bot.send_message(text=f'{call.from_user.first_name}, ставка не может превышать ваши средства',
                               chat_id=chat_id)
    else:
        sqLite.insert_info(table=f'all_users', name='money', data=int(user_data[2]) - lust_deal, telegram_id=user_id)
        now = str(datetime.now()).split('.')[0]
        sqLite.insert_all_info_casino(table=f'ruletka{table_name}', money=lust_deal, deal=lust_deal_data[3],
                                      telegram_id=user_id, datatime=now, nick=call.from_user.first_name)
        if str(lust_deal_data[3]) == 'zero':
            await bot.send_message(text=f'Ставка принята: {call.from_user.first_name} {lust_deal} монет на 0💚',
                                   chat_id=chat_id)
        elif str(lust_deal_data[3]) == 'red':
            await bot.send_message(text=f'Ставка принята: {call.from_user.first_name} {lust_deal} монет на красное 🔴',
                                   chat_id=chat_id)
        elif str(lust_deal_data[3]) == 'black':
            await bot.send_message(text=f'Ставка принята: {call.from_user.first_name} {lust_deal} монет на черное ⚫️',
                                   chat_id=chat_id)
        elif '-' in str(lust_deal_data[3]):
            start = str(lust_deal_data[3]).split('-')[0]
            finish = str(lust_deal_data[3]).split('-')[1]
            await bot.send_message(text=f'Ставка принята: {call.from_user.first_name} {lust_deal} монет на {start}-'
                                        f'{finish}',
                                   chat_id=chat_id)


# Удвоить
async def func_double(call: types.CallbackQuery):
    user_id = call.from_user.id
    chat_id = call.message.chat.id
    if '-' in str(chat_id):
        table_name = str(chat_id)[1:]
    else:
        table_name = str(chat_id)
    user_data = sqLite.read_values_by_name(table=f'all_users', data=user_id)
    deals_ruletka = sqLite.read_value_table_name(table=f'ruletka{table_name}', telegram_id=user_id, graph='*')
    for deal in deals_ruletka:
        lust_deal_data = deal
        lust_deal = lust_deal_data[2] * 2
        if int(user_data[2]) < lust_deal:
            await bot.send_message(text=f'{call.from_user.first_name}, ставка не может превышать ваши средства',
                                   chat_id=chat_id)
            break
        else:
            sqLite.insert_info(table=f'all_users', name='money', data=int(user_data[2]) - lust_deal,
                               telegram_id=user_id)
            sqLite.insert_info(table=f'all_users', name='lust_deal', data=lust_deal, telegram_id=user_id)
            now = str(datetime.now()).split('.')[0]
            sqLite.insert_all_info_casino(table=f'ruletka{table_name}', money=lust_deal, deal=lust_deal_data[3],
                                          telegram_id=user_id, datatime=now, nick=call.from_user.first_name)
            if str(lust_deal_data[3]) == 'zero':
                await bot.send_message(text=f'Ставка принята: {call.from_user.first_name} {lust_deal} монет на 0💚',
                                       chat_id=chat_id)
            elif str(lust_deal_data[3]) == 'red':
                await bot.send_message(
                    text=f'Ставка принята: {call.from_user.first_name} {lust_deal} монет на красное 🔴',
                    chat_id=chat_id)
            elif str(lust_deal_data[3]) == 'black':
                await bot.send_message(
                    text=f'Ставка принята: {call.from_user.first_name} {lust_deal} монет на черное ⚫️',
                    chat_id=chat_id)
            elif '-' in str(lust_deal_data[3]):
                start = str(lust_deal_data[3]).split('-')[0]
                finish = str(lust_deal_data[3]).split('-')[1]
                await bot.send_message(text=f'Ставка принята: {call.from_user.first_name} {lust_deal} монет на {start}-'
                                            f'{finish}',
                                       chat_id=chat_id)


# Старт рулетка
async def func_start(call: types.CallbackQuery):
    user_id = call.from_user.id
    chat_id = call.message.chat.id
    off_roll = sqLite.read_values_by_name(table=f'chats', id_name='chat_id', data=f"{chat_id}")
    # Проверка на отключение рулетки в этом чате
    if off_roll is None:
        await call.message.answer('Рулетка в этом чате отключена')
    elif off_roll[4] == 1:
        await call.message.answer('Рулетка в этом чате отключена')
    else:
        # Проверка на отключение лимита на рулетку
        if off_roll[2] == 1:
            # проверяем крутил ли раньше этот пользователь
            chat_user_data = sqLite.read_values_by_name(table=f'chat{str(chat_id)[1:]}', id_name='tg_id', data=user_id)
            if chat_user_data is None:
                await roll_start(call)
                sqLite.insert_first_note(table=f'chat{str(chat_id)[1:]}', id_name='tg_id', telegram_id=user_id)
                sqLite.insert_info(table=f'chat{str(chat_id)[1:]}', name='roll_number', data=1, id_name='tg_id',
                                   telegram_id=user_id)
            elif chat_user_data[2] == 0:
                await roll_start(call)
                sqLite.insert_info(table=f'chat{str(chat_id)[1:]}', name='roll_number', data=1, id_name='tg_id',
                                   telegram_id=user_id)
            elif chat_user_data[2] == 1:
                await call.message.answer('Чтобы снять ограничение в чате,вам нужно перейти в магазин лс бота и внести '
                        'свой вклад,сделав пожертвование создателю бота на его развитие.')
            else:
                pass
        else:
            await roll_start(call)


# Старт рулетка
async def roll_start(call: types.CallbackQuery):
    chat_id = call.message.chat.id
    if '-' in str(chat_id):
        name_id = str(chat_id)[1:]
    else:
        name_id = str(chat_id)
    rand_time = random.randrange(5, 15)
    await bot.send_message(text=f'{call.from_user.first_name} крутит {rand_time} сек',
                           chat_id=chat_id)
    await asyncio.sleep(rand_time)
    if '-' in str(chat_id):
        table_name = str(chat_id)[1:]
    else:
        table_name = str(chat_id)
    result = random.randrange(0, 12)
    if result == 0:
        sumbol = '💚'
    elif result == 1 or result == 3 or result == 5 or result == 7 or result == 9 or result == 11:
        sumbol = '🔴'
    else:
        sumbol = '⚫️'
    ruletka_data = sqLite.read_all(table=f'ruletka{table_name}')
    text = ''
    for line in ruletka_data:

        if str(line[3]).isdigit():
            # Собираем текст тех кто выиграл
            if line[3] == result:
                text = text + f'{line[5]} {line[2]} на {line[3]}\n' \
                              f'{line[5]} выиграл {line[2] * 12} на {line[3]} {sumbol}\n'
                read_and_save_data(tg_id=line[1], deal=line[2], income=line[2] * 12)
                read_and_save_data_chat(tg_id=line[1], deal=line[2], income=line[2] * 12, chat_id=chat_id)
                sqLite.ins_log(tg_id=str(line[1]), info=f'выигрыш в рулетку', money=f"+{line[2] * 12}",
                               chanel_id=chat_id)
            else:
                read_and_save_data(tg_id=line[1], deal=line[2], income=0)
                read_and_save_data_chat(tg_id=line[1], deal=line[2], income=0, chat_id=chat_id)
                sqLite.ins_log(tg_id=str(line[1]), info=f'проигрыш в рулетку', money=f"-{line[2]}",
                               chanel_id=chat_id)

        elif '-' in str(line[3]):
            # Собираем текст тех кто выиграл
            start = int(str(line[3]).split('-')[0])
            finish = int(str(line[3]).split('-')[1])
            if start <= result <= finish:

                range_rul = finish - start + 1
                if range_rul == 2:
                    koeficient = 6
                elif range_rul == 3:
                    koeficient = 4
                elif range_rul == 4:
                    koeficient = 3
                elif range_rul == 5:
                    koeficient = 2.4
                elif range_rul == 6:
                    koeficient = 2
                elif range_rul == 7:
                    koeficient = 1.7
                elif range_rul == 8:
                    koeficient = 1.5
                elif range_rul == 9:
                    koeficient = 1.33
                elif range_rul == 10:
                    koeficient = 1.2
                elif range_rul == 11:
                    koeficient = 1.09
                elif range_rul == 12:
                    koeficient = 1
                else:
                    koeficient = 0.92
                text = text + f'{line[5]} {line[2]} на {line[3]}\n' \
                              f'{line[5]} выиграл {line[2] * koeficient} на {line[3]} {sumbol}\n'
                read_and_save_data(tg_id=line[1], deal=line[2], income=line[2] * koeficient)
                read_and_save_data_chat(tg_id=line[1], deal=line[2], income=line[2] * koeficient, chat_id=chat_id)
                sqLite.ins_log(tg_id=str(line[1]), info=f'выигрыш в рулетку', money=f"+{line[2] * koeficient}",
                               chanel_id=chat_id)

            else:
                read_and_save_data(tg_id=line[1], deal=line[2], income=0)
                read_and_save_data_chat(tg_id=line[1], deal=line[2], income=0, chat_id=chat_id)
                sqLite.ins_log(tg_id=str(line[1]), info=f'проигрыш в рулетку', money=f"-{line[2]}",
                               chanel_id=chat_id)

        elif 'красное' in str(line[3]):
            if result == 1 or result == 3 or result == 5 or result == 7 or result == 9 or result == 11:
                text = text + f'{line[5]} {line[2]} на {line[3]}\n' \
                              f'{line[5]} выиграл {line[2] * 2} на {line[3]} {sumbol}\n'
                read_and_save_data(tg_id=line[1], deal=line[2], income=line[2] * 2)
                read_and_save_data_chat(tg_id=line[1], deal=line[2], income=line[2] * 2, chat_id=chat_id)
                sqLite.ins_log(tg_id=str(line[1]), info=f'выигрыш в рулетку', money=f"+{line[2] * 2}",
                               chanel_id=chat_id)
            else:
                read_and_save_data(tg_id=line[1], deal=line[2], income=0)
                read_and_save_data_chat(tg_id=line[1], deal=line[2], income=0, chat_id=chat_id)
                sqLite.ins_log(tg_id=str(line[1]), info=f'проигрыш в рулетку', money=f"-{line[2]}",
                               chanel_id=chat_id)

        elif 'черное' in str(line[3]):
            if result == 2 or result == 4 or result == 6 or result == 8 or result == 10 or result == 12:
                text = text + f'{line[5]} {line[2]} на {line[3]}\n' \
                              f'{line[5]} выиграл {line[2] * 2} на {line[3]} {sumbol}\n'
                read_and_save_data(tg_id=line[1], deal=line[2], income=line[2] * 2)
                read_and_save_data_chat(tg_id=line[1], deal=line[2], income=line[2] * 2, chat_id=chat_id)
                sqLite.ins_log(tg_id=str(line[1]), info=f'выигрыш в рулетку', money=f"+{line[2]}",
                               chanel_id=chat_id)
            else:
                read_and_save_data(tg_id=line[1], deal=line[2], income=0)
                read_and_save_data_chat(tg_id=line[1], deal=line[2], income=0, chat_id=chat_id)
                sqLite.ins_log(tg_id=str(line[1]), info=f'проигрыш в рулетку', money=f"-{line[2]}",
                               chanel_id=chat_id)
    if text == '':
        await bot.send_message(text=f'Рулетка: {result}{sumbol}\n'
                                    f'Никто не выиграл', chat_id=chat_id)
    else:
        await bot.send_message(text=f'Рулетка: {result}{sumbol}\n'
                                    f'{text}', chat_id=chat_id)
    sqLite.delete_table(table=f'ruletka{name_id}')
    await asyncio.sleep(1)
    sqLite.new_table_ruletka(name_id)


# Если сообщение от и до
async def func_start_to_finish_mes(message: types.Message, start: int, finish: int, *, deal: int = 0):
    user_id = message.from_user.id
    chat_id = message.chat.id
    if '-' in str(chat_id):
        table_name = str(chat_id)[1:]
    else:
        table_name = str(chat_id)
    user_data = sqLite.read_values_by_name(table=f'all_users', data=user_id)
    if deal == 0:
        lust_deal = int(user_data[8])
    else:
        lust_deal = deal
    if int(user_data[2]) < lust_deal:
        await bot.send_message(text=f'{message.from_user.first_name}, ставка не может превышать ваши средства',
                               chat_id=chat_id)
    else:
        sqLite.insert_info(table=f'all_users', name='money', data=int(user_data[2]) - lust_deal, telegram_id=user_id)
        now = str(datetime.now()).split('.')[0]
        sqLite.insert_all_info_casino(table=f'ruletka{table_name}', money=lust_deal, deal=f'{start}-{finish}',
                                      telegram_id=user_id, datatime=now, nick=message.from_user.first_name)
        await bot.send_message(text=f'Ставка принята: <a href="tg://user?id={message.from_user.id}">'
                                    f'{message.from_user.first_name}</a> {lust_deal} монет на {start}-'
                                    f'{finish}', chat_id=chat_id, parse_mode='html')


# На красное
async def func_red_mes(message: types.Message, *, deal: int = 0):
    user_id = message.from_user.id
    chat_id = message.chat.id
    if '-' in str(chat_id):
        table_name = str(chat_id)[1:]
    else:
        table_name = str(chat_id)
    user_data = sqLite.read_values_by_name(table=f'all_users', data=user_id)
    if deal == 0:
        lust_deal = int(user_data[8])
    else:
        lust_deal = deal
    if int(user_data[2]) < lust_deal:
        await bot.send_message(text=f'{message.from_user.first_name}, ставка не может превышать ваши средства',
                               chat_id=chat_id)
    else:
        sqLite.insert_info(table=f'all_users', name='money', data=int(user_data[2]) - lust_deal, telegram_id=user_id)
        now = str(datetime.now()).split('.')[0]
        sqLite.insert_all_info_casino(table=f'ruletka{table_name}', money=lust_deal, deal=f'красное',
                                      telegram_id=user_id, datatime=now, nick=message.from_user.first_name)
        await bot.send_message(text=f'Ставка принята: <a href="tg://user?id={message.from_user.id}">'
                                    f'{message.from_user.first_name}</a> {lust_deal} монет на красное 🔴',
                               chat_id=chat_id, parse_mode='html')


# На черное
async def func_black_mes(message: types.Message, *, deal: int = 0):
    user_id = message.from_user.id
    chat_id = message.chat.id
    if '-' in str(chat_id):
        table_name = str(chat_id)[1:]
    else:
        table_name = str(chat_id)
    user_data = sqLite.read_values_by_name(table=f'all_users', data=user_id)
    if deal == 0:
        lust_deal = int(user_data[8])
    else:
        lust_deal = deal
    if int(user_data[2]) < lust_deal:
        await bot.send_message(text=f'{message.from_user.first_name}, ставка не может превышать ваши средства',
                               chat_id=chat_id)
    else:
        sqLite.insert_info(table=f'all_users', name='money', data=int(user_data[2]) - lust_deal, telegram_id=user_id)
        now = str(datetime.now()).split('.')[0]
        sqLite.insert_all_info_casino(table=f'ruletka{table_name}', money=lust_deal, deal=f'черное',
                                      telegram_id=user_id, datatime=now, nick=message.from_user.first_name)
        await bot.send_message(text=f'Ставка принята: <a href="tg://user?id={message.from_user.id}">'
                                    f'{message.from_user.first_name}</a> {lust_deal} монет на черное ⚫️',
                               chat_id=chat_id, parse_mode='html')


# На зеро
async def func_zero_mes(message: types.Message, *, deal: int = 0):
    user_id = message.from_user.id
    chat_id = message.chat.id
    if '-' in str(chat_id):
        table_name = str(chat_id)[1:]
    else:
        table_name = str(chat_id)
    user_data = sqLite.read_values_by_name(table=f'all_users', data=user_id)
    if deal == 0:
        lust_deal = int(user_data[8])
    else:
        lust_deal = deal
    if int(user_data[2]) < lust_deal:
        await bot.send_message(text=f'{message.from_user.first_name}, ставка не может превышать ваши средства',
                               chat_id=chat_id)
    else:
        sqLite.insert_info(table=f'all_users', name='money', data=int(user_data[2]) - lust_deal, telegram_id=user_id)
        now = str(datetime.now()).split('.')[0]
        sqLite.insert_all_info_casino(table=f'ruletka{table_name}', money=lust_deal, deal=f'zero',
                                      telegram_id=user_id, datatime=now, nick=message.from_user.first_name)
        await bot.send_message(text=f'Ставка принята: <a href="tg://user?id={message.from_user.id}">'
                                    f'{message.from_user.first_name}</a> {lust_deal} монет на 0💚',
                               chat_id=chat_id, parse_mode='html')


# На число
async def func_number_mes(message: types.Message, *, deal: int = 0):
    user_id = message.from_user.id
    chat_id = message.chat.id
    if message.text.split(' ')[1].isdigit():
        number = message.text.split(' ')[1]
    elif message.text.split(' на ')[1].isdigit():
        number = message.text.split(' на ')[1]
    elif 0 < int(message.text.split(' на ')[1]) < 13:
        number = message.text.split(' ')[1]
    if '-' in str(chat_id):
        table_name = str(chat_id)[1:]
    else:
        table_name = str(chat_id)
    user_data = sqLite.read_values_by_name(table=f'all_users', data=user_id)
    if deal == 0:
        lust_deal = int(user_data[8])
    else:
        lust_deal = deal
    if int(user_data[2]) < lust_deal:
        await bot.send_message(text=f'{message.from_user.first_name}, ставка не может превышать ваши средства',
                               chat_id=chat_id)
    else:
        sqLite.insert_info(table=f'all_users', name='money', data=int(user_data[2]) - lust_deal, telegram_id=user_id)
        now = str(datetime.now()).split('.')[0]
        sqLite.insert_all_info_casino(table=f'ruletka{table_name}', money=lust_deal, deal=number,
                                      telegram_id=user_id, datatime=now, nick=message.from_user.first_name)
        await bot.send_message(text=f'Ставка принята: <a href="tg://user?id={message.from_user.id}">'
                                    f'{message.from_user.first_name}</a> {lust_deal} монет на {number}',
                               chat_id=chat_id, parse_mode='html')


# Старт рулетка
async def func_start_mes(message: types.Message):
    chat_id = message.chat.id
    user_id = message.from_user.id
    off_roll = sqLite.read_values_by_name(table=f'chats', id_name='chat_id', data=f"{chat_id}")
    # Проверка на отключение рулетки в этом чате
    if off_roll is None:
        await message.answer('Рулетка в этом чате отключена')
    elif off_roll[4] == 1:
        await message.answer('Рулетка в этом чате отключена')
    else:
        # Проверка на отключение лимита на рулетку
        if off_roll[2] == 1:
            # Проверяем есть ли ставки от этого пользователя
            if '-' in str(chat_id):
                table_name = str(chat_id)[1:]
            else:
                table_name = str(chat_id)
            deals_roll = sqLite.read_all(table=f'ruletka{table_name}', name='telegram_id')
            # проверям крутил ли раньше этот пользователь
            chat_user_data = sqLite.read_values_by_name(table=f'chat{str(chat_id)[1:]}', id_name='tg_id', data=user_id)
            if str(user_id) in str(deals_roll):
                if chat_user_data is None:
                    await roll_start_mes(message)
                    sqLite.insert_first_note(table=f'chat{str(chat_id)[1:]}', id_name='tg_id', telegram_id=user_id)
                    sqLite.insert_info(table=f'chat{str(chat_id)[1:]}', name='roll_number', data=1, id_name='tg_id',
                                       telegram_id=user_id)
                elif chat_user_data[2] == 0:
                    await roll_start_mes(message)
                    sqLite.insert_info(table=f'chat{str(chat_id)[1:]}', name='roll_number', data=1, id_name='tg_id',
                                       telegram_id=user_id)
                elif chat_user_data[2] == 1:
                    await message.answer(
                        'Чтобы снять ограничение в чате,вам нужно перейти в магазин лс бота и внести '
                        'свой вклад,сделав пожертвование создателю бота на его развитие.')
                else:
                    pass
            else:
                await message.answer('Ты не поставил ставку.')
        else:
            # Проверяем есть ли ставки от этого пользователя
            if '-' in str(chat_id):
                table_name = str(chat_id)[1:]
            else:
                table_name = str(chat_id)
            deals_roll = sqLite.read_all(table=f'ruletka{table_name}')
            if str(user_id) in str(deals_roll):
                await roll_start_mes(message)


# Старт рулетка без ставок
async def func_start_mes_go(message: types.Message):
    chat_id = message.chat.id
    user_id = message.from_user.id
    off_roll = sqLite.read_values_by_name(table=f'chats', id_name='chat_id', data=f"{chat_id}")
    # Проверка на отключение рулетки в этом чате
    if off_roll is None:
        await message.answer('Рулетка в этом чате отключена')
    elif off_roll[4] == 1:
        await message.answer('Рулетка в этом чате отключена')
    else:
        # Проверка на отключение лимита на рулетку
        if off_roll[2] == 1:
            # проверям крутил ли раньше этот пользователь
            chat_user_data = sqLite.read_values_by_name(table=f'chat{str(chat_id)[1:]}', id_name='tg_id', data=user_id)
            if chat_user_data is None:
                await roll_start_mes(message)
                sqLite.insert_first_note(table=f'chat{str(chat_id)[1:]}', id_name='tg_id', telegram_id=user_id)
                sqLite.insert_info(table=f'chat{str(chat_id)[1:]}', name='roll_number', data=1, id_name='tg_id',
                                   telegram_id=user_id)
            elif chat_user_data[2] == 0:
                await roll_start_mes(message)
                sqLite.insert_info(table=f'chat{str(chat_id)[1:]}', name='roll_number', data=1, id_name='tg_id',
                                   telegram_id=user_id)
            elif chat_user_data[2] == 1:
                await message.answer(
                    'Чтобы снять ограничение в чате,вам нужно перейти в магазин лс бота и внести '
                    'свой вклад,сделав пожертвование создателю бота на его развитие.')
            else:
                pass
        else:
            await roll_start_mes(message)


async def roll_start_mes(message: types.Message):
    chat_id = message.chat.id
    if '-' in str(chat_id):
        name_id = str(chat_id)[1:]
    else:
        name_id = str(chat_id)
    rand_time = random.randrange(5, 10)
    await bot.send_message(text=f'<a href="tg://user?id={message.from_user.id}">{message.from_user.first_name}</a> '
                                f'крутит ({rand_time}) сек',
                           chat_id=chat_id, parse_mode='html')
    anime_ids = ['CgACAgIAAxkBAAMvYbPDrh_4PpYkh4eJi_Bzji24ooIAAoQSAAJJD5lJ-0LnE8wMzVMjBA',
                 'CgACAgIAAxkBAAMxYbPGe4D9s-SadXC5yYd8Z3QpwyMAAocSAAJJD5lJfxXSEoWDffojBA',
                 'CgACAgIAAxkBAAMzYbPGofEZUC3aWbf8h0mb5S0wkcUAAogSAAJJD5lJ41SfXxDFDKYjBA']
    await bot.send_animation(chat_id=chat_id, animation=random.choice(anime_ids))
    await asyncio.sleep(rand_time)
    if '-' in str(chat_id):
        table_name = str(chat_id)[1:]
    else:
        table_name = str(chat_id)
    result = random.randrange(0, 13)
    if result == 0:
        sumbol = '💚'
    elif result == 1 or result == 3 or result == 5 or result == 7 or result == 9 or result == 11:
        sumbol = '🔴'
    else:
        sumbol = '⚫️'
    ruletka_data = sqLite.give_top_bigmany(table=f'ruletka{table_name}', sort_name='telegram_id')
    lost_text = ''
    win_text = ''
    for line in ruletka_data:

        if str(line[3]).isdigit():
            # Собираем текст тех кто выиграл
            if int(line[3]) == result:
                win_text = win_text + f'<a href="tg://user?id={line[1]}">{line[5]}</a> выиграл {line[2] * 12} на {line[3]}\n'
                read_and_save_data(tg_id=line[1], deal=line[2], income=line[2] * 12)
                read_and_save_data_chat(tg_id=line[1], deal=line[2], income=line[2] * 12, chat_id=chat_id)
                sqLite.ins_log(tg_id=str(line[1]), info=f'выигрыш в рулетку', money=f"+{line[2] * 12}",
                               chanel_id=chat_id)
            else:
                if result == 0:
                    read_and_save_data(tg_id=line[1], deal=line[2], income=line[2] / 2)
                    read_and_save_data_chat(tg_id=line[1], deal=line[2], income=line[2] / 12, chat_id=chat_id)
                    sqLite.ins_log(tg_id=str(line[1]), info=f'проигрыш в рулетку', money=f"+{line[2] / 2}",
                                   chanel_id=chat_id)
                else:
                    lost_text = lost_text + f'{line[5]} {line[2]} на {line[3]}\n'
                    read_and_save_data(tg_id=line[1], deal=line[2], income=0)
                    read_and_save_data_chat(tg_id=line[1], deal=line[2], income=0, chat_id=chat_id)
                    sqLite.ins_log(tg_id=str(line[1]), info=f'проигрыш в рулетку', money=f"-{line[2]}",
                                   chanel_id=chat_id)

        elif '-' in str(line[3]):
            # Собираем текст тех кто выиграл
            start = int(str(line[3]).split('-')[0])
            finish = int(str(line[3]).split('-')[1])
            if start <= result <= finish:

                range_rul = finish - start + 1
                if range_rul == 2:
                    koeficient = 6
                elif range_rul == 3:
                    koeficient = 4
                elif range_rul == 4:
                    koeficient = 3
                elif range_rul == 5:
                    koeficient = 2.4
                elif range_rul == 6:
                    koeficient = 2
                elif range_rul == 7:
                    koeficient = 1.7
                elif range_rul == 8:
                    koeficient = 1.5
                elif range_rul == 9:
                    koeficient = 1.33
                elif range_rul == 10:
                    koeficient = 1.2
                elif range_rul == 11:
                    koeficient = 1.09
                elif range_rul == 12:
                    koeficient = 1
                else:
                    koeficient = 0.92
                win_text = win_text + f'<a href="tg://user?id={line[1]}">{line[5]}</a> выиграл {line[2] * koeficient} ' \
                                      f'на {line[3]}\n'
                read_and_save_data(tg_id=line[1], deal=line[2], income=line[2] * koeficient)
                read_and_save_data_chat(tg_id=line[1], deal=line[2], income=line[2] * koeficient, chat_id=chat_id)
                sqLite.ins_log(tg_id=str(line[1]), info=f'выигрыш в рулетку', money=f"+{line[2] * koeficient}",
                               chanel_id=chat_id)

            else:
                lost_text = lost_text + f'{line[5]} {line[2]} на {line[3]}\n'
                read_and_save_data(tg_id=line[1], deal=line[2], income=0)
                read_and_save_data_chat(tg_id=line[1], deal=line[2], income=0, chat_id=chat_id)
                sqLite.ins_log(tg_id=str(line[1]), info=f'проигрыш в рулетку', money=f"-{line[2]}", chanel_id=chat_id)

        elif 'красное' in str(line[3]):
            if result == 1 or result == 3 or result == 5 or result == 7 or result == 9 or result == 11:
                win_text = win_text + f'<a href="tg://user?id={line[1]}">{line[5]}</a> выиграл {line[2] * 2} на {line[3]}\n'
                read_and_save_data(tg_id=line[1], deal=line[2], income=line[2] * 2)
                read_and_save_data_chat(tg_id=line[1], deal=line[2], income=line[2] * 2, chat_id=chat_id)
                sqLite.ins_log(tg_id=str(line[1]), info=f'выигрыш в рулетку', money=f"-{line[2] * 2}",
                               chanel_id=chat_id)
            else:
                lost_text = lost_text + f'{line[5]} {line[2]} на {line[3]}\n'
                read_and_save_data(tg_id=line[1], deal=line[2], income=0)
                read_and_save_data_chat(tg_id=line[1], deal=line[2], income=0, chat_id=chat_id)
                sqLite.ins_log(tg_id=str(line[1]), info=f'проигрыш в рулетку', money=f"-{line[2]}", chanel_id=chat_id)

        elif 'черное' in str(line[3]):
            if result == 2 or result == 4 or result == 6 or result == 8 or result == 10 or result == 12:
                win_text = win_text + f'<a href="tg://user?id={line[1]}">{line[5]}</a> выиграл {line[2] * 2} на ' \
                              f'{line[3]}\n'
                read_and_save_data(tg_id=line[1], deal=line[2], income=line[2] * 2)
                read_and_save_data_chat(tg_id=line[1], deal=line[2], income=line[2] * 2, chat_id=chat_id)
                sqLite.ins_log(tg_id=str(line[1]), info=f'выигрыш в рулетку', money=f"+{line[2] * 2}",
                               chanel_id=chat_id)
            else:
                lost_text = lost_text + f'{line[5]} {line[2]} на {line[3]}\n'
                read_and_save_data(tg_id=line[1], deal=line[2], income=0)
                read_and_save_data_chat(tg_id=line[1], deal=line[2], income=0, chat_id=chat_id)
                sqLite.ins_log(tg_id=str(line[1]), info=f'проигрыш в рулетку', money=f"-{line[2]}", chanel_id=chat_id)
    if win_text == '':
        win_text = 'Никто не выиграл'
    await bot.send_message(text=f'Рулетка: {result}{sumbol}\n'
                                f'{lost_text}'
                                f'{win_text}', chat_id=chat_id, parse_mode='html')
    sqLite.delete_table(table=f'ruletka{name_id}')
    await asyncio.sleep(1)
    sqLite.new_table_ruletka(name_id)


# Повторить
async def func_repitt_mes(message: types.Message):
    user_id = message.from_user.id
    chat_id = message.chat.id
    if '-' in str(chat_id):
        table_name = str(chat_id)[1:]
    else:
        table_name = str(chat_id)
    user_data = sqLite.read_values_by_name(table=f'all_users', data=user_id)
    deals_ruletka = sqLite.read_value_table_name(table=f'ruletka{table_name}', telegram_id=user_id, graph='*')
    lengs = len(deals_ruletka)
    lust_deal_data = (deals_ruletka[lengs - 1])
    lust_deal = lust_deal_data[2]
    if int(user_data[2]) < lust_deal:
        await bot.send_message(text=f'{message.from_user.first_name}, ставка не может превышать ваши средства',
                               chat_id=chat_id)
    else:
        sqLite.insert_info(table=f'all_users', name='money', data=int(user_data[2]) - lust_deal, telegram_id=user_id)
        now = str(datetime.now()).split('.')[0]
        sqLite.insert_all_info_casino(table=f'ruletka{table_name}', money=lust_deal, deal=lust_deal_data[3],
                                      telegram_id=user_id, datatime=now, nick=message.from_user.first_name)
        if str(lust_deal_data[3]) == 'zero':
            await bot.send_message(text=f'Ставка принята: {message.from_user.first_name} {lust_deal} монет на 0💚',
                                   chat_id=chat_id)
        elif str(lust_deal_data[3]) == 'red':
            await bot.send_message(
                text=f'Ставка принята: {message.from_user.first_name} {lust_deal} монет на красное 🔴',
                chat_id=chat_id)
        elif str(lust_deal_data[3]) == 'black':
            await bot.send_message(
                text=f'Ставка принята: {message.from_user.first_name} {lust_deal} монет на черное ⚫️',
                chat_id=chat_id)
        elif '-' in str(lust_deal_data[3]):
            start = str(lust_deal_data[3]).split('-')[0]
            finish = str(lust_deal_data[3]).split('-')[1]
            await bot.send_message(text=f'Ставка принята: {message.from_user.first_name} {lust_deal} монет на {start}-'
                                        f'{finish}',
                                   chat_id=chat_id)


# Удвоить
async def func_double_mes(message: types.Message):
    user_id = message.from_user.id
    chat_id = message.chat.id
    if '-' in str(chat_id):
        table_name = str(chat_id)[1:]
    else:
        table_name = str(chat_id)
    user_data = sqLite.read_values_by_name(table=f'all_users', data=user_id)
    deals_ruletka = sqLite.read_value_table_name(table=f'ruletka{table_name}', telegram_id=user_id, graph='*')
    for deal in deals_ruletka:
        lust_deal_data = deal
        lust_deal = lust_deal_data[2] * 2
        if int(user_data[2]) < lust_deal:
            await bot.send_message(text=f'{message.from_user.first_name}, ставка не может превышать ваши средства',
                                   chat_id=chat_id)
            break
        else:
            sqLite.insert_info(table=f'all_users', name='money', data=int(user_data[2]) - lust_deal,
                               telegram_id=user_id)
            sqLite.insert_info(table=f'all_users', name='lust_deal', data=lust_deal, telegram_id=user_id)
            now = str(datetime.now()).split('.')[0]
            sqLite.insert_all_info_casino(table=f'ruletka{table_name}', money=lust_deal, deal=lust_deal_data[3],
                                          telegram_id=user_id, datatime=now, nick=message.from_user.first_name)
            if str(lust_deal_data[3]) == 'zero':
                await bot.send_message(text=f'Ставка принята: {message.from_user.first_name} {lust_deal} монет на 0💚',
                                       chat_id=chat_id)
            elif str(lust_deal_data[3]) == 'red':
                await bot.send_message(
                    text=f'Ставка принята: {message.from_user.first_name} {lust_deal} монет на красное 🔴',
                    chat_id=chat_id)
            elif str(lust_deal_data[3]) == 'black':
                await bot.send_message(
                    text=f'Ставка принята: {message.from_user.first_name} {lust_deal} монет на черное ⚫️',
                    chat_id=chat_id)
            elif '-' in str(lust_deal_data[3]):
                start = str(lust_deal_data[3]).split('-')[0]
                finish = str(lust_deal_data[3]).split('-')[1]
                await bot.send_message(
                    text=f'Ставка принята: {message.from_user.first_name} {lust_deal} монет на {start}-'
                         f'{finish}',
                    chat_id=chat_id)


# Ставки
async def my_deals(message: types.Message):
    user_id = message.from_user.id
    chat_id = message.chat.id
    if '-' in str(chat_id):
        table_name = str(chat_id)[1:]
    else:
        table_name = str(chat_id)
    deals_ruletka = sqLite.read_value_table_name(table=f'ruletka{table_name}', telegram_id=user_id, graph='*')
    text = ''
    for deal in deals_ruletka:
        money_deal = deal[2]
        text_deal = deal[3]
        if text_deal == 'red':
            text_deal = 'красное'
        elif text_deal == 'black':
            text_deal = 'черное'
        elif text_deal == 'zero':
            text_deal = '0'
        text = text + f'{money_deal} монет на {text_deal}\n'
    await bot.send_message(text=f'Ставки {message.from_user.first_name}:\n {text}',
                           chat_id=chat_id, parse_mode='html')
    # await bot.send_message(text=f'Ставки <a href="tg://user?id={message.from_user.id}">'
    #                             f'{message.from_user.first_name}</a>:\n {text}',
    #                        chat_id=chat_id, parse_mode='html')


# Отменить
async def delete_all_mes(message: types.Message):
    user_id = message.from_user.id
    chat_id = message.chat.id
    if '-' in str(chat_id):
        table_name = str(chat_id)[1:]
    else:
        table_name = str(chat_id)
    deals_ruletka = sqLite.read_value_table_name(table=f'ruletka{table_name}', telegram_id=user_id, graph='*')
    for deal in deals_ruletka:
        user_data = sqLite.read_values_by_name(table=f'all_users', data=user_id)
        lust_deal = int(deal[2])
        sqLite.insert_info(table=f'all_users', name='money', data=int(user_data[2]) + lust_deal, telegram_id=user_id)
        sqLite.delete_str(table=f'ruletka{table_name}', data=int(deal[0]), name='id')
    await bot.send_message(text=f'{message.from_user.first_name} все ставки отменены',
                           chat_id=chat_id)


# Парсим все колбэки
async def callS_ruletka(call: types.CallbackQuery):
    data = str(call.data)
    if data.startswith('ruletka_one_to_3'):
        await func_start_to_finish(call, start=1, finish=3)
    elif data.startswith('ruletka_for_to_6'):
        await func_start_to_finish(call, start=4, finish=6)
    elif data.startswith('ruletka_seven_to_9'):
        await func_start_to_finish(call, start=7, finish=9)
    elif data.startswith('ruletka_ten_to_12'):
        await func_start_to_finish(call, start=10, finish=12)
    elif data.startswith('ruletka_to_red'):
        await func_red(call)
    elif data.startswith('ruletka_to_black'):
        await func_black(call)
    elif data.startswith('ruletka_to_0'):
        await func_zero(call)
    elif data.startswith('ruletka_repit'):
        await func_repitt(call)
    elif data.startswith('ruletka_double'):
        await func_double(call)
    elif data.startswith('ruletka_start'):
        await func_start(call)


# Парсим сообщения на красное
async def on_red(message: types.Message):
    deal = int(message.text.split(' ')[0])
    await func_red_mes(message, deal=deal)


# Парсим сообщения на черное
async def on_black(message: types.Message):
    deal = int(message.text.split(' ')[0])
    await func_black_mes(message, deal=deal)


# Парсим сообщения на зеро
async def on_zero_mes(message: types.Message):
    deal = int(message.text.split(' ')[0])
    await func_zero_mes(message, deal=deal)


# Парсим сообщения на число
async def on_number_mes(message: types.Message):
    deal = int(message.text.split(' ')[0])
    await func_number_mes(message, deal=deal)


# Интервал от и до
async def on_range_mes(message: types.Message):
    numbers = message.text.split(' на ')[1]
    deal = int(message.text.split(' на ')[0])
    start = int(str(numbers).split('-')[0])
    finish = int(str(numbers).split('-')[1])
    await func_start_to_finish_mes(message=message, start=start, finish=finish, deal=deal)


# Интервал от и до
async def on_range_short_mes(message: types.Message):
    numbers = message.text.split(' ')[1]
    deal = int(message.text.split(' ')[0])
    start = int(str(numbers).split('-')[0])
    finish = int(str(numbers).split('-')[1])
    await func_start_to_finish_mes(message=message, start=start, finish=finish, deal=deal)


# Удвоить все мои ставки
async def on_double(message: types.Message):
    await func_double_mes(message)
