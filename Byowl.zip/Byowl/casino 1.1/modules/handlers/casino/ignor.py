from aiogram import types
from modules import sqLite


# Включаем игнор
async def ignore(message: types.Message):
    victem_id = message.reply_to_message.from_user.id
    user_id = message.from_user.id
    victem_data = sqLite.read_values_by_name(table='all_users', data=victem_id)

    user_name = message.from_user.first_name
    victem_name = message.reply_to_message.from_user.first_name

    if victem_data[16] == 1 or victem_data[17] == 1:
        pass
    else:
        ignor_data = sqLite.read_value_2_(user_tg_id=user_id, ignor_tg_id=victem_id)
        if str(ignor_data) == '[]':
            await message.answer(f'{message.from_user.first_name} запретил {victem_name} отвечать на свои сообщения')
            sqLite.insert_ignor_table(table='ignor', user_tg_id=user_id, ignor_tg_id=victem_id)
        else:
            await message.answer(f'{message.from_user.first_name} разрешил {victem_name} отвечать на свои сообщения')
            sqLite.delete_str(table='ignor', name='id', data=ignor_data[0][0])
