import asyncio
import random
from aiogram import types
from modules.handlers.casino.read_and_save_data import read_and_save_data
from modules.dispatcher import bot


async def bandit(message: types.Message):
    tg_id = message.from_user.id
    chat_id = message.chat.id
    if str(message.text.split(' ')[1]).isdigit():
        deal = int(message.text.split(' ')[1])
        cards = ('🖕', '💲', '🌝', '🌚', '🍒', '🍓', '🍌', '🖕')
        card_1 = random.randrange(1, 8)
        card_2 = random.randrange(1, 8)
        card_3 = random.randrange(1, 8)

        if card_1 == 2 and card_2 == 2 and card_3 == 2:
            income = deal * 7
        elif card_1 == 1 or card_2 == 1 or card_3 == 1:
            income = 0
        elif card_1 == 8 or card_2 == 8 or card_3 == 8:
            income = 0
        elif card_1 == card_2 and card_3 == card_2:
            income = deal * 3
        elif card_1 == card_2 or card_3 == card_2 or card_1 == card_3:
            income = deal * 1.5
        else:
            income = deal * random.randrange(11, 13) / 10
        card_1 = cards[card_1 - 1]
        card_2 = cards[card_2 - 1]
        card_3 = cards[card_3 - 1]
        id_mes = message.message_id + 1
        await bot.send_message(chat_id=chat_id, text='Dragon\n|🌫️|🌫️|🌫️|')
        await asyncio.sleep(1)
        await bot.edit_message_text(chat_id=chat_id, message_id=id_mes, text=f'Dragon\n|{card_1}|🌫️|🌫️|')
        await asyncio.sleep(1)
        await bot.edit_message_text(chat_id=chat_id, message_id=id_mes, text=f'Dragon\n|{card_1}|{card_2}|🌫️|')
        await asyncio.sleep(1)
        await bot.edit_message_text(chat_id=chat_id, message_id=id_mes, text=f'Dragon\n|{card_1}|{card_2}|{card_3}| '
                                                                             f'Выигрыш {income}')
        read_and_save_data(tg_id=tg_id, deal=deal, income=income)

    else:
        await bot.send_message(chat_id=tg_id, text='Неправильная команда')
