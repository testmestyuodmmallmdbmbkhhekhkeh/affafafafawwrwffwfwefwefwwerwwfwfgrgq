import datetime

from modules import sqLite
from modules.dispatcher import bot
from aiogram import types
from modules.keyboards import wedding_start_kb
import random


def random_licensy():
    sumbols = '123456789abcdefghiklmnopqrstuvwxyz'
    licensi_n = ''
    for i in range(0, 15):
        licensi_n = licensi_n + random.choice(sumbols)
    return licensi_n


def send_main_text(name: str = ' ',
                   man: str = ' ',
                   woman: str = ' ',
                   weetnes_m: str = ' ',
                   weetnes_w: str = ' ',
                   registr: str = ' ',
                   guests: str = ' '):
    text = f'{name} предлагает провести церемонию бракосочетания💏\n\n' \
           f'🤵Жених: {man}\n' \
           f'👰Невеста: {woman}\n\n' \
           f'👨Свидетель: {weetnes_m}\n' \
           f'👩Свидетельница: {weetnes_w}\n\n' \
           f'👩🏼💼Регистратор: {registr}\n\n' \
           f'💃Гости: {guests}'
    return text


def random_text():
    text = ("— Ты правда хочешь, чтобы мы были всё же на «ты»? \n— Я хочу, чтобы мы были же-на-ты.",
            "Мало быть мужем и женой, надо ещё стать друзьями и любовниками, чтобы потом не искать их на стороне…",
            "Брак — настоящий аттракцион. И я рад, что ты мой ремень безопасности. Он тоже боялся. Но и понимал, что "
            "если они не сделают этот шаг вместе, то дальше им придётся идти в одиночестве. До конца жизни, потому "
            "что ничего подобного с ними уже никогда не произойдёт, а на меньшее они не согласятся...",
            "Он тоже боялся. Но и понимал, что если они не сделают этот шаг вместе, то дальше им придётся идти в "
            "одиночестве. До конца жизни, потому что ничего подобного с ними уже никогда не произойдёт, а на меньшее "
            "они не согласятся...",
            "— Слушай, а почему ты не выходила замуж? \n"
            "— Тебя ждала...",
            "Брак – это мирное сосуществование двух нервных систем.",
            "Я не хочу только спать с тобой. Я хочу жениться, чтобы делить с тобой все, что у тебя внутри.",
            "Хорошая семья та, в которой муж и жена днем забывают, что они любовники, а ночью — о том, что они "
            "супруги.",
            "Он готов умереть за тебя, и больше того – он хочет на тебе жениться.",
            "Любовь, как выяснилось, — это нечто большее, чем три слова, оброненные перед сном. Любовь поддерживается "
            "действием. Нежностью даже в тех вещах, которые мы делаем друг для друга изо дня в день.",
            "Смысл брака не в том. чтобы думать одинаково, а в том, чтобы думать вместе.",
            "Брак представляет собой отношения между мужчиной и женщиной, где независимость обеих сторон одинакова, "
            "зависимость обоюдна, а обязательства взаимны.")
    return random.choice(text)


# Создаем свадьбу
async def wedding(message: types.Message):
    chat_id = message.chat.id
    if '-' not in str(chat_id):
        pass
    else:
        tg_id = message.from_user.id
        licensi_w = int(sqLite.read_values_by_name(table='all_users', data=tg_id)[11])
        if licensi_w < 1:
            await message.answer(f'У вас отсутствует лицензия,вы можете купить ее в магазине.')
        else:
            sqLite.insert_info(table='all_users', name="license", data=(licensi_w-1), telegram_id=tg_id)
            # создаем номер лицензии
            check = '123'
            while check is not None:
                licensi_n = random_licensy()
                check = sqLite.read_values_by_name(table='weddings', id_name='wedding_id', data=licensi_n)
            sqLite.insert_first_note(table='weddings', id_name='wedding_id', telegram_id=licensi_n)
            sqLite.insert_info(table='weddings', name='chat', data=message.chat.title, id_name='wedding_id',
                               telegram_id=licensi_n)
            sqLite.ins_log(tg_id=tg_id, info=f'Создал свадьбу', money='-1', chanel_id=chat_id)
            await message.answer(text=send_main_text(name=message.from_user.first_name),
                                 reply_markup=wedding_start_kb(licensi_n, message.from_user.id))


# Заполняем поля
async def in_wedding(call: types.CallbackQuery):
    nick = call.from_user.first_name
    role = call.data.split('_')[1]
    licensi_n = call.data.split('_')[2]
    creator = call.data.split('_')[3]
    check = sqLite.read_values_by_name(table='weddings', id_name='wedding_id', data=licensi_n, name=role)[0]
    if check is None:
        data = sqLite.read_values_by_name(table='weddings', id_name='wedding_id', data=licensi_n)
        if f"{nick}#№%{call.from_user.id}" in str(data):
            await bot.answer_callback_query(call.id)
        else:
            sqLite.insert_info(table='weddings', name=role, data=f"{nick}#№%{call.from_user.id}", id_name='wedding_id',
                               telegram_id=licensi_n)
            data = sqLite.read_values_by_name(table='weddings', id_name='wedding_id', data=licensi_n)
            first_name = sqLite.read_values_by_name(table='all_users', data=int(creator))[10]
            person = lambda x: " " if str(x) == 'None' else str(x)
            man = person(str(data[2]).split("#№%")[0])
            woman = person(str(data[3]).split("#№%")[0])
            weetnes_m = person(str(data[4]).split("#№%")[0])
            weetnes_w = person(str(data[5]).split("#№%")[0])
            registr = person(str(data[6]).split("#№%")[0])
            guests = person(str(data[7]).split("#№%")[0])
            await call.message.edit_text(text=send_main_text(name=first_name,
                                                             man=man,
                                                             woman=woman,
                                                             weetnes_m=weetnes_m,
                                                             weetnes_w=weetnes_w,
                                                             registr=registr,
                                                             guests=guests),
                                         reply_markup=wedding_start_kb(licensi_n, creator))
    else:
        await bot.answer_callback_query(call.id)


# Заполняем поля за гостей
async def in_guests_wedding(call: types.CallbackQuery):
    nick = call.from_user.first_name
    licensi_n = call.data.split('_')[2]
    creator = call.data.split('_')[3]

    data = sqLite.read_values_by_name(table='weddings', id_name='wedding_id', data=licensi_n)
    if f"{nick}" in str(data):
        await bot.answer_callback_query(call.id)
    else:
        if str(data[7]) == 'None':
            sqLite.insert_info(table='weddings', name='guests', data=f"{nick}", id_name='wedding_id',
                               telegram_id=licensi_n)
        else:
            sqLite.insert_info(table='weddings', name='guests', data=f"{data[7]}, {nick}", id_name='wedding_id',
                               telegram_id=licensi_n)
        data = sqLite.read_values_by_name(table='weddings', id_name='wedding_id', data=licensi_n)
        first_name = sqLite.read_values_by_name(table='all_users', data=int(creator))[10]
        person = lambda x: " " if str(x) == 'None' else str(x)
        man = person(str(data[2]).split("#№%")[0])
        woman = person(str(data[3]).split("#№%")[0])
        weetnes_m = person(str(data[4]).split("#№%")[0])
        weetnes_w = person(str(data[5]).split("#№%")[0])
        registr = person(str(data[6]).split("#№%")[0])
        guests = person(str(data[7]).split("#№%")[0])
        await call.message.edit_text(text=send_main_text(name=first_name,
                                                         man=man,
                                                         woman=woman,
                                                         weetnes_m=weetnes_m,
                                                         weetnes_w=weetnes_w,
                                                         registr=registr,
                                                         guests=guests), reply_markup=wedding_start_kb(licensi_n, creator))


# Жених и невеста ставят подписи
async def sing_wedding(call: types.CallbackQuery):
    nick = call.from_user.first_name
    role = call.data.split('_')[1]
    licensi_n = call.data.split('_')[2]
    creator = call.data.split('_')[3]
    wedding_data = sqLite.read_values_by_name(table='weddings', id_name='wedding_id', data=licensi_n)
    if f"{nick}#№%{call.from_user.id}" == str(wedding_data[2]):
        sqLite.insert_info(table='weddings', name='man', data=f"✅{nick}#№%{call.from_user.id}", id_name='wedding_id',
                           telegram_id=licensi_n)
        data = sqLite.read_values_by_name(table='weddings', id_name='wedding_id', data=licensi_n)
        first_name = sqLite.read_values_by_name(table='all_users', data=int(creator))[10]
        person = lambda x: " " if str(x) == 'None' else str(x)
        man = person(str(data[2]).split("#№%")[0])
        woman = person(str(data[3]).split("#№%")[0])
        weetnes_m = person(str(data[4]).split("#№%")[0])
        weetnes_w = person(str(data[5]).split("#№%")[0])
        registr = person(str(data[6]).split("#№%")[0])
        guests = person(str(data[7]).split("#№%")[0])
        await call.message.edit_text(text=send_main_text(name=first_name,
                                                         man=man,
                                                         woman=woman,
                                                         weetnes_m=weetnes_m,
                                                         weetnes_w=weetnes_w,
                                                         registr=registr,
                                                         guests=guests),
                                     reply_markup=wedding_start_kb(licensi_n, creator))
    elif f"{nick}#№%{call.from_user.id}" == str(wedding_data[3]):
        sqLite.insert_info(table='weddings', name="woman", data=f"✅{nick}#№%{call.from_user.id}", id_name='wedding_id',
                           telegram_id=licensi_n)
        data = sqLite.read_values_by_name(table='weddings', id_name='wedding_id', data=licensi_n)
        first_name = sqLite.read_values_by_name(table='all_users', data=int(creator))[10]
        person = lambda x: " " if str(x) == 'None' else str(x)
        man = person(str(data[2]).split("#№%")[0])
        woman = person(str(data[3]).split("#№%")[0])
        weetnes_m = person(str(data[4]).split("#№%")[0])
        weetnes_w = person(str(data[5]).split("#№%")[0])
        registr = person(str(data[6]).split("#№%")[0])
        guests = person(str(data[7]).split("#№%")[0])
        await call.message.edit_text(text=send_main_text(name=first_name,
                                                         man=man,
                                                         woman=woman,
                                                         weetnes_m=weetnes_m,
                                                         weetnes_w=weetnes_w,
                                                         registr=registr,
                                                         guests=guests),
                                     reply_markup=wedding_start_kb(licensi_n, creator))
    else:
        await bot.answer_callback_query(call.id)


# Заключаем брак
async def registr_wedding(call: types.CallbackQuery):
    await bot.answer_callback_query(call.id)
    licensi_n = call.data.split('_')[2]
    wedding_data = sqLite.read_values_by_name(table='weddings', id_name='wedding_id', data=licensi_n)
    if f"✅" in str(wedding_data[2]) and f"✅" in str(wedding_data[3]):
        proces = True
        for k in wedding_data:
            if k is None:
                proces = False
            else:
                pass
        check_guests = str(wedding_data[7]).split(', ')
        if len(check_guests) < 2:
            pass
        else:
            if proces:
                data = sqLite.read_values_by_name(table='weddings', id_name='wedding_id', data=licensi_n)
                man_id = str(data[2]).split("#№%")[1]
                woman_id = str(data[3]).split("#№%")[1]
                data_man = sqLite.read_values_by_name(table='all_users', data=man_id)
                data_woman = sqLite.read_values_by_name(table='all_users', data=woman_id)

                man = str(data[2]).split("#№%")[0]
                woman = str(data[3]).split("#№%")[0]

                sqLite.insert_info(table='weddings', name="data_d",
                                   data=str(datetime.datetime.now()).split('.')[0],
                                   id_name='wedding_id',
                                   telegram_id=licensi_n)
                sqLite.insert_info(table='weddings', name="status",
                                   data="wedding",
                                   id_name='wedding_id',
                                   telegram_id=licensi_n)
                # Сохраняем свидетельства
                sqLite.insert_info(table='all_users', name="wedding",
                                   data=licensi_n,
                                   telegram_id=man_id)
                sqLite.insert_info(table='all_users', name="wedding",
                                   data=licensi_n,
                                   telegram_id=woman_id)
                # Сохраняем супругов
                sqLite.insert_info(table='all_users', name="hasben",
                                   data=woman[1:],
                                   telegram_id=man_id)
                sqLite.insert_info(table='all_users', name="hasben",
                                   data=man[1:],
                                   telegram_id=woman_id)

                # Сохраняем обновляем имена в свидетельстве
                sqLite.insert_info(table='weddings', name="man",
                                   data=str(data[2])[1:],
                                   id_name='wedding_id',
                                   telegram_id=licensi_n)
                sqLite.insert_info(table='weddings', name="woman",
                                   data=str(data[3])[1:],
                                   id_name='wedding_id',
                                   telegram_id=licensi_n)
                weetnes_m = str(data[4]).split("#№%")[0]
                weetnes_w = str(data[5]).split("#№%")[0]
                registr = str(data[6]).split("#№%")[0]
                guests = str(data[7])
                await call.message.edit_text(text=f'Брак зарегистрирован\n\n'
                                                  f'{random_text()}\n\n'
                                                  f'с уважением регистрация @ByOwl_Technical_Support')
                await call.message.answer(text=f'{man[1:]} и {woman[1:]}\n'
                                               f'заключили брак в чате {str(data[1])}\n'
                                               f'Регистратор: {registr}\n'
                                               f'Свидетель: {weetnes_m}\n'
                                               f'Свидетельница: {weetnes_w}\n'
                                               f'Гости: {guests}\n'
                                               f'Дата: {str(data[9])}\n'
                                               f'Код: {licensi_n}')
    else:
        await bot.answer_callback_query(call.id)


# Парсим все колбэки
async def call_wedding(call: types.CallbackQuery):
    data = call.data
    if data.startswith('wedding_man_'):
        await in_wedding(call)
    elif data.startswith('wedding_woman_'):
        await in_wedding(call)
    elif data.startswith('wedding_guests_'):
        await in_guests_wedding(call)
    elif data.startswith('wedding_witnessw_'):
        await in_wedding(call)
    elif data.startswith('wedding_witnessm_'):
        await in_wedding(call)
    elif data.startswith('wedding_start_'):
        await registr_wedding(call)
    elif data.startswith('wedding_sing_'):
        await sing_wedding(call)
    elif data.startswith('wedding_registrar_'):
        await in_wedding(call)
    elif data.startswith('wedding_cancel_'):
        if call.from_user.id == int(data.split('_')[3]):
            licensi_w = int(sqLite.read_values_by_name(table='all_users', data=call.from_user.id)[11])
            sqLite.insert_info(table='all_users', name="license", data=(licensi_w + 1), telegram_id=call.from_user.id)
            data = sqLite.read_values_by_name(table='weddings', id_name='wedding_id', data=str(data.split('_')[2]))[0]
            sqLite.delete_str(table='weddings', name='id', data=int(data))
            sqLite.ins_log(tg_id=data.split('_')[3], info='Свадьба отменена', money='1', chanel_id=call.message.chat.id)
            await call.message.edit_text("Свадьба отменена")
        else:
            await bot.answer_callback_query(call.id)
            print(data)



