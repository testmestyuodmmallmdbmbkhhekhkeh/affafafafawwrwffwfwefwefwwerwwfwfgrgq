from modules import sqLite
from modules.handlers.casino.read_and_save_data import read_and_save_data
from modules.dispatcher import bot
from aiogram import types
from modules.keyboards import duel_start_kb, duel_keyb, duel_playe_keyb


async def duel(message: types.Message, rep_tg_id: int = None):
    deal = message.text.split(' ')[1]
    user_id = message.from_user.id
    tg_id = message.from_user.id
    money = int(sqLite.read_values_by_name(table='all_users', data=tg_id)[2])
    if money < int(deal):
        await message.answer(f'{message.from_user.first_name}, ставка не может превышать ваши средства')
    else:
        if rep_tg_id is None:
            await message.answer(f'{message.from_user.first_name} вызывает на Дуэль! Ставка: {deal}',
                                 reply_markup=duel_start_kb(user_id, deal))
        else:
            await message.answer(f'{message.from_user.first_name} вызывает на Дуэль! Ставка: {deal}',
                                 reply_markup=duel_start_kb(user_id, deal, rep_tg_id))


# Начинаем игру
async def start_duel(call: types.CallbackQuery):
    tg_id_start = call.data.split('_')[2]
    deal = call.data.split('_')[4]
    money = sqLite.read_values_by_name(table='all_users', data=call.from_user.id)
    if int(money[2]) < int(deal):
        await call.message.answer(f'{call.from_user.first_name}, ставка не может превышать ваши средства')
    else:

        if call.from_user.id == int(tg_id_start):
            await bot.answer_callback_query(call.id)
        else:
            await bot.answer_callback_query(call.id)
            user_start = sqLite.read_values_by_name(table='all_users', data=tg_id_start)

            sqLite.insert_info(table=f'all_users', name='money', data=int(money[2]) - int(deal),
                               telegram_id=call.from_user.id)
            sqLite.insert_info(table=f'all_users', name='money', data=int(user_start[2]) - int(deal),
                               telegram_id=tg_id_start)
            await call.message.edit_text(f'1️⃣1 {user_start[10]}\n'
                                         f'2️⃣2 {call.from_user.first_name}\n'
                                         f'Сейчас ходит : {user_start[10]}',
                                         reply_markup=duel_keyb(user_start[1], call.from_user.id, deal))


# Основная игра
async def main_duel(call: types.CallbackQuery):
    tg_id_next = call.data.split('_')[4]
    tg_id_start = call.data.split('_')[3]
    death = int(call.data.split('_')[2])
    open_btn = call.data.split('_')[5]
    deal = call.data.split('_')[6]
    btn = call.data.split('_')[1]
    if call.from_user.id != int(tg_id_start):
        await bot.answer_callback_query(call.id)
    else:
        await bot.answer_callback_query(call.id)
        user_start = sqLite.read_values_by_name(table='all_users', data=tg_id_next)
        if len(open_btn) % 2 == 0:
            await call.message.edit_text(f'1️⃣1 {call.from_user.first_name}\n'
                                         f'2️⃣2 {user_start[10]}\n'
                                         f'Сейчас ходит : {user_start[10]}',
                                         reply_markup=duel_playe_keyb(user_1_id=user_start[1],
                                                                      user_2_id=call.from_user.id,
                                                                      death=death, deal=deal,
                                                                      open_btn=open_btn, btn=btn))
        else:
            await call.message.edit_text(f'1️⃣1 {user_start[10]}\n'
                                         f'2️⃣2 {call.from_user.first_name}\n'
                                         f'Сейчас ходит : {user_start[10]}',
                                         reply_markup=duel_playe_keyb(user_1_id=user_start[1],
                                                                      user_2_id=call.from_user.id,
                                                                      death=death, deal=deal,
                                                                      open_btn=open_btn, btn=btn))


# Конец игры
async def death_duel(call: types.CallbackQuery):
    chat_id = call.message.chat.id
    tg_1 = int(call.data.split('_')[2])
    tg_2 = int(call.data.split('_')[3])
    deal = int(call.data.split('_')[4])
    user_1 = sqLite.read_values_by_name(table='all_users', data=tg_1)
    user_2 = sqLite.read_values_by_name(table='all_users', data=tg_2)
    if call.from_user.id == tg_1:
        read_and_save_data(tg_id=tg_2, deal=deal, income=deal * 2)
        sqLite.ins_log(tg_id=str(tg_2), info=f'выигрыш в дуэли', money=f"+{deal}",
                       chanel_id=chat_id, victem_id=str(tg_1))
        sqLite.ins_log(tg_id=str(tg_1), info=f'проигрыш в дуэли', money=f"-{deal}",
                       chanel_id=chat_id, victem_id=str(tg_2))
        await call.message.edit_text(f'Игра окончена!\n\n'
                                     f'Победитель {user_2[10]}\n'
                                     f'Проиграл {user_1[10]}\n\n'
                                     f'Выигрыш: {deal} монет')
    else:
        read_and_save_data(tg_id=tg_1, deal=deal, income=deal * 2)
        sqLite.ins_log(tg_id=str(tg_1), info=f'выигрыш в дуэли', money=f"+{deal}",
                       chanel_id=chat_id, victem_id=str(tg_2))
        sqLite.ins_log(tg_id=str(tg_2), info=f'проигрыш в дуэли', money=f"-{deal}",
                       chanel_id=chat_id, victem_id=str(tg_1))
        await call.message.edit_text(f'Игра окончена!\n\n'
                                     f'Победитель {user_1[10]}\n'
                                     f'Проиграл {user_2[10]}\n\n'
                                     f'Выигрыш: {deal} монет')


# Конец игры когда сдался
async def close_duel(call: types.CallbackQuery):
    chat_id = call.message.chat.id
    tg_1 = int(call.data.split('_')[2])
    tg_2 = int(call.data.split('_')[3])
    deal = int(call.data.split('_')[4])
    user_1 = sqLite.read_values_by_name(table='all_users', data=tg_1)
    user_2 = sqLite.read_values_by_name(table='all_users', data=tg_2)
    if call.from_user.id != tg_1 and call.from_user.id != tg_2:
        await bot.answer_callback_query(call.id)
    else:
        await bot.answer_callback_query(call.id)
        if call.from_user.id == tg_1:
            read_and_save_data(tg_id=tg_2, deal=deal, income=deal * 2)
            sqLite.ins_log(tg_id=str(tg_2), info=f'выигрыш в дуэли', money=f"+{deal}",
                           chanel_id=chat_id, victem_id=str(tg_1))
            sqLite.ins_log(tg_id=str(tg_1), info=f'проигрыш в дуэли', money=f"-{deal}",
                           chanel_id=chat_id, victem_id=str(tg_2))
            await call.message.edit_text(f'Игра окончена!\n\n'
                                      f'Победитель {user_2[10]}\n'
                                      f'Проиграл {user_1[10]}\n\n'
                                      f'Выигрыш: {deal} монет')
        else:
            read_and_save_data(tg_id=tg_1, deal=deal, income=deal * 2)
            sqLite.ins_log(tg_id=str(tg_1), info=f'выигрыш в дуэли', money=f"+{deal}",
                           chanel_id=chat_id, victem_id=str(tg_2))
            sqLite.ins_log(tg_id=str(tg_2), info=f'проигрыш в дуэли', money=f"-{deal}",
                           chanel_id=chat_id, victem_id=str(tg_1))
            await call.message.edit_text(f'Игра окончена!\n\n'
                                      f'Победитель {user_1[10]}\n'
                                      f'Проиграл {user_2[10]}\n\n'
                                      f'Выигрыш: {deal} монет')


# Отмена игры до начала
async def close_duel_on_start(call: types.CallbackQuery):
    tg_1 = int(call.data.split('_')[3])
    tg_2 = call.data.split('_')[4]
    if tg_2 == 'free':
        if call.from_user.id == tg_1:
            await call.message.edit_text("Дуэль была отменена")
        else:
            pass
    else:
        if call.from_user.id == tg_1 or call.from_user.id == int(tg_2):
            await call.message.edit_text("Дуэль была отменена")
        else:
            pass


# Парсим все колбэки
async def call_duel(call: types.CallbackQuery):
    data = call.data
    if data.split('_')[3] == 'free':
        await start_duel(call)
    elif data.startswith('s_duel_close_'):
        await close_duel_on_start(call)
    else:
        tg_id = int(call.data.split('_')[3])
        await bot.answer_callback_query(call.id)
        if tg_id == call.from_user.id:
            await start_duel(call)
        else:
            pass
