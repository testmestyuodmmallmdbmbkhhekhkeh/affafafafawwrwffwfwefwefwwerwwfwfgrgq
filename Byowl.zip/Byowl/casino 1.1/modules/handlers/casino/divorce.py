import datetime

from modules import sqLite
from modules.dispatcher import bot
from aiogram import types
from modules.keyboards import divorce_start_kb
import random


def send_main_text(name: str = ' ',
                   man: str = ' ',
                   woman: str = ' ',
                   registr: str = ' ',
                   wietnes: str = ' '):
    text = f'{name} предлагает провести развод⌛️\n\n' \
           f'🧔Муж: {man}\n' \
           f'👱Жена: {woman}\n\n' \
           f'👩🏻⚖️Судья: {registr}\n' \
           f'🙋♂Присяжные: {wietnes}'
    return text


def random_text():
    text = ("Развод — одно из величайших достижений человечества! Чтобы влюбиться, достаточно и минуты. Чтобы развестись, иногда приходится прожить двадцать лет вместе.",
            "Когда люди уже не любят друг друга, им трудно найти повод для того, чтобы разойтись.",
            "Распадающийся брак выявляет все самое дурное в обоих супругах.",
            "Семьи разрушаются тогда, когда люди понимают те намеки, которые ты и не собирался делать, или когда они не обращают внимания на те намеки, которые ты делаешь.",
            "— К сожалению, при живой жене вы не можете жениться вторично.\n— При живой? Вы предлагаете её убить?",
            "Будучи в некотором нервном перевозбуждении, герцог вдруг схватил и подписал несколько прошений о разводе словами: «На волю, всех на волю!»",
            "— Разведенный — не значит плохой!\n— Это написано на фирменных салфетках их клуба.",
            "— Ты не забыл, что через полчаса начнётся бракоразводный процесс?\n— Он начался давно. В тот день, когда я тебя увидел.",
            "Развод столь же стар, как и брак, хотя, впрочем, брак на несколько недель древнее.",
            "Я развелся, потому что моя жена бросила меня ради другой женщины. <…> Но я воспринял это довольно стойко – я попытался задавить их обеих машиной.",
            "Мы раздумывали, что делать: поехать на Багамские острова или развестись. Но в конце концов решили, что Багамы — удовольствие только на две недели, а хороший развод остается на всю жизнь.",
            "Если брак разрывается безболезненно, значит не такой уж и ценный был брак.")
    return random.choice(text)


# Создаем развод
async def divorce(message: types.Message):
    chat_id = message.chat.id
    if '-' not in str(chat_id):
        pass
    else:
        tg_id = message.from_user.id
        licensi_w = sqLite.read_values_by_name(table='all_users', data=tg_id)
        if str(licensi_w[12]) == '0':
            await message.answer(f'Вы не состоите в браке')
        else:
            all_licensis = str(licensi_w[12]).split(', ')
            if len(all_licensis) > 1:
                licensi = all_licensis[len(all_licensis) - 1]
            else:
                licensi = all_licensis[0]
            wedding_data = str(sqLite.read_values_by_name(table='weddings', id_name='wedding_id', data=licensi)[10])
            if 'vip' in wedding_data:
                number_license = int(licensi_w[14])
            else:
                number_license = int(licensi_w[11])
            if number_license < 1:
                await message.answer(f'У вас отсутствует лицензия,вы можете приобрести ее в магазине.')
            else:
                hasben = sqLite.read_values_by_name(table='all_users', data=tg_id)
                all_licensis = str(hasben[12]).split(', ')
                if len(all_licensis) > 1:
                    licensi = all_licensis[len(all_licensis)-1]
                else:
                    licensi = all_licensis[0]

                if 'vip' in wedding_data:
                    sqLite.ins_log(tg_id=str(tg_id), info=f'Отмена VIP развод', money=f"+1",
                                   chanel_id=chat_id)
                    sqLite.insert_info(table='all_users', name="license_vip", data=(number_license - 1),
                                       telegram_id=tg_id)
                else:
                    sqLite.ins_log(tg_id=str(tg_id), info=f'Отмена VIP развод', money=f"+1",
                                   chanel_id=chat_id)
                    sqLite.insert_info(table='all_users', name="license", data=(number_license - 1), telegram_id=tg_id)

                data = sqLite.read_values_by_name(table='weddings', id_name='wedding_id', data=licensi)
                sqLite.insert_first_note(table='divorce', id_name='divorce_id', telegram_id=licensi)
                sqLite.insert_info(table='divorce', name='chat', data=message.chat.title, id_name='divorce_id',
                                   telegram_id=licensi)
                sqLite.insert_info(table='divorce', name='man', data=str(data[2]), id_name='divorce_id',
                                   telegram_id=licensi)
                sqLite.insert_info(table='divorce', name='woman', data=str(data[3]), id_name='divorce_id',
                                   telegram_id=licensi)
                await message.answer(text=send_main_text(name=message.from_user.first_name,
                                                         woman=str(data[3]).split('#№%')[0],
                                                         man=str(data[2]).split('#№%')[0]),
                                     reply_markup=divorce_start_kb(licensi, message.from_user.id))


# Создаем свадьбу если reply
async def divorce_rep(message: types.Message):
    chat_id = message.reply_to_message.chat.id
    tg_id = message.reply_to_message.from_user.id
    if '-' not in str(chat_id):
        pass
    else:
        tg_id_main = message.from_user.id
        licensi_w = sqLite.read_values_by_name(table='all_users', data=tg_id_main)
        check_brack = sqLite.read_values_by_name(table='all_users', data=tg_id)
        if str(check_brack[12]) == '0':
            await message.answer(f'Пользователь не состоит в браке')
        else:
            all_licensis = str(check_brack[12]).split(', ')
            if len(all_licensis) > 1:
                licensi = all_licensis[len(all_licensis) - 1]
            else:
                licensi = all_licensis[0]
            wedding_data = str(sqLite.read_values_by_name(table='weddings', id_name='wedding_id', data=licensi)[10])
            if 'vip' in wedding_data:
                number_license = int(licensi_w[14])
            else:
                number_license = int(licensi_w[11])
            if number_license < 1:
                await message.answer(f'У вас отсутствует лицензия,вы можете купить ее в магазине.')
            else:
                if 'vip' in wedding_data:
                    sqLite.insert_info(table='all_users', name="license_vip", data=(number_license - 1),
                                       telegram_id=tg_id_main)
                else:
                    sqLite.insert_info(table='all_users', name="license", data=(number_license - 1), telegram_id=tg_id_main)
                tg_id = message.reply_to_message.from_user.id
                hasben = sqLite.read_values_by_name(table='all_users', data=tg_id)
                all_licensis = str(hasben[12]).split(', ')
                if len(all_licensis) > 1:
                    licensi = all_licensis[len(all_licensis)-1]
                else:
                    licensi = all_licensis[0]
                data = sqLite.read_values_by_name(table='weddings', id_name='wedding_id', data=licensi)
                sqLite.insert_first_note(table='divorce', id_name='divorce_id', telegram_id=licensi)
                sqLite.insert_info(table='divorce', name='chat', data=message.chat.title, id_name='divorce_id',
                                   telegram_id=licensi)
                sqLite.insert_info(table='divorce', name='man', data=str(data[2]), id_name='divorce_id',
                                   telegram_id=licensi)
                sqLite.insert_info(table='divorce', name='woman', data=str(data[3]), id_name='divorce_id',
                                   telegram_id=licensi)
                await message.answer(text=send_main_text(name=message.from_user.first_name,
                                                         woman=str(data[3]).split('#№%')[0],
                                                         man=str(data[2]).split('#№%')[0]),
                                     reply_markup=divorce_start_kb(licensi, tg_id_main))


# Заполняем поля
async def in_divorce(call: types.CallbackQuery):
    nick = call.from_user.first_name
    role = call.data.split('_')[1]
    licensi_n = call.data.split('_')[2]
    creator = call.data.split('_')[3]
    check = sqLite.read_values_by_name(table='divorce', id_name='divorce_id', data=licensi_n, name=role)[0]
    if check is None:
        data = sqLite.read_values_by_name(table='divorce', id_name='divorce_id', data=licensi_n)
        if f"{nick}#№%{call.from_user.id}" in str(data):
            await bot.answer_callback_query(call.id)
        else:
            sqLite.insert_info(table='divorce', name="registrator", data=f"{nick}#№%{call.from_user.id}",
                               id_name='divorce_id',
                               telegram_id=licensi_n)
            data = sqLite.read_values_by_name(table='divorce', id_name='divorce_id', data=licensi_n)
            first_name = sqLite.read_values_by_name(table='all_users', data=int(creator))[10]
            person = lambda x: " " if str(x) == 'None' else str(x)
            man = person(str(data[2]).split("#№%")[0])
            woman = person(str(data[3]).split("#№%")[0])
            wietnes = person(str(data[4]))
            registr = person(str(data[5]).split("#№%")[0])
            await call.message.edit_text(text=send_main_text(name=first_name,
                                                             man=man,
                                                             woman=woman,
                                                             wietnes=wietnes,
                                                             registr=registr),
                                         reply_markup=divorce_start_kb(licensi_n, creator))
    else:
        await bot.answer_callback_query(call.id)


# Заполняем поля за присяжных
async def in_wietnes_divorce(call: types.CallbackQuery):
    nick = call.from_user.first_name
    licensi_n = call.data.split('_')[2]
    creator = call.data.split('_')[3]

    data = sqLite.read_values_by_name(table='divorce', id_name='divorce_id', data=licensi_n)
    if f"{nick}" in str(data):
        await bot.answer_callback_query(call.id)
    else:
        if str(data[4]) == 'None':
            sqLite.insert_info(table='divorce', name='wietnes', data=f"{nick}", id_name='divorce_id',
                               telegram_id=licensi_n)
        else:
            sqLite.insert_info(table='divorce', name='wietnes', data=f"{data[4]}, {nick}", id_name='divorce_id',
                               telegram_id=licensi_n)
        data = sqLite.read_values_by_name(table='divorce', id_name='divorce_id', data=licensi_n)
        first_name = sqLite.read_values_by_name(table='all_users', data=int(creator))[10]
        person = lambda x: " " if str(x) == 'None' else str(x)
        man = person(str(data[2]).split("#№%")[0])
        woman = person(str(data[3]).split("#№%")[0])
        wietnes = person(str(data[4]))
        registr = person(str(data[5]).split("#№%")[0])
        await call.message.edit_text(text=send_main_text(name=first_name,
                                                         man=man,
                                                         woman=woman,
                                                         wietnes=wietnes,
                                                         registr=registr),
                                     reply_markup=divorce_start_kb(licensi_n, creator))


# Жених и невеста ставят подписи
async def sing_divorce(call: types.CallbackQuery):
    nick = call.from_user.first_name
    licensi_n = call.data.split('_')[2]
    creator = call.data.split('_')[3]
    wedding_data = sqLite.read_values_by_name(table='divorce', id_name='divorce_id', data=licensi_n)
    if f"{nick}#№%{call.from_user.id}" == str(wedding_data[2]):
        sqLite.insert_info(table='divorce', name='man', data=f"✅{wedding_data[2]}", id_name='divorce_id',
                           telegram_id=licensi_n)
        sqLite.insert_info(table='divorce', name='woman', data=f"✅{wedding_data[3]}", id_name='divorce_id',
                           telegram_id=licensi_n)
        data = sqLite.read_values_by_name(table='divorce', id_name='divorce_id', data=licensi_n)
        first_name = sqLite.read_values_by_name(table='all_users', data=int(creator))[10]
        person = lambda x: " " if str(x) == 'None' else str(x)
        man = person(str(data[2]).split("#№%")[0])
        woman = person(str(data[3]).split("#№%")[0])
        wietnes = person(str(data[4]))
        registr = person(str(data[5]).split("#№%")[0])
        await call.message.edit_text(text=send_main_text(name=first_name,
                                                         man=man,
                                                         woman=woman,
                                                         wietnes=wietnes,
                                                         registr=registr),
                                     reply_markup=divorce_start_kb(licensi_n, creator))
    elif f"{nick}#№%{call.from_user.id}" == str(wedding_data[3]):
        sqLite.insert_info(table='divorce', name="woman", data=f"✅{nick}#№%{call.from_user.id}", id_name='divorce_id',
                           telegram_id=licensi_n)
        data = sqLite.read_values_by_name(table='divorce', id_name='divorce_id', data=licensi_n)
        first_name = sqLite.read_values_by_name(table='all_users', data=int(creator))[10]
        person = lambda x: " " if str(x) == 'None' else str(x)
        man = person(str(data[2]).split("#№%")[0])
        woman = person(str(data[3]).split("#№%")[0])
        wietnes = person(str(data[4]))
        registr = person(str(data[5]).split("#№%")[0])
        await call.message.edit_text(text=send_main_text(name=first_name,
                                                         man=man,
                                                         woman=woman,
                                                         wietnes=wietnes,
                                                         registr=registr),
                                     reply_markup=divorce_start_kb(licensi_n, creator))
    else:
        await bot.answer_callback_query(call.id)


# Разводим
async def registr_divorce(call: types.CallbackQuery):
    await bot.answer_callback_query(call.id)
    licensi_n = call.data.split('_')[2]
    wedding_data = sqLite.read_values_by_name(table='divorce', id_name='divorce_id', data=licensi_n)
    if f"✅" in str(wedding_data[2]) and f"✅" in str(wedding_data[3]):
        proces = True
        for k in wedding_data:
            if k is None:
                proces = False
            else:
                pass
        check_guests = str(wedding_data[4]).split(', ')
        if len(check_guests) < 2:
            pass
        else:
            if proces:
                # удаляем брак
                data_w = sqLite.read_values_by_name(table='weddings', id_name='wedding_id', data=licensi_n)[0]
                sqLite.delete_str(table='weddings', name='id', data=int(data_w))
                # Сохраняем дату
                sqLite.insert_info(table='divorce', name="data_d",
                                   data=str(datetime.datetime.now()).split('.')[0],
                                   id_name='divorce_id',
                                   telegram_id=licensi_n)
                data = sqLite.read_values_by_name(table='divorce', id_name='divorce_id', data=licensi_n)
                man_id = str(data[2]).split("#№%")[1]
                woman_id = str(data[3]).split("#№%")[1]

                man = str(data[2]).split("#№%")[0]
                woman = str(data[3]).split("#№%")[0]
                # Удаляем супругов
                sqLite.insert_info(table='all_users', name="hasben",
                                   data='0',
                                   telegram_id=man_id)
                sqLite.insert_info(table='all_users', name="hasben",
                                   data='0',
                                   telegram_id=woman_id)

                # Сохраняем обновляем имена в свидетельстве
                sqLite.insert_info(table='divorce', name="man",
                                   data=man[1:],
                                   id_name='divorce_id',
                                   telegram_id=licensi_n)
                sqLite.insert_info(table='divorce', name="woman",
                                   data=woman[1:],
                                   id_name='divorce_id',
                                   telegram_id=licensi_n)
                registr = str(data[5]).split("#№%")[0]
                wietnes = str(data[4])
                await call.message.edit_text(text=f'Хорошую вещь браком не назовут с уважением администрация @ByOw1Bot конец\n\n'
                                                  f'{random_text()}')
                await call.message.answer(text=f'{man[1:]} и {woman[1:]}\n'
                                               f'расторгли брак в чате {str(data[1])}\n'
                                               f'Судья: {registr}\n'
                                               f'Присяжные: {wietnes}\n'
                                               f'Дата: {str(data[6])}\n'
                                               f'Код: {licensi_n}')
    else:
        await bot.answer_callback_query(call.id)


# Парсим все колбэки
async def call_divorce(call: types.CallbackQuery):
    data = call.data
    chat_id = call.message.chat.id
    if data.startswith('divorce_wietnes_'):
        await in_wietnes_divorce(call)
    elif data.startswith('divorce_registrator_'):
        await in_divorce(call)
    elif data.startswith('divorce_sing_'):
        await sing_divorce(call)
    elif data.startswith('divorce_start_'):
        await registr_divorce(call)
    elif data.startswith('divorce_cancel_'):
        if call.from_user.id == int(data.split('_')[3]):

            licensi_w = str(data.split('_')[2])
            wedding_data = str(sqLite.read_values_by_name(table='weddings', id_name='wedding_id', data=licensi_w)[10])
            check_brack = sqLite.read_values_by_name(table='all_users', data=call.from_user.id)
            if 'vip' in wedding_data:
                sqLite.ins_log(tg_id=str(call.from_user.id), info=f'Отмена VIP развод', money=f"+1",
                               chanel_id=chat_id)
                sqLite.insert_info(table='all_users', name="license_vip", data=(int(check_brack[14]) + 1),
                                   telegram_id=call.from_user.id)
            else:
                sqLite.ins_log(tg_id=str(call.from_user.id), info=f'Отмена развод', money=f"+1",
                               chanel_id=chat_id)
                sqLite.insert_info(table='all_users', name="license", data=(int(check_brack[11]) + 1),
                                   telegram_id=call.from_user.id)

            data = sqLite.read_values_by_name(table='divorce', id_name='divorce_id', data=str(data.split('_')[2]))[0]
            sqLite.delete_str(table='divorce', name='id', data=int(data))
            await call.message.edit_text("Развод отменен")
        else:
            await bot.answer_callback_query(call.id)



