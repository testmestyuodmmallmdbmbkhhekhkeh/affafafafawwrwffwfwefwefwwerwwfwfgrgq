from aiogram import types
from main import dp
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters import Text
from modules import sqLite
from modules.handlers.casino.sertificat import send_weding_sertificat
from modules.dispatcher import Donations, Market
from modules.keyboards import main_kb
import datetime


def get_all_status(user: tuple):
    now = datetime.datetime.now()
    get_time = lambda str_time: datetime.datetime.strptime(str(str_time), "%Y-%m-%d %H:%M:%S") + \
                                datetime.timedelta(days=30)
    status = 'Status: '
    # дневной статус
    if user[20] == 0:
        pass
    else:
        if get_time(str(user[20])) > now:
            status = status + '[🌝] Дневной '
    # Ночной статус
    if user[21] == 0:
        pass
    else:
        if get_time(str(user[21])) > now:
            status = status + '[🌚] Ночной '
    # Королевский статус
    if user[22] == 0:
        pass
    else:
        if get_time(user[22]) > now:
            status = status + '[👑] Королевский '
    # Фирменный статус
    if user[23] == 0:
        pass
    else:
        if get_time(user[23]) > now:
            status = status + '[🦉] Фирменный '
    # Декоративный статус
    if user[24] == 0:
        pass
    else:
        if get_time(user[24]) > now:
            status = status + '[🎩] Декоративный '
    # Текстовый статус
    if user[25] == '0':
        pass
    else:
        status = status + user[25]
    if status != 'Status: ':
        status = status + '\n'
    else:
        status = ''
    return status


# Собираем титулы
def get_all_tituls(user: tuple):
    titul = ''
    # Битва Чатов
    if user[26] == 0:
        pass
    else:
        postfix = user[26]
        if postfix == 1:
            titul = titul + 'Битва Чатов 🏆\n'
        else:
            titul = titul + f'Битва Чатов 🏆x{postfix}\n'
    # Турнир «Новички»
    if user[27] == 0:
        pass
    else:
        postfix = user[27]
        if postfix == 1:
            titul = titul + 'Турнир «Новички» 🏆\n'
        else:
            titul = titul + f'Турнир «Новички» 🏆x{postfix}\n'
    # Турнир «Новички»
    if user[28] == 0:
        pass
    else:
        postfix = user[28]
        if postfix == 1:
            titul = titul + 'Турнир «Продвинутые» 🏆\n'
        else:
            titul = titul + f'Турнир «Продвинутые» 🏆x{postfix}\n'
    # Турнир «Профи» 🏆
    if user[29] == 0:
        pass
    else:
        postfix = user[29]
        if postfix == 1:
            titul = titul + 'Турнир «Профи» 🏆\n'
        else:
            titul = titul + f'Турнир «Профи» 🏆x{postfix}\n'

    # Конкурс «Пара Месяца» 🏆
    if user[30] == 0:
        pass
    else:
        postfix = user[30]
        if postfix == 1:
            titul = titul + 'Конкурс «Пара Месяца» 🏆\n'
        else:
            titul = titul + f'Конкурс «Пара Месяца» 🏆x{postfix}\n'

    if titul != '':
        titul = '\n' + titul
    return titul


def profile_text(message: types.Message):
    user_d = sqLite.read_values_by_name(table='all_users', data=message.from_user.id)
    name = message.from_user.first_name
    money = int(user_d[2])
    income = user_d[3]
    outcome = user_d[4]
    max_incom = user_d[5]
    max_deal = user_d[6]
    license_n = int(user_d[11])
    license_VIP = int(user_d[14])
    hasben = str(user_d[13])
    status = get_all_status(user_d)
    tituls = get_all_tituls(user_d)
    if hasben == '0':
        hasben = ''
    else:
        hasben = f"Жена: {hasben}\n"
    kids = str(user_d[15])
    if kids == '0':
        kids = ''
    else:
        kids = f"Дети: {kids}\n"
    license = str(user_d[12])
    if license == '0':
        license = ''
    else:
        license = f"Вот ваши брачные сертификаты: {license}\n"
    text = f'{name}\n{hasben}{kids}' \
           f'{status}'\
           f'Монеты: {money}\n' \
           f'Выиграно: {income}\n' \
           f'Проиграно: {outcome}\n' \
           f'Макс. выигрыш: {max_incom}\n' \
           f'Макс. ставка: {max_deal}\n' \
           f'Кол-во лицензий: {license_n}\n' \
           f'Кол-во VipOwl: {license_VIP}\n{license}{tituls}'
    return text


text_links = '🔥Уважаемые игроки, добро пожаловать в бот @ByOw1Bot\n' \
             '🆕Все самые свежие новости и обновления бота   @ByOWLBroadcastingCorporation\n\n\n' \
             'Основные игровые чаты для Вас:\n\n' \
             '1. 😌𝐍𝐈𝐑𝐕𝐀𝐍𝐀🍀 - @Nirvana_ByOWL - чат для игроков, желающих поиграть в спокойной обстановке, соблюдая общие правила. \n' \
             '2.🔥𝐀𝐍𝐀𝐑𝐂𝐇𝐘🔥 - @Anarchy_ByOWL - чат для анархистов не желающих подчиняться правилам\n' \
             '3. 🤪𝐏𝐀𝐋𝐀𝐓𝐀 №9🏥 - @Palata9_ByOWL - чат для токсичных любителей срачей, для гиперактивных игроков🤪\n' \
             '4. 🌍𝐒𝐍𝐆🔥 - @SNG_ByOWL - чат для игроков всех стран, здесь Вы можете пообщаться на своём родном языке, найти новых друзей и стать частью многонациональной семьи \n' \
             '5.🏆𝐀𝐑𝐄𝐍𝐀🏆 - @ARENA_ByOWL - чат для турниров  и супертурниров с регламентом участия и призовым фондом\n' \
             '6. 👑𝐁𝐄𝐋𝐋𝐀𝐆𝐈𝐎 𝐂𝐀𝐒𝐈𝐍𝐎🎩 - \n' \
             'https://t.me/joinchat/n_zm6cOos8Y1Mzgy. - чат для пузатеньких богатеев, с взносом для входа и с возможностью депозита\n' \
             '7.  💒𝐑𝐎𝐘𝐀𝐋 𝐏𝐀𝐑𝐓𝐘👰‍♀️🤵‍♂️ - \n' \
             '@RoyalParty_ByOWL - чат для проведения свадеб, разводов, создания семьи с функцией "дети", а так же "доска объявлений для одиноких сердец"\n' \
             '8. 🖋𝐖𝐎𝐑𝐃𝐒 𝐎𝐅 𝐖𝐎𝐑𝐋𝐃🌍 - \n' \
             '@WordsOfWorld_ByOWL - чат для игры в Буквы. Создавай слова из букв! Победит умнейший! \n' \
             '9. 🔥𝐖𝐈𝐋𝐃 𝐖𝐄𝐒𝐓🏜 - \n' \
             '@WildWest_ByOWL - чат где можно сразиться на Дуэли, испытать судьбу и удачу\n' \
             '10. 🌃𝐍𝐈𝐆𝐇𝐓 𝐋𝐈𝐅𝐄🌑 - @NightLife_ByOWL - чат для тех, кому не спится, болтаем играя в Крестики Нолики'


# Profile menu
@dp.message_handler(Text(equals='📋профиль', ignore_case=True), state='*')
async def user_profile(message: types.Message):
    await message.answer(text=profile_text(message), parse_mode='html', reply_markup=main_kb)
    await Donations.first_menu.set()


# Profile menu
@dp.message_handler(Text(equals='профиль', ignore_case=True), state='*')
async def user_profile(message: types.Message):
    await message.answer(text=profile_text(message), parse_mode='html')
    await Donations.first_menu.set()


# Profile menu
@dp.message_handler(Text(equals='б', ignore_case=True), state='*')
@dp.message_handler(Text(equals='Б', ignore_case=True), state='*')
@dp.message_handler(Text(equals='Баланс', ignore_case=True), state='*')
async def start_menu(message: types.Message):
    user_d = sqLite.read_values_by_name(table='all_users', data=message.from_user.id)
    name = message.from_user.first_name
    money = user_d[2]
    await message.answer(text=f'{money}')


# Profile menu
@dp.message_handler(Text(equals='🌐ссылки', ignore_case=True), state='*')
async def start_menu(message: types.Message):
    await message.answer(text=text_links, parse_mode='html', reply_markup=main_kb)


# Profile menu
@dp.message_handler(Text(equals='cсылки', ignore_case=True), state='*')
@dp.message_handler(Text(equals='Ссылки', ignore_case=True), state='*')
async def start_menu(message: types.Message):
    await message.answer(text=text_links, parse_mode='html')


# Profile menu
@dp.message_handler(Text(equals='!Помощь основные', ignore_case=True), state='*')
async def start_menu(message: types.Message):
    await message.answer(text=f'<b>Основные команды</b>\n'
                              f'<code>Профиль</code> - Просмотр личного профиля.\n'
                              f'<code>История</code> - просмотр последних изменений баланса Вашего лицевого счёта.\n'
                              f'<code>Баланс/Б</code> - Проверка баланса Вашего лицевого счета.\n'
                              f'<code>+(n)</code> (в ответ на сообщение) - Передать (n) монет другому пользователю.\n'
                              f'<code>-(n)</code> (в ответ на сообщение) - Попытаться украсть (n) монет у другого пользователя.\n'
                              f'<code>!Ссылки</code> - Просмотр списка официальных игровых чатов.\n'
                              f'<code>!(Титул)</code> дня (1 раз в час) - Выбирает случайного пользователя из списка участников чата и назначает ему (Титул) который вы придумали на день, обновляется каждые 24 часа в 00:00 по Московскому времени.\n'
                              f'<code>Титулы</code> - просмотр титулов дня данного чата(обновляется каждые 24 часа).\n'
                              f'<code>!!мут</code> (в ответ на сообщение) - Запрещает писать пользователю в чате где была использована команда на 1 минуту за 200 монет.\n'
                              f'<code>бот игнор</code> (в ответ на сообщение) - Запрешает пользователю на сообщение которого вы ответили отвечать на ваши сообщения. Повторное использование команды на того же пользователя снимает ограничение.',
                         parse_mode='html', reply_markup=main_kb)


# Помощь основные
@dp.message_handler(Text(equals='!Помощь рулетка', ignore_case=True), state='*')
async def start_menu(message: types.Message):
    await message.answer(text=f'<b>Рулетка</b>\n'
                              f'<code>Рулетка</code> - Запуск мини-игры в рулетку.\n'
                              f'<b>Для ставок используйте следующие команды:</b>\n'
                              f'<code>(n) на красное/(n) на к/(n) к</code> - Поставить (n) монет на красное.\n'
                              f'<code>(n) на черное/(n) на ч/(n) ч</code> - Поставить (n) монет на черное.\n'
                              f'<code>(n) на 0</code> - Поставить (n) монет на зеро/0.\n'
                              f'<code>(n) на 0-12/(n) 0-12</code> - Поставить (n) монет на диапазон чисел от 0 до 12(выбираете любой угодный вам диапазон от 0 до 12 включительно).\n'
                              f'<code>(n) на 1</code> - Поставить (n) монет на число 1(выбираете любое число от 1 до 12).\n'
                              f'<code>Отмена</code> - Отменяет все сделанные Вами ставки.\n'
                              f'<code>Ставки</code> - Показывает все сделаные Вами в этом раунде ставки.\n'
                              f'<code>Удвоить</code> - Удваивает каждую Вашу ставку на 100%.\n'
                              f'<code>Повторить</code> - Повторяет последнюю вашу ставку.',
                         parse_mode='html', reply_markup=main_kb)


# Помощь розыгрыш
@dp.message_handler(Text(equals='!Помощь розыгрыш', ignore_case=True), state='*')
async def start_menu(message: types.Message):
    await message.answer(text=f'<b>Розыгрыши</b>\n'
                              f'<code>!розыгрыш (n)</code> - Открывает набор участников для розыгрыша (n) монет(от 1 до 25000).',
                         parse_mode='html', reply_markup=main_kb)


# Помощь свадьбы
@dp.message_handler(Text(equals='!Помощь свадьбы', ignore_case=True), state='*')
async def start_menu(message: types.Message):
    await message.answer(text=f'<b>Свадьбы</b>\n'
                              f'<code>!Свадьба</code> - Открывает подготовку к свадебной церемонии.\n'
                              f'<code>!Свадьба vip</code> - Открывает подготовку к свадебной VIP церемонии.\n'
                              f'<code>!Развод</code> - Открывает подготовку к разводу.\n'
                              f'<code>!Развод vip</code> - Открывает подготовку к VIP разводу.\n'
                              f'<code>Свидетельство</code> - Просмотр Вашего свидетельства.\n'
                              f'<code>Свидетельство (код выданный при браке)</code> - Просмотр свидетельства другой пары.',
                         parse_mode='html', reply_markup=main_kb)


# Помощь рейтинг
@dp.message_handler(Text(equals='!Помощь рейтинг', ignore_case=True), state='*')
async def start_menu(message: types.Message):
    await message.answer(text=f'<b>Рейтинги</b>\n'
                              f'<code>!Топ</code> - Просмотр рейтинга чата по количеству монет.\n'
                              f'<code>Рекорды рулетки дня</code> - Просмотр рекордов рулетки за сегодняшнний день.\n'
                              f'<code>Топ ставки</code> - Топ по сумме ставок в рулетке.\n'
                              f'<code>Топ выиграно</code> - Топ по сумме выиграных монет в рулетке.\n'
                              f'<code>Топ проиграно</code> - Топ по сумме проиграных монет в рулетке.\n'
                              f'<code>Топ выигрышей</code> - Топ максимальных выигрышей монет в рулетке за одну прокрутку.\n'
                              f'<code>!топ буквы</code> -  топ очков за всё время\n'
                              f'<code>!топ слово</code> - топ самых длинных использованных слов\n',
                         parse_mode='html', reply_markup=main_kb)


# Помощь дуэль
@dp.message_handler(Text(equals='!Помощь дуэль', ignore_case=True), state='*')
async def start_menu(message: types.Message):
    await message.answer(text=f'Дуэль - запуск мини-игры буквы со ставкой 500 монет.'
                              f'!дуэль (n) - запуск мини-игры с желаемой(n) ставкой.'
                              f'!дуэль (n) с реплаем любого игрока - вызвать на дуэль.',
                         parse_mode='html', reply_markup=main_kb)

# Помощь буквы
@dp.message_handler(Text(equals='!Помощь буквы', ignore_case=True), state='*')
async def start_menu(message: types.Message):
    await message.answer(text=f'Буквы - запуск мини-игры буквы со ставкой 500 монет.'
                              f'!буквы (n) - запуск мини-игры с желаемой(n) ставкой.'
                              f'!буквы (n) с реплаем любого игрока - вызвать на дуэль.'
                              f'!сдаться - отдать победу сопернику.',
                         parse_mode='html', reply_markup=main_kb)


# Помощь крестики нолики
@dp.message_handler(Text(equals='!Помощь крестики', ignore_case=True), state='*')
async def start_menu(message: types.Message):
    await message.answer(text=f'Крестики - запуск мини-игры крестики-нолики со ставкой 500 монет.'
                              f'!крестики (n) - запуск мини-игры с желаемой(n) ставкой.'
                              f'!крестики (n) с реплаем любого игрока - вызвать на дуэль.',
                         parse_mode='html', reply_markup=main_kb)


# свидетельство
@dp.message_handler(Text(equals='свидетельство', ignore_case=True), state='*')
async def start_menu(message: types.Message):
    await send_weding_sertificat(message)


# Снятие лимитов в группе
@dp.message_handler(state=Market.roll_limits)
async def start_menu(message: types.Message, state: FSMContext):
    if '-' in message.text:
        if str(message.text[1:]).isdigit():
            chat_data = sqLite.read_values_by_name(table=f'chats', data=message.text, id_name='chat_id')
            if chat_data is None:
                await message.answer('Такой группы не существует')
            elif str(chat_data[2]) == '0':
                await message.answer('Вы приобрели снятие ограничения на рулетку')
            else:
                user_data = sqLite.read_values_by_name(table=f'all_users', data=message.from_user.id)
                sqLite.ins_log(tg_id=str(message.from_user.id), info=f'снятие ограничений на рулетку {message.text}',
                               money="-2000000", chanel_id=str(message.from_user.id))
                sqLite.insert_info(table=f'all_users', name='money', data=user_data[2] - 2000000,
                                   telegram_id=message.from_user.id)
                sqLite.insert_info(table=f'chats', name='limits_rol', data='0', telegram_id=message.text,
                                   id_name='chat_id')
                await message.answer(text='Вы приобрели снятие ограничения на рулетку',
                                     parse_mode='html', reply_markup=main_kb)
                await state.finish()
        else:
            await message.answer('Неправильное ID группы')
    else:
        await message.answer('Неправильное ID группы')


# Снятие лимитов в группе
@dp.message_handler(state=Market.roll_limits_pay)
async def start_menu(message: types.Message, state: FSMContext):
    if '-' in message.text:
        if str(message.text[1:]).isdigit():
            chat_data = sqLite.read_values_by_name(table=f'chats', data=message.text, id_name='chat_id')
            if chat_data is None:
                await message.answer('Такой группы не существует')
            elif str(chat_data[2]) == '0':
                await message.answer('Вы приобрели снятие ограничения на рулетку')
            else:
                sqLite.ins_log(tg_id=str(message.from_user.id), info=f'Снимаем лимиты в рулетке {message.text}',
                               money="-599 RUR", chanel_id=str(message.from_user.id))
                sqLite.insert_info(table=f'chats', name='limits_rol', data='0', telegram_id=message.text,
                                   id_name='chat_id')
                await message.answer(text='Вы приобрели снятие ограничения на рулетку',
                                     parse_mode='html', reply_markup=main_kb)
                await state.finish()
        else:
            await message.answer('Неправильное ID группы')
    else:
        await message.answer('Неправильное ID группы')


# Команда id
@dp.message_handler(commands=['id'], state='*')
async def start_menu(message: types.Message):
    if not message.reply_to_message:
        await message.answer(text=f'{message.chat.id}')
    else:
        await message.answer(text=f'{message.reply_to_message.from_user.id}')
