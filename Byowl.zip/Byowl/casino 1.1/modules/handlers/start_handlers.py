from aiogram import types
from main import dp
from modules.dispatcher import bot
from aiogram.dispatcher.filters import Text
import logging
from modules import sqLite
from modules.dispatcher import Donations
from aiogram.dispatcher import FSMContext
from modules.keyboards import *


# Check ban user
@dp.message_handler(is_ban_user=True, state='*')
async def ban_user_skip(message: types.Message):
    pass


# Check ban chat
@dp.message_handler(is_chat_ban=True, state='*')
async def ban_chat_skip(message: types.Message):
    pass


# Check ignor user
@dp.message_handler(is_ignor=True, state='*')
async def ban_chat_skip(message: types.Message):
    chat_id = message.chat.id
    await bot.delete_message(chat_id=chat_id, message_id=message.message_id)
#
#
# # Загрузка медиа
# @dp.message_handler(content_types=types.ContentType.ANIMATION, state='*')
# async def ban_chat_skip(message: types.Message):
#     chat_id = message.chat.id
#     anime_id = message.animation.file_id
#     await bot.send_message(chat_id=chat_id, text=anime_id)


# Start menu
@dp.message_handler(commands=['start'], state='*')
async def start_menu(message: types.Message):
    sqLite.insert_first_note(table='all_users', telegram_id=message.from_user.id)
    sqLite.insert_info(table=f'all_users', name='nickname', data=message.from_user.first_name,
                       telegram_id=message.from_user.id)
    sqLite.new_user_log_table(str(message.from_user.id))
    await message.answer(text='Добро пожаловать в  @ByOw1Bot. \n'
                              'Начав игру в боте, вы даёте своё согласие с данными правилами. \n'
                              'Администрация бота не несёт ответственности за какие-либо происшествия, связанные с '
                              'взаимоотношениями игроков.\n'
                              'Наш бот включает в себя только развлекательную функцию для чатов в Telegram, все '
                              'выигрыши являются символическими.\n'
                              'Следите за новостями @ByOWLBroadcastingCorporation', parse_mode='html',
                         reply_markup=main_kb)


@dp.callback_query_handler(text='back', state=Donations.first_menu)
async def start_menu(call: types.CallbackQuery):
    await call.message.answer(text='Добро пожаловать в  @ByOw1Bot. \n'
                                   'Начав игру в боте, вы даёте своё согласие с данными правилами. \n'
                                   'Администрация бота не несёт ответственности за какие-либо происшествия, '
                                   'связанные с взаимоотношениями игроков.\n'
                                   'Наш бот включает в себя только развлекательную функцию для чатов в Telegram, все '
                                   'выигрыши являются символическими.\n'
                                   'Следите за новостями @ByOWLBroadcastingCorporation', parse_mode='html',
                              reply_markup=main_kb)


# Help menu
@dp.message_handler(Text(equals='🆘помощь', ignore_case=True), state='*')
@dp.message_handler(commands=['help'], state='*')
async def start_menu(message: types.Message):
    await message.answer(text='<b>help</b>\n'
                              '<code>!Помощь основные</code> - Открывает список основных команд бота.\n'
                              '<code>!Помощь рулетка</code> - Открывает список команд по игре в рулетку.\n'
                              '<code>!Помощь розыгрыш</code> - Открывает список команд по розыгрышам.\n'
                              '<code>!помощь свадьбы</code> - Открывает список команд для свадеб и разводов.\n'
                              '<code>!Помощь рейтинг</code> - Выводит список команд для проверки рейтингов.\n'
                              '<code>!Помощь буквы</code> - Выводит список команд по буквам.\n'
                              '<code>!Помощь дуэль</code> - Выводит список команд по дуэлям.\n'
                              '<code>!Помощь крестики</code> - Выводит список команд по крестикам.\n'
                         , parse_mode='html',
                         reply_markup=main_kb)


# Cancel all process
@dp.message_handler(state='*', commands=['cancel'])
@dp.message_handler(Text(equals='cancel', ignore_case=True), state='*')
async def cancel_handler(message: types.Message, state: FSMContext):
    current_state = await state.get_state()
    await message.reply('Процесс отменен. Все данные стерты. Что бы начать все с начала нажми /start',
                        reply_markup=types.ReplyKeyboardRemove())
    if current_state is None:
        return
    logging.info('Cancelling state %r', current_state)
    # Cancel state and inform user about it
    await state.finish()
