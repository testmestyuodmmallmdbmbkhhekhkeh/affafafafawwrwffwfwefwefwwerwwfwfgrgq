from aiogram import types
from main import dp
from modules import sqLite
from modules.dispatcher import bot, token
from aiogram.dispatcher.filters import Text
from modules.dispatcher import Donations
from aiogram.types.message import ContentTypes
from modules.keyboards import donations_kb, market_kb, main_kb, pay_sber_kb
from modules.handlers.casino.read_and_save_data import save_after_pay
from pyqiwip2p import Qiwip2p


# Help menu
@dp.message_handler(Text(equals='🔙 назад', ignore_case=True), state=Donations.first_menu)
@dp.message_handler(Text(equals='💳донат', ignore_case=True), state='*')
async def start_menu(message: types.Message):
    await message.answer(text='Монеты 💰\n'
                              '100.000 - 99₽\n'
                              '500.000 - 399₽\n'
                              '1.000.000 - 699₽\n'
                              '5.000.000 - 3399₽\n'
                              '10.000.000 - 5999₽\n'
                              '——————————————————\n'
                              '💎Статусы💎\n'
                              '[🌝] Дневной - 50.000 монет в день - 499₽\n'
                              '[🌚] Ночной - 200.000 монет в день - 1999₽\n'
                              '[👑] Королевский - 500.000 монет в день - 4999₽\n'
                              '[🦉] Фирменный - 1.000.000 монет в день - 9999₽\n'
                              '[🎩] Декоративный статус без монет - 679₽\n'
                              '——————————————————\n'
                              'Лимиты🔓\n'
                              '[🔐]Снятие лимита рулетки в группе - 599₽\n'
                              '[🤴❤️👸] VipOwl - красочная свадьба, одинокий развод - 299₽\n'
                              '——————————————————\n\n<b>❗️ВНИМАНИЕ❗️ '
                              'СОВЕРШАЯ ДОНАТ, ПОЛЬЗОВАТЕЛЬ ДОЛЖЕН ЗНАТЬ, ЧТО ЕГО '
                              'ДЕНЕЖНЫЕ СРЕДСТВА ЯВЛЯЮТСЯ НЕВОЗВРАТНЫМИ.'
                              'ЗАРАБОТАТЬ РЕАЛЬНЫЕ ДЕНЬГИ В ИГРЕ НЕВОЗМОЖНО.'
                              '</b>\n\nПо поводу ваших претензий, вопросов , просьб, пожеланий, вы  '
                              'можете обратиться к:'
                              '@Technical_Support_ByOWL', parse_mode='html', reply_markup=donations_kb)
    await Donations.first_menu.set()


@dp.callback_query_handler(state=Donations.first_menu, text='sber_pay')
async def pay_sber(call: types.CallbackQuery):
    await call.message.answer("Выберите платеж.", reply_markup=pay_sber_kb)
    await Donations.second_menu.set()


@dp.callback_query_handler(state=Donations.second_menu)
async def input_money(call: types.CallbackQuery):
    pay_token = token.sber_token()
    price = int(call.data[6:])*100
    try:
        await bot.send_invoice(chat_id=call.from_user.id, title='Оплата за пользование ботом',
                               currency='RUB',
                               description=f'Вы делаете покупку на {price/100} RUB в боте',
                               payload=f'pay_{price}',
                               provider_token=pay_token, start_parameter='bot_pay',
                               prices=[{"label": 'Руб', "amount": int(price)}])
    except:
        await call.message.answer('Ошибка платежной системы')


@dp.message_handler(state='*', content_types=ContentTypes.SUCCESSFUL_PAYMENT)
async def got_payment(message: types.Message):
    if message.successful_payment.invoice_payload.startswith('pay_'):
        await save_after_pay(message)
    else:
        print(message.successful_payment.invoice_payload)


@dp.pre_checkout_query_handler(state='*')
async def pre_check_query(pre_check: types.PreCheckoutQuery):
    await bot.answer_pre_checkout_query(pre_check.id, ok=True)


# Help for bad payments(bonus)
@dp.callback_query_handler(state=Donations.first_menu, text='get_bonus')
async def get_support_pay(call: types.CallbackQuery):
    user_id = call.from_user.id
    user_data = sqLite.read_values_by_name(table=f'all_users', data=user_id)
    if user_data[2] > 1000:
        await call.message.answer("У вас есть монеты", reply_markup=main_kb)
    else:
        sqLite.insert_info(table=f'all_users', name='money', data=user_data[2] + 5000,
                           telegram_id=user_id)
        await call.message.answer(f"Получено 5000 монет")
        sqLite.ins_log(tg_id=str(user_id),
                       info=f'начисление бонуса +5000',
                       money=f"+5000", chanel_id=call.from_user.id)


# Market
@dp.message_handler(Text(equals='магазин', ignore_case=True), state='*')
@dp.message_handler(Text(equals='🛒 магазин', ignore_case=True), state='*')
async def start_menu(message: types.Message):
    if message.chat.id == message.from_user.id:
        await message.answer(text='Вы в магазине\n'
                                  '📜Лицензия – 50к монет\n'
                                  '🔐Снятие лимита рулетки в группе - 2кк монет\n'
                                  '🚫Защита от !игнор - 1кк монет\n'
                                  '🚫🙊Защита от !!мут и !игнор - 2кк монет', parse_mode='html',
                             reply_markup=market_kb())
    else:
        pass
