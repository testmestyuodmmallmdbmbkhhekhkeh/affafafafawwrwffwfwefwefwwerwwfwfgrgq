from aiogram import types
from modules.dispatcher import bot
from main import dp
from modules.handlers.admins_handlers import _main_admin_pars, _admin_pars
from modules.handlers.func_for_all_handlers import all_handlers, all_cals
from modules.my_filters import check_main_admin, check_admin, is_bot_not_off
from modules.my_filters import check_main_admin_call, check_admin_call, is_bot_not_off_call


# Profile menu
@dp.message_handler(state='*')
async def all_handlers_check(message: types.Message):
    if await check_main_admin(message):
        await _main_admin_pars(message)
    elif await check_admin(message):
        await _admin_pars(message)
    elif await is_bot_not_off(message):
        await all_handlers(message)


# Profile menu
@dp.callback_query_handler(state='*')
async def start_menu(call: types.CallbackQuery):
    await bot.answer_callback_query(call.id)
    if await check_main_admin_call(call):
        await all_cals(call)
    elif await check_admin_call(call):
        await all_cals(call)
    elif await is_bot_not_off_call(call):
        await all_cals(call)
    else:
        pass
