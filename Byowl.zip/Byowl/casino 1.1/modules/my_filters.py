from aiogram import types
from modules import sqLite
from modules.keyboards import go_to_bot
from aiogram.dispatcher.filters import BoundFilter


class IsAdminFilter(BoundFilter):
    key = 'is_admin'

    def __init__(self, is_admin):
        self.is_admin = is_admin

    async def check(self, message: types.Message):
        user_id = message.from_user.id
        user_data = sqLite.read_values_by_name(table=f'all_users', data=user_id)[7]
        print(user_data)
        if str(user_data) == 'admin':
            return True
        else:
            return False


class IsMainAdminFilter(BoundFilter):
    key = 'is_main_admin'

    def __init__(self, is_main_admin):
        self.is_main_admin = is_main_admin

    async def check(self, message: types.Message):
        user_id = message.from_user.id
        user_data = sqLite.read_values_by_name(table=f'all_users', data=user_id)[7]
        print(user_data)
        if str(user_data) == 'mainAdmin':
            return True
        else:
            return False


class IsUserBanFilter(BoundFilter):
    key = 'is_ban_user'

    def __init__(self, is_ban_user):
        self.is_ban_user = is_ban_user

    async def check(self, message: types.Message):
        try:
            user_id = message.from_user.id
            user_data = sqLite.read_values_by_name(table=f'all_users', data=user_id)[7]
            if str(user_data) == 'ban':
                return True
            else:
                return False
        except:
            await message.answer(f'{message.from_user.first_name}, Вы были зарегистрированы в '
                                 f'<a href="@ByOw1Bot">@ByOw1Bot</a>, используя функции нашего проекта, '
                                 f'Вы подтверждаете своё согласие с пользовательским соглашением',
                                 reply_markup=go_to_bot(), parse_mode='html')
            sqLite.insert_first_note(table='all_users', telegram_id=message.from_user.id)
            sqLite.insert_info(table=f'all_users', name='nickname', data=message.from_user.first_name,
                               telegram_id=message.from_user.id)
            sqLite.new_user_log_table(str(message.from_user.id))
            return False


class IsIgnorFilter(BoundFilter):
    key = 'is_ignor'

    def __init__(self, is_ignor):
        self.is_ignor = is_ignor

    async def check(self, message: types.Message):
        if message.reply_to_message:
            user_id = message.reply_to_message.from_user.id
            victem_id = message.from_user.id
            ignor_data = sqLite.read_value_2_(user_tg_id=user_id, ignor_tg_id=victem_id)
            if str(ignor_data) == '[]':
                return False
            else:
                return True
        else:
            return False


# Забанина ли группа
class IsChatBanFilter(BoundFilter):
    key = 'is_chat_ban'

    def __init__(self, is_chat_ban):
        self.is_chat_ban = is_chat_ban

    async def check(self, message: types.Message):
        user_id = message.from_user.id
        user_data = sqLite.read_values_by_name(table=f'all_users', data=user_id)[7]
        chat_id = message.chat.id
        if message.chat.id == message.from_user.id:
            return False
        elif 'dmin' in user_data:
            sqLite.new_table_chat(str(chat_id)[1:])
            sqLite.insert_first_note(table=f'chat{str(chat_id)[1:]}', id_name='tg_id', telegram_id=message.from_user.id)
            sqLite.insert_info(table=f'chat{str(chat_id)[1:]}', name='nick', data=message.from_user.first_name,
                               id_name='tg_id', telegram_id=message.from_user.id)
            chat_data = sqLite.read_values_by_name(table=f'chats', data=str(chat_id), id_name='chat_id')
            if chat_data is None:
                sqLite.insert_first_note(table=f'chats', telegram_id=str(chat_id), id_name='chat_id')
            return False
        else:
            # создаем таблицу чата
            sqLite.new_table_chat(str(chat_id)[1:])
            sqLite.insert_first_note(table=f'chat{str(chat_id)[1:]}', id_name='tg_id', telegram_id=message.from_user.id)
            sqLite.insert_info(table=f'chat{str(chat_id)[1:]}', name='nick', data=message.from_user.first_name,
                               id_name='tg_id', telegram_id=message.from_user.id)

            chat_data = sqLite.read_values_by_name(table=f'chats', data=str(chat_id), id_name='chat_id')
            if chat_data is None:
                sqLite.insert_first_note(table=f'chats', telegram_id=str(chat_id), id_name='chat_id')
            else:
                if str(chat_data[3]) == 'ban':
                    return True
                else:
                    return False


# Отключен ли бот для пользователей
async def is_bot_not_off(message: types.Message):
    if message.chat.id == message.from_user.id:
        return False
    else:
        chat_id = message.chat.id
        chat_data = sqLite.read_values_by_name(table=f'chats', data=str(chat_id), id_name='chat_id')
        if str(chat_data[7]) == '0':
            return True
        else:
            return False


async def check_main_admin(message: types.Message):
    user_id = message.from_user.id
    user_data = sqLite.read_values_by_name(table=f'all_users', data=user_id)[7]
    if str(user_data) == 'mainAdmin':
        return True
    else:
        return False


async def check_admin(message: types.Message):
    user_id = message.from_user.id
    user_data = sqLite.read_values_by_name(table=f'all_users', data=user_id)[7]
    if str(user_data) == 'admin':
        return True
    else:
        return False


# Отключен ли бот для пользователей
async def is_bot_not_off_call(call: types.CallbackQuery):
    if call.message.chat.id == call.from_user.id:
        return False
    else:
        chat_id = call.message.chat.id
        chat_data = sqLite.read_values_by_name(table=f'chats', data=str(chat_id), id_name='chat_id')
        if str(chat_data[7]) == '0':
            return True
        else:
            return False


async def check_main_admin_call(call: types.CallbackQuery):
    user_id = call.from_user.id
    user_data = sqLite.read_values_by_name(table=f'all_users', data=user_id)[7]
    if str(user_data) == 'mainAdmin':
        return True
    else:
        return False


async def check_admin_call(call: types.CallbackQuery):
    user_id = call.from_user.id
    user_data = sqLite.read_values_by_name(table=f'all_users', data=user_id)[7]
    if str(user_data) == 'admin':
        return True
    else:
        return False
