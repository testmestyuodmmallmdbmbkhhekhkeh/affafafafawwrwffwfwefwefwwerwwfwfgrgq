import random

from aiogram.types import ReplyKeyboardMarkup, KeyboardButton
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton


back_reply = KeyboardButton('🔙 назад')

back_kb = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True).add(back_reply)

# Main keyboard
user_data = KeyboardButton('📋профиль')
url = KeyboardButton('🌐ссылки')
market = KeyboardButton('🛒 магазин')
help_btn = KeyboardButton('🆘помощь')
stikers = KeyboardButton('🎭стикеры')
donations = KeyboardButton('💳донат')

main_kb = ReplyKeyboardMarkup(resize_keyboard=True).add(user_data)
main_kb.add(url, market, help_btn)
main_kb.add(stikers, donations)


# Donations kb
qiwi_pay = InlineKeyboardButton(text='🥝QIWI🥝', callback_data='qiwi_pay')
y_kasa_pay = InlineKeyboardButton(text='Оплата картой (СберКасса)', callback_data='sber_pay')
pay_saport = InlineKeyboardButton(text='Проблемы с оплатой', callback_data='pay_saport')
get_bonus = InlineKeyboardButton(text='Получить бонус', callback_data='get_bonus')
back_btn = InlineKeyboardButton(text='Назад', callback_data='back')

donations_kb = InlineKeyboardMarkup().add(qiwi_pay)
# donations_kb.add(y_kasa_pay)
donations_kb.add(get_bonus)
donations_kb.add(back_btn)

# Market keyboard
license_btn = KeyboardButton('📜Лицензия')
no_limits_ = KeyboardButton('🔐Снятие лимита рулетки в группе ')
inviseble = KeyboardButton('🙈Невидимка от !бот вангуй ')
no_ignor = KeyboardButton('🚫Защита от !игнор')
no_muter = KeyboardButton('🚫🙊Защита от !!мут и !игнор')

market_kb = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True).add(license_btn)
market_kb.add(no_limits_)
market_kb.add(inviseble)


# Donations kb
ruletka_one_to_3 = InlineKeyboardButton(text='1-3', callback_data='ruletka_one_to_3')
ruletka_for_to_6 = InlineKeyboardButton(text='4-6', callback_data='ruletka_for_to_6')
ruletka_seven_to_9 = InlineKeyboardButton(text='7-9', callback_data='ruletka_seven_to_9')
ruletka_ten_to_12 = InlineKeyboardButton(text='10-12', callback_data='ruletka_ten_to_12')
ruletka_to_rad = InlineKeyboardButton(text='5 на 🔴', callback_data='ruletka_to_red')
ruletka_to_black = InlineKeyboardButton(text='5 на ⚫️', callback_data='ruletka_to_black')
ruletka_zero = InlineKeyboardButton(text='5 на 💚', callback_data='ruletka_to_0')
ruletka_repit = InlineKeyboardButton(text='Повторить', callback_data='ruletka_repit')
ruletka_double = InlineKeyboardButton(text='Удвоить', callback_data='ruletka_double')
ruletka_start = InlineKeyboardButton(text='Крутить', callback_data='ruletka_start')

ruletka_kb = InlineKeyboardMarkup(row_width=4).add(ruletka_one_to_3, ruletka_for_to_6, ruletka_seven_to_9, ruletka_ten_to_12)
ruletka_kb.add(ruletka_to_rad, ruletka_to_black, ruletka_zero)
ruletka_kb.add(ruletka_repit, ruletka_double, ruletka_start)


def duel_keyb(user_1_id: int, user_2_id: int, deal):
    death = random.randrange(1, 7)
    if death == 1:
        pul_1 = InlineKeyboardButton(text=' ', callback_data=f'death_1_{user_1_id}_{user_2_id}__{deal}')
    else:
        pul_1 = InlineKeyboardButton(text=' ', callback_data=f'live_1_{death}_{user_1_id}_{user_2_id}__{deal}')

    if death == 2:
        pul_2 = InlineKeyboardButton(text=' ', callback_data=f'death_2_{user_1_id}_{user_2_id}__{deal}')
    else:
        pul_2 = InlineKeyboardButton(text=' ', callback_data=f'live_2_{death}_{user_1_id}_{user_2_id}__{deal}')

    if death == 3:
        pul_3 = InlineKeyboardButton(text=' ', callback_data=f'death_3_{user_1_id}_{user_2_id}__{deal}')
    else:
        pul_3 = InlineKeyboardButton(text=' ', callback_data=f'live_3_{death}_{user_1_id}_{user_2_id}__{deal}')

    if death == 4:
        pul_4 = InlineKeyboardButton(text=' ', callback_data=f'death_4_{user_1_id}_{user_2_id}__{deal}')
    else:
        pul_4 = InlineKeyboardButton(text=' ', callback_data=f'live_4_{death}_{user_1_id}_{user_2_id}__{deal}')

    if death == 5:
        pul_5 = InlineKeyboardButton(text=' ', callback_data=f'death_5_{user_1_id}_{user_2_id}__{deal}')
    else:
        pul_5 = InlineKeyboardButton(text=' ', callback_data=f'live_5_{death}_{user_1_id}_{user_2_id}__{deal}')

    if death == 6:
        pul_6 = InlineKeyboardButton(text=' ', callback_data=f'death_6_{user_1_id}_{user_2_id}__{deal}')
    else:
        pul_6 = InlineKeyboardButton(text=' ', callback_data=f'live_6_{death}_{user_1_id}_{user_2_id}__{deal}')
    close_btn = InlineKeyboardButton(text='Сдаться', callback_data=f'close_duel_{user_1_id}_{user_2_id}_{deal}')

    duel_kb = InlineKeyboardMarkup(row_width=4).add(pul_1, pul_2)
    duel_kb.add(pul_3, pul_4)
    duel_kb.add(pul_5, pul_6)
    duel_kb.add(close_btn)
    return duel_kb


def duel_playe_keyb(user_1_id: int, user_2_id: int, death: int, open_btn: str, btn: str, deal: str):
    open_btn = open_btn + btn
    if death == 1:
        pul_1 = InlineKeyboardButton(text=' ', callback_data=f'death_1_{user_1_id}_{user_2_id}_{deal}')
    elif '1' in open_btn:
        pul_1 = InlineKeyboardButton(text='Жизнь', callback_data=f'empty')
    else:
        pul_1 = InlineKeyboardButton(text=' ', callback_data=f'live_1_{death}_{user_1_id}_{user_2_id}_{open_btn}_{deal}')

    if death == 2:
        pul_2 = InlineKeyboardButton(text=' ', callback_data=f'death_2_{user_1_id}_{user_2_id}_{deal}')
    elif '2' in open_btn:
        pul_2 = InlineKeyboardButton(text='Жизнь', callback_data=f'empty')
    else:
        pul_2 = InlineKeyboardButton(text=' ', callback_data=f'live_2_{death}_{user_1_id}_{user_2_id}_{open_btn}_{deal}')

    if death == 3:
        pul_3 = InlineKeyboardButton(text=' ', callback_data=f'death_3_{user_1_id}_{user_2_id}_{deal}')
    elif '3' in open_btn:
        pul_3 = InlineKeyboardButton(text='Жизнь', callback_data=f'empty')
    else:
        pul_3 = InlineKeyboardButton(text=' ', callback_data=f'live_3_{death}_{user_1_id}_{user_2_id}_{open_btn}_{deal}')

    if death == 4:
        pul_4 = InlineKeyboardButton(text=' ', callback_data=f'death_4_{user_1_id}_{user_2_id}_{deal}')
    elif '4' in open_btn:
        pul_4 = InlineKeyboardButton(text='Жизнь', callback_data=f'empty')
    else:
        pul_4 = InlineKeyboardButton(text=' ', callback_data=f'live_4_{death}_{user_1_id}_{user_2_id}_{open_btn}_{deal}')

    if death == 5:
        pul_5 = InlineKeyboardButton(text=' ', callback_data=f'death_5_{user_1_id}_{user_2_id}_{deal}')
    elif '5' in open_btn:
        pul_5 = InlineKeyboardButton(text='Жизнь', callback_data=f'empty')
    else:
        pul_5 = InlineKeyboardButton(text=' ', callback_data=f'live_5_{death}_{user_1_id}_{user_2_id}_{open_btn}_{deal}')

    if death == 6:
        pul_6 = InlineKeyboardButton(text=' ', callback_data=f'death_6_{user_1_id}_{user_2_id}_{deal}')
    elif '6' in open_btn:
        pul_6 = InlineKeyboardButton(text='Жизнь', callback_data=f'empty')
    else:
        pul_6 = InlineKeyboardButton(text=' ', callback_data=f'live_6_{death}_{user_1_id}_{user_2_id}_{open_btn}_{deal}')
    close_btn = InlineKeyboardButton(text='Сдаться', callback_data=f'close_duel_{user_1_id}_{user_2_id}_{deal}')

    duel_kb = InlineKeyboardMarkup(row_width=4).add(pul_1, pul_2)
    duel_kb.add(pul_3, pul_4)
    duel_kb.add(pul_5, pul_6)
    duel_kb.add(close_btn)
    return duel_kb


# Дуэль стартовая клавиатура
def duel_start_kb(tg_id: int,  deal: str,  rep_tg_id: int = None):
    if rep_tg_id is None:
        success_btn = InlineKeyboardButton(text='Принять', callback_data=f's_duel_{tg_id}_free_{deal}')
        close_btn = InlineKeyboardButton(text='Отменить', callback_data=f's_duel_close_{tg_id}_free_{deal}')
    else:
        success_btn = InlineKeyboardButton(text='Принять', callback_data=f's_duel_{tg_id}_{rep_tg_id}_{deal}')
        close_btn = InlineKeyboardButton(text='Отменить', callback_data=f's_duel_close_{tg_id}_{rep_tg_id}_{deal}')
    duel_kb = InlineKeyboardMarkup(row_width=4).add(success_btn)
    duel_kb.add(close_btn)
    return duel_kb


# ХО стартовая клавиатура
def xo_start_kb(tg_id: int,  deal: str,  rep_tg_id: int = None):
    if rep_tg_id is None:
        success_btn = InlineKeyboardButton(text='Принять', callback_data=f's_xo_{tg_id}_free_{deal}')
        close_btn = InlineKeyboardButton(text='Отменить', callback_data=f's_xo_close_{tg_id}_free_{deal}')
    else:
        success_btn = InlineKeyboardButton(text='Принять', callback_data=f's_xo_{tg_id}_{rep_tg_id}_{deal}')
        close_btn = InlineKeyboardButton(text='Отменить', callback_data=f's_xo_close_{tg_id}_{rep_tg_id}_{deal}')
    duel_kb = InlineKeyboardMarkup(row_width=4).add(success_btn)
    duel_kb.add(close_btn)
    return duel_kb


def xo_keyb(user_1_id: int, user_2_id: int, deal: int, cod: str ='000000000'):
    pul_1 = InlineKeyboardButton(text=' ', callback_data=f'x_1_{user_1_id}_{user_2_id}_{cod}_{deal}')
    pul_2 = InlineKeyboardButton(text=' ', callback_data=f'x_2_{user_1_id}_{user_2_id}_{cod}_{deal}')
    pul_3 = InlineKeyboardButton(text=' ', callback_data=f'x_3_{user_1_id}_{user_2_id}_{cod}_{deal}')
    pul_4 = InlineKeyboardButton(text=' ', callback_data=f'x_4_{user_1_id}_{user_2_id}_{cod}_{deal}')
    pul_5 = InlineKeyboardButton(text=' ', callback_data=f'x_5_{user_1_id}_{user_2_id}_{cod}_{deal}')
    pul_6 = InlineKeyboardButton(text=' ', callback_data=f'x_6_{user_1_id}_{user_2_id}_{cod}_{deal}')
    pul_7 = InlineKeyboardButton(text=' ', callback_data=f'x_7_{user_1_id}_{user_2_id}_{cod}_{deal}')
    pul_8 = InlineKeyboardButton(text=' ', callback_data=f'x_8_{user_1_id}_{user_2_id}_{cod}_{deal}')
    pul_9 = InlineKeyboardButton(text=' ', callback_data=f'x_9_{user_1_id}_{user_2_id}_{cod}_{deal}')
    close_btn = InlineKeyboardButton(text='Сдаться', callback_data=f'close_x_{user_1_id}_{user_2_id}_{deal}')

    xo_kb = InlineKeyboardMarkup(row_width=4).add(pul_1, pul_2, pul_3)
    xo_kb.add(pul_4, pul_5, pul_6)
    xo_kb.add(pul_7, pul_8, pul_9)
    xo_kb.add(close_btn)
    return xo_kb


def xo_playe_keyb(user_1_id: int, user_2_id: int, cod: str, deal: str):
    if cod[0] == '0':
        pul_1 = InlineKeyboardButton(text=' ', callback_data=f'x_1_{user_1_id}_{user_2_id}_{cod}_{deal}')
    elif cod[0] == '1':
        pul_1 = InlineKeyboardButton(text='X', callback_data=f'xxo_1_{user_1_id}_{user_2_id}_{cod}_{deal}')
    elif cod[0] == '2':
        pul_1 = InlineKeyboardButton(text='O', callback_data=f'xxo_1_{user_1_id}_{user_2_id}_{cod}_{deal}')

    if cod[1] == '0':
        pul_2 = InlineKeyboardButton(text=' ', callback_data=f'x_2_{user_1_id}_{user_2_id}_{cod}_{deal}')
    elif cod[1] == '1':
        pul_2 = InlineKeyboardButton(text='X', callback_data=f'xxo_2_{user_1_id}_{user_2_id}_{cod}_{deal}')
    elif cod[1] == '2':
        pul_2 = InlineKeyboardButton(text='O', callback_data=f'xxo_2_{user_1_id}_{user_2_id}_{cod}_{deal}')

    if cod[2] == '0':
        pul_3 = InlineKeyboardButton(text=' ', callback_data=f'x_3_{user_1_id}_{user_2_id}_{cod}_{deal}')
    elif cod[2] == '1':
        pul_3 = InlineKeyboardButton(text='X', callback_data=f'xxo_3_{user_1_id}_{user_2_id}_{cod}_{deal}')
    elif cod[2] == '2':
        pul_3 = InlineKeyboardButton(text='O', callback_data=f'xxo_3_{user_1_id}_{user_2_id}_{cod}_{deal}')

    if cod[3] == '0':
        pul_4 = InlineKeyboardButton(text=' ', callback_data=f'x_4_{user_1_id}_{user_2_id}_{cod}_{deal}')
    elif cod[3] == '1':
        pul_4 = InlineKeyboardButton(text='X', callback_data=f'xxo_4_{user_1_id}_{user_2_id}_{cod}_{deal}')
    elif cod[3] == '2':
        pul_4 = InlineKeyboardButton(text='O', callback_data=f'xxo_4_{user_1_id}_{user_2_id}_{cod}_{deal}')

    if cod[4] == '0':
        pul_5 = InlineKeyboardButton(text=' ', callback_data=f'x_5_{user_1_id}_{user_2_id}_{cod}_{deal}')
    elif cod[4] == '1':
        pul_5 = InlineKeyboardButton(text='X', callback_data=f'xxo_5_{user_1_id}_{user_2_id}_{cod}_{deal}')
    elif cod[4] == '2':
        pul_5 = InlineKeyboardButton(text='O', callback_data=f'xxo_5_{user_1_id}_{user_2_id}_{cod}_{deal}')

    if cod[5] == '0':
        pul_6 = InlineKeyboardButton(text=' ', callback_data=f'x_6_{user_1_id}_{user_2_id}_{cod}_{deal}')
    elif cod[5] == '1':
        pul_6 = InlineKeyboardButton(text='X', callback_data=f'xxo_6_{user_1_id}_{user_2_id}_{cod}_{deal}')
    elif cod[5] == '2':
        pul_6 = InlineKeyboardButton(text='O', callback_data=f'xxo_6_{user_1_id}_{user_2_id}_{cod}_{deal}')

    if cod[6] == '0':
        pul_7 = InlineKeyboardButton(text=' ', callback_data=f'x_7_{user_1_id}_{user_2_id}_{cod}_{deal}')
    elif cod[6] == '1':
        pul_7 = InlineKeyboardButton(text='X', callback_data=f'xxo_7_{user_1_id}_{user_2_id}_{cod}_{deal}')
    elif cod[6] == '2':
        pul_7 = InlineKeyboardButton(text='O', callback_data=f'xxo_7_{user_1_id}_{user_2_id}_{cod}_{deal}')

    if cod[7] == '0':
        pul_8 = InlineKeyboardButton(text=' ', callback_data=f'x_8_{user_1_id}_{user_2_id}_{cod}_{deal}')
    elif cod[7] == '1':
        pul_8 = InlineKeyboardButton(text='X', callback_data=f'xxo_8_{user_1_id}_{user_2_id}_{cod}_{deal}')
    elif cod[7] == '2':
        pul_8 = InlineKeyboardButton(text='O', callback_data=f'xxo_8_{user_1_id}_{user_2_id}_{cod}_{deal}')

    if cod[8] == '0':
        pul_9 = InlineKeyboardButton(text=' ', callback_data=f'x_9_{user_1_id}_{user_2_id}_{cod}_{deal}')
    elif cod[8] == '1':
        pul_9 = InlineKeyboardButton(text='X', callback_data=f'xxo_9_{user_1_id}_{user_2_id}_{cod}_{deal}')
    elif cod[8] == '2':
        pul_9 = InlineKeyboardButton(text='O', callback_data=f'xxo_9_{user_1_id}_{user_2_id}_{cod}_{deal}')

    close_btn = InlineKeyboardButton(text='Сдаться', callback_data=f'close_x_{user_1_id}_{user_2_id}_{deal}')

    xo_kb = InlineKeyboardMarkup(row_width=4).add(pul_1, pul_2, pul_3)
    xo_kb.add(pul_4, pul_5, pul_6)
    xo_kb.add(pul_7, pul_8, pul_9)
    xo_kb.add(close_btn)
    return xo_kb


def xo_win_keyb(user_1_id: int, user_2_id: int, cod: str, deal: str):
    if cod[0] == '0':
        pul_1 = InlineKeyboardButton(text=' ', callback_data=f'xxo_1_{user_1_id}_{user_2_id}_{cod}_{deal}')
    elif cod[0] == '1':
        pul_1 = InlineKeyboardButton(text='X', callback_data=f'xxo_1_{user_1_id}_{user_2_id}_{cod}_{deal}')
    elif cod[0] == '2':
        pul_1 = InlineKeyboardButton(text='O', callback_data=f'xxo_1_{user_1_id}_{user_2_id}_{cod}_{deal}')

    if cod[1] == '0':
        pul_2 = InlineKeyboardButton(text=' ', callback_data=f'xxo_2_{user_1_id}_{user_2_id}_{cod}_{deal}')
    elif cod[1] == '1':
        pul_2 = InlineKeyboardButton(text='X', callback_data=f'xxo_2_{user_1_id}_{user_2_id}_{cod}_{deal}')
    elif cod[1] == '2':
        pul_2 = InlineKeyboardButton(text='O', callback_data=f'xxo_2_{user_1_id}_{user_2_id}_{cod}_{deal}')

    if cod[2] == '0':
        pul_3 = InlineKeyboardButton(text=' ', callback_data=f'xxo_3_{user_1_id}_{user_2_id}_{cod}_{deal}')
    elif cod[2] == '1':
        pul_3 = InlineKeyboardButton(text='X', callback_data=f'xxo_3_{user_1_id}_{user_2_id}_{cod}_{deal}')
    elif cod[2] == '2':
        pul_3 = InlineKeyboardButton(text='O', callback_data=f'xxo_3_{user_1_id}_{user_2_id}_{cod}_{deal}')

    if cod[3] == '0':
        pul_4 = InlineKeyboardButton(text=' ', callback_data=f'xxo_4_{user_1_id}_{user_2_id}_{cod}_{deal}')
    elif cod[3] == '1':
        pul_4 = InlineKeyboardButton(text='X', callback_data=f'xxo_4_{user_1_id}_{user_2_id}_{cod}_{deal}')
    elif cod[3] == '2':
        pul_4 = InlineKeyboardButton(text='O', callback_data=f'xxo_4_{user_1_id}_{user_2_id}_{cod}_{deal}')

    if cod[4] == '0':
        pul_5 = InlineKeyboardButton(text=' ', callback_data=f'xxo_5_{user_1_id}_{user_2_id}_{cod}_{deal}')
    elif cod[4] == '1':
        pul_5 = InlineKeyboardButton(text='X', callback_data=f'xxo_5_{user_1_id}_{user_2_id}_{cod}_{deal}')
    elif cod[4] == '2':
        pul_5 = InlineKeyboardButton(text='O', callback_data=f'xxo_5_{user_1_id}_{user_2_id}_{cod}_{deal}')

    if cod[5] == '0':
        pul_6 = InlineKeyboardButton(text=' ', callback_data=f'xxo_6_{user_1_id}_{user_2_id}_{cod}_{deal}')
    elif cod[5] == '1':
        pul_6 = InlineKeyboardButton(text='X', callback_data=f'xxo_6_{user_1_id}_{user_2_id}_{cod}_{deal}')
    elif cod[5] == '2':
        pul_6 = InlineKeyboardButton(text='O', callback_data=f'xxo_6_{user_1_id}_{user_2_id}_{cod}_{deal}')

    if cod[6] == '0':
        pul_7 = InlineKeyboardButton(text=' ', callback_data=f'xxo_7_{user_1_id}_{user_2_id}_{cod}_{deal}')
    elif cod[6] == '1':
        pul_7 = InlineKeyboardButton(text='X', callback_data=f'xxo_7_{user_1_id}_{user_2_id}_{cod}_{deal}')
    elif cod[6] == '2':
        pul_7 = InlineKeyboardButton(text='O', callback_data=f'xxo_7_{user_1_id}_{user_2_id}_{cod}_{deal}')

    if cod[7] == '0':
        pul_8 = InlineKeyboardButton(text=' ', callback_data=f'xxo_8_{user_1_id}_{user_2_id}_{cod}_{deal}')
    elif cod[7] == '1':
        pul_8 = InlineKeyboardButton(text='X', callback_data=f'xxo_8_{user_1_id}_{user_2_id}_{cod}_{deal}')
    elif cod[7] == '2':
        pul_8 = InlineKeyboardButton(text='O', callback_data=f'xxo_8_{user_1_id}_{user_2_id}_{cod}_{deal}')

    if cod[8] == '0':
        pul_9 = InlineKeyboardButton(text=' ', callback_data=f'xxo_9_{user_1_id}_{user_2_id}_{cod}_{deal}')
    elif cod[8] == '1':
        pul_9 = InlineKeyboardButton(text='X', callback_data=f'xxo_9_{user_1_id}_{user_2_id}_{cod}_{deal}')
    elif cod[8] == '2':
        pul_9 = InlineKeyboardButton(text='O', callback_data=f'xxo_9_{user_1_id}_{user_2_id}_{cod}_{deal}')

    close_btn = InlineKeyboardButton(text='Сдаться', callback_data=f'close_xxo_{user_1_id}_{user_2_id}_{deal}')

    xo_kb = InlineKeyboardMarkup(row_width=4).add(pul_1, pul_2, pul_3)
    xo_kb.add(pul_4, pul_5, pul_6)
    xo_kb.add(pul_7, pul_8, pul_9)
    xo_kb.add(close_btn)
    return xo_kb


# ХО стартовая клавиатура
def words_start_kb(tg_id: int, chat_id: int, deal: str,  rep_tg_id: int = None):
    if rep_tg_id is None:
        success_btn = InlineKeyboardButton(text='Принять', callback_data=f's_words_{chat_id}_{tg_id}_free_{deal}')
        close_btn = InlineKeyboardButton(text='Отменить', callback_data=f'words_closeons_{chat_id}_{tg_id}_free_{deal}')
    else:
        success_btn = InlineKeyboardButton(text='Принять', callback_data=f's_words_{chat_id}_{tg_id}_{rep_tg_id}_{deal}')
        close_btn = InlineKeyboardButton(text='Отменить', callback_data=f'words_closeons_{chat_id}_{tg_id}_{rep_tg_id}_{deal}')
    duel_kb = InlineKeyboardMarkup(row_width=4).add(success_btn)
    duel_kb.add(close_btn)
    return duel_kb


# Свадьба простая стартовая клавиатура
def wedding_start_kb(chat_id: str, creator: str):

    man_btn = InlineKeyboardButton(text='Жених', callback_data=f'wedding_man_{chat_id}_{creator}')
    woman_btn = InlineKeyboardButton(text='Невеста', callback_data=f'wedding_woman_{chat_id}_{creator}')
    guest_btn = InlineKeyboardButton(text='Гость', callback_data=f'wedding_guests_{chat_id}_{creator}')
    wetnes_w_btn = InlineKeyboardButton(text='Свидетельница', callback_data=f'wedding_witnessw_{chat_id}_{creator}')
    wetnes_m_btn = InlineKeyboardButton(text='Свидетель', callback_data=f'wedding_witnessm_{chat_id}_{creator}')
    wedding_btn = InlineKeyboardButton(text='Поженить', callback_data=f'wedding_start_{chat_id}_{creator}')
    sing_btn = InlineKeyboardButton(text='Подпись', callback_data=f'wedding_sing_{chat_id}_{creator}')
    registr_btn = InlineKeyboardButton(text='Регистратор', callback_data=f'wedding_registrar_{chat_id}_{creator}')
    cancel_btn = InlineKeyboardButton(text='Отменить свадьбу', callback_data=f'wedding_cancel_{chat_id}_{creator}')

    wedding_kb = InlineKeyboardMarkup(row_width=4).add(man_btn, woman_btn, guest_btn)
    wedding_kb.add(wetnes_w_btn, wetnes_m_btn)
    wedding_kb.add(wedding_btn, sing_btn, registr_btn)
    wedding_kb.add(cancel_btn)
    return wedding_kb


# Свадьба вип стартовая клавиатура
def wedding_vip_start_kb(chat_id: str, creator: str):

    man_btn = InlineKeyboardButton(text='Жених', callback_data=f'wedvip_man_{chat_id}_{creator}')
    woman_btn = InlineKeyboardButton(text='Невеста', callback_data=f'wedvip_woman_{chat_id}_{creator}')
    guest_btn = InlineKeyboardButton(text='Гость', callback_data=f'wedvip_guests_{chat_id}_{creator}')
    son_w_btn = InlineKeyboardButton(text='Сыночек', callback_data=f'wedvip_son_{chat_id}_{creator}')
    daurhter_m_btn = InlineKeyboardButton(text='Дочка', callback_data=f'wedvip_daughter_{chat_id}_{creator}')
    wetnes_w_btn = InlineKeyboardButton(text='Свидетельница', callback_data=f'wedvip_witnessw_{chat_id}_{creator}')
    wetnes_m_btn = InlineKeyboardButton(text='Свидетель', callback_data=f'wedvip_witnessm_{chat_id}_{creator}')
    wedding_btn = InlineKeyboardButton(text='Поженить', callback_data=f'wedvip_start_{chat_id}_{creator}')
    sing_btn = InlineKeyboardButton(text='Подпись', callback_data=f'wedvip_sing_{chat_id}_{creator}')
    registr_btn = InlineKeyboardButton(text='Регистратор', callback_data=f'wedvip_registrar_{chat_id}_{creator}')
    cancel_btn = InlineKeyboardButton(text='Отменить свадьбу', callback_data=f'wedvip_cancel_{chat_id}_{creator}')

    wedding_kb = InlineKeyboardMarkup(row_width=4).add(man_btn, woman_btn, guest_btn)
    wedding_kb.add(son_w_btn, daurhter_m_btn)
    wedding_kb.add(wetnes_w_btn, wetnes_m_btn)
    wedding_kb.add(wedding_btn, sing_btn, registr_btn)
    wedding_kb.add(cancel_btn)
    return wedding_kb


# Развод стартовая клавиатура
def divorce_start_kb(licensi: str, creator: str):
    guest_btn = InlineKeyboardButton(text='Присяжный', callback_data=f'divorce_wietnes_{licensi}_{creator}')
    wedding_btn = InlineKeyboardButton(text='Развести', callback_data=f'divorce_start_{licensi}_{creator}')
    sing_btn = InlineKeyboardButton(text='Подпись', callback_data=f'divorce_sing_{licensi}_{creator}')
    registr_btn = InlineKeyboardButton(text='Судья', callback_data=f'divorce_registrator_{licensi}_{creator}')
    cancel_btn = InlineKeyboardButton(text='Отменить развод', callback_data=f'divorce_cancel_{licensi}_{creator}')

    divorce_kb = InlineKeyboardMarkup(row_width=4).add(registr_btn, guest_btn)
    divorce_kb.add(wedding_btn, sing_btn)
    divorce_kb.add(cancel_btn)
    return divorce_kb


# Развод стартовая клавиатура
def market_kb():
    licensy_btn = InlineKeyboardButton(text='📃лицензия', callback_data=f'market_licensy_btn')
    licensy_vip_btn = InlineKeyboardButton(text='📜лицензия Vip', callback_data=f'market_licensy_vip_btn')
    ruletka_btn = InlineKeyboardButton(text='🔐Снятие лимита рулетки в группе', callback_data="market_ruletka_btn")
    invise_protect_btn = InlineKeyboardButton(text='🙈Невидимка от !бот вангуй', callback_data='market_invise_btn')
    ignor_protect_btn = InlineKeyboardButton(text='🚫Защита от !игнор', callback_data=f'market_ignor_protect_btn')
    mut_protect_btn = InlineKeyboardButton(text='🚫🙊Защита от !!мут и !игнор', callback_data=f'market_mut_protect_btn')

    market_kb = InlineKeyboardMarkup().add(licensy_btn)
    # market_kb.add(licensy_vip_btn)
    market_kb.add(ruletka_btn)
    # market_kb.add(invise_protect_btn)
    market_kb.add(ignor_protect_btn)
    market_kb.add(mut_protect_btn)
    return market_kb


# Donations kb сбер банк
money_99 = InlineKeyboardButton(text='100.000 - 99₽', callback_data='money_99')
money_399 = InlineKeyboardButton(text='500.000 - 399₽', callback_data='money_399')
money_699 = InlineKeyboardButton(text='1.000.000 - 699₽', callback_data='money_699')
money_3399 = InlineKeyboardButton(text='5.000.000 - 3399₽', callback_data='money_3399')
money_5999 = InlineKeyboardButton(text='10.000.000 - 5999₽', callback_data='money_5999')
status_499 = InlineKeyboardButton(text='[🌝] Дневной - 499₽', callback_data='statu_499')
status_1999 = InlineKeyboardButton(text='[🌚] Ночной - 1999₽', callback_data='statu_1999')
status_4999 = InlineKeyboardButton(text='[👑] Королевский - 4999₽', callback_data='statu_4999')
status_9999 = InlineKeyboardButton(text='[🦉] Фирменный - 9999₽', callback_data='statu_9999')
status_999 = InlineKeyboardButton(text='[🎩] Декоративный статус без монет - 679₽', callback_data='statu_679')
status_599 = InlineKeyboardButton(text='[🔐]Снятие лимита рулетки в группе - 599₽', callback_data='statu_599')
status_299 = InlineKeyboardButton(text='[🤴❤️👸] VipOwl - красочная свадьба, одинокий развод - 299',
                                  callback_data='statu_299')

pay_sber_kb = InlineKeyboardMarkup().add(money_99, money_399)
pay_sber_kb.add(money_699, money_3399)
pay_sber_kb.add(money_5999)
pay_sber_kb.add(status_499)
pay_sber_kb.add(status_1999)
pay_sber_kb.add(status_4999)
pay_sber_kb.add(status_9999)
pay_sber_kb.add(status_999)
pay_sber_kb.add(status_599)
pay_sber_kb.add(status_299)


def qiwi_pay_bill(pay_url: str):
    pay_btn = InlineKeyboardButton(text='Оплатить счет', url=pay_url)

    pay_kb = InlineKeyboardMarkup().add(pay_btn)
    return pay_kb


def go_to_bot():
    go_to_btn = InlineKeyboardButton(text='Пользовательское соглашение', url="https://t.me/ByOw1Bot")

    go_to_kb = InlineKeyboardMarkup().add(go_to_btn)
    return go_to_kb


# Розыгрыш стартовая клавиатура
def raffle_start_kb(tg_id: int, chat_id: int, deal: str):
    attach_btn = InlineKeyboardButton(text='Присоединиться', callback_data=f'raffle_attach_{chat_id}_{tg_id}_{deal}')
    close_btn = InlineKeyboardButton(text='Отменить', callback_data=f'raffle_close_{chat_id}_{tg_id}_{deal}')
    start_btn = InlineKeyboardButton(text='Начать', callback_data=f'raffle_start_{chat_id}_{tg_id}_{deal}')
    raffle_kb = InlineKeyboardMarkup(row_width=4).add(attach_btn, start_btn)
    raffle_kb.add(close_btn)
    return raffle_kb
