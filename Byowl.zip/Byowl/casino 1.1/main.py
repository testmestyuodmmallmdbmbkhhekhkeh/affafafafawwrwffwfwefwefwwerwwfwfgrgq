from aiogram import executor
from modules.dispatcher import dp
import threading
from modules.scedual_process import start_schedule_


if __name__ == '__main__':
    t = threading.Thread(target=start_schedule_, name="Thread")
    t.start()
    executor.start_polling(dp)
